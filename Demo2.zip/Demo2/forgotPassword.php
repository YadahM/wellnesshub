<!-- counsellor forgot password html -->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />

  <meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
  />

  <title>
    Forgot Password — WellnessHub
  </title>

  <link
    rel="stylesheet"
    href="css/style.css"
  />
</head>

<body class="dark-body">

  <main class="auth-screen">

    <section class="auth-card dark-login-card forgot-card">

      <div class="auth-number">
        COUNSELLOR PASSWORD RECOVERY
      </div>

      <div class="brand-mini">

        <span
          class="mini-leaf"
          aria-hidden="true">
          ☘
        </span>

        <span>
          WellnessHub
        </span>

      </div>


      <!-- STEP 1 -->
      <div
        id="emailStep"
        class="forgot-step active-step">

        <header class="auth-header">

          <div class="forgot-icon">
            🔐
          </div>

          <h1>Forgot Password?</h1>

          <p>
            Enter your counsellor email address
            to reset your password.
          </p>

        </header>


        <form
          id="forgotEmailForm"
          class="auth-form">

          <label class="field">

            <span>
              Counsellor Email
            </span>

            <input
              id="resetEmail"
              type="email"
              placeholder="counsellor@richfield.ac.za"
              autocomplete="email"
              required
            />

          </label>


          <p
            id="emailMessage"
            class="forgot-message">
          </p>


          <button
            class="btn btn-blue btn-full"
            type="submit">

            Send Verification Code

          </button>

        </form>


        <p class="forgot-back">

          <a href="counsellor-login.php">
            ← Back to Counsellor Login
          </a>

        </p>

      </div>


      <!-- STEP 2 -->
      <div
        id="codeStep"
        class="forgot-step">

        <header class="auth-header">

          <div class="forgot-icon">
            ✉️
          </div>

          <h1>Verify Account</h1>

          <p>
            Enter the 6-digit verification
            code sent to your email.
          </p>

        </header>


        <form
          id="verificationForm"
          class="auth-form">

          <label class="field">

            <span>
              Verification Code
            </span>

            <input
              id="verificationCode"
              class="verification-input"
              type="text"
              maxlength="6"
              inputmode="numeric"
              placeholder="000000"
              required
            />

          </label>


          <div class="demo-code-box">

            <strong>Prototype Code</strong>

            <span>
              Use 123456
            </span>

          </div>


          <p
            id="codeMessage"
            class="forgot-message">
          </p>


          <button
            class="btn btn-blue btn-full"
            type="submit">

            Verify Code

          </button>


          <button
            id="resendCode"
            class="forgot-secondary-btn"
            type="button">

            Resend Code

          </button>

        </form>


        <p class="forgot-back">

          <button
            id="backToEmail"
            class="forgot-link-button"
            type="button">

            ← Change Email

          </button>

        </p>

      </div>


      <!-- STEP 3 -->
      <div
        id="passwordStep"
        class="forgot-step">

        <header class="auth-header">

          <div class="forgot-icon">
            🔑
          </div>

          <h1>Create New Password</h1>

          <p>
            Create a new password for your
            counsellor account.
          </p>

        </header>


        <form
          id="newPasswordForm"
          class="auth-form">

          <label class="field password-field">

            <span>
              New Password
            </span>

            <input
              id="newPassword"
              type="password"
              placeholder="Enter new password"
              minlength="8"
              required
            />

            <button
              class="password-toggle"
              type="button"
              aria-label="Show password">

              ◎

            </button>

          </label>


          <label class="field password-field">

            <span>
              Confirm Password
            </span>

            <input
              id="confirmPassword"
              type="password"
              placeholder="Confirm new password"
              minlength="8"
              required
            />

            <button
              class="password-toggle"
              type="button"
              aria-label="Show password">

              ◎

            </button>

          </label>


          <div class="password-requirements">

            <p>Password must contain:</p>

            <span id="lengthRequirement">
              ○ At least 8 characters
            </span>

            <span id="numberRequirement">
              ○ At least one number
            </span>

            <span id="capitalRequirement">
              ○ At least one uppercase letter
            </span>

          </div>


          <p
            id="passwordMessage"
            class="forgot-message">
          </p>


          <button
            class="btn btn-blue btn-full"
            type="submit">

            Reset Password

          </button>

        </form>

      </div>


      <!-- STEP 4 -->
      <div
        id="successStep"
        class="forgot-step">

        <div class="forgot-success">

          <div class="success-circle">
            ✓
          </div>

          <h1>
            Password Reset
          </h1>

          <p>
            Your counsellor password has
            been successfully changed.
          </p>

          <a
            href="counsellor-login.php"
            class="btn btn-blue btn-full">

            Return to Login

          </a>

        </div>

      </div>


      <p class="legal-text">
        Secure • Confidential • POPIA Compliant
      </p>

    </section>

  </main>


  <script src="js/forgotPassword.js"></script>

</body>

</html>