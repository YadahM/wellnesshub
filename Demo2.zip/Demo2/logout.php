<?php
session_start();

$role = $_SESSION['role'] ?? 'student';

$_SESSION = [];

if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'],
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );
}

session_destroy();

$destination = match ($role) {
    'admin'      => 'admin-login.php',
    'counsellor' => 'counsellor-login.php',
    default      => 'login.php',
};

header('Location: ' . $destination);
exit;
