<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Login — WellnessHub</title>
  <link rel="stylesheet" href="css/style.css" />
  <style>
    .banner{padding:12px 14px; border-radius:10px; font-size:13px; font-weight:700; margin-bottom:16px; display:none;}
    .banner.error{background:rgba(243,109,109,.16); color:#ffb4b4; display:block;}
    .banner.success{background:rgba(87,166,111,.18); color:#9be6b3; display:block;}
  </style>
</head>
<body class="dark-body">
  <main class="auth-screen">
    <section class="auth-card dark-login-card">
      <div class="auth-number">12. &nbsp; ADMIN LOGIN</div>
      <div class="brand-mini"><span class="mini-leaf" aria-hidden="true">☘</span><span>WellnessHub</span></div>
      <header class="auth-header"><h1>Administrator Account</h1><p>Login to continue</p></header>

      <div id="formBanner" class="banner"></div>

      <form class="auth-form" id="adminLoginForm" novalidate>
        <label class="field"><span>Admin Email</span><input type="email" id="email" name="email" placeholder="admin@richfield.ac.za" required /></label>
        <label class="field password-field"><span>Password</span><input type="password" id="password" name="password" placeholder="••••••••" required /><button type="button" aria-label="Show password" data-toggle="password">◎</button></label>
        <button class="btn btn-blue btn-full" type="submit" id="submitBtn">Login</button>
      </form>
      <p class="legal-text">Secure • Restricted • POPIA Compliant</p>
      <p class="form-footer"><a href="login.php">Student Login</a> · <a href="counsellor-login.php">Counsellor Login</a></p>
    </section>
  </main>

  <script src="js/admin-login.js"></script>
</body>
</html>
