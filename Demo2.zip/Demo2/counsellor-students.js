// counsellor student js
document.addEventListener("DOMContentLoaded", () => {

    // ==========================================
    // 1. CHECK COUNSELLOR LOGIN
    // ==========================================

    const counsellorLoggedIn =
        sessionStorage.getItem("counsellorLoggedIn");

    /*
    Enable this after testing your login page.

    if (counsellorLoggedIn !== "true") {
        alert("Please login as a counsellor first.");
        window.location.href = "counsellor-login.html";
        return;
    }
    */


    // ==========================================
    // 2. GET PAGE ELEMENTS
    // ==========================================

    const searchInput =
        document.querySelector(".input-like");

    const table =
        document.querySelector(".data-table");

    const tableBody =
        table.querySelector("tbody");

    const rows =
        tableBody.querySelectorAll("tr");


    // ==========================================
    // 3. STUDENT SEARCH
    // ==========================================

    searchInput.addEventListener("input", () => {

        const searchValue =
            searchInput.value
                .toLowerCase()
                .trim();

        let visibleStudents = 0;

        rows.forEach(row => {

            const rowText =
                row.textContent.toLowerCase();

            if (rowText.includes(searchValue)) {

                row.style.display = "";
                visibleStudents++;

            } else {

                row.style.display = "none";
            }

        });

        showNoResultsMessage(visibleStudents);
    });


    // ==========================================
    // 4. NO SEARCH RESULTS MESSAGE
    // ==========================================

    function showNoResultsMessage(count) {

        let noResultsRow =
            document.querySelector(".no-results-row");

        if (count === 0) {

            if (!noResultsRow) {

                noResultsRow =
                    document.createElement("tr");

                noResultsRow.classList.add(
                    "no-results-row"
                );

                noResultsRow.innerHTML = `
                    <td colspan="5"
                        style="
                            text-align:center;
                            padding:30px;
                            opacity:0.7;
                        ">
                        No students found.
                    </td>
                `;

                tableBody.appendChild(noResultsRow);
            }

        } else {

            if (noResultsRow) {
                noResultsRow.remove();
            }

        }
    }


    // ==========================================
    // 5. STUDENT DATA
    // ==========================================

    const students = {

        "Student #T103": {
            mood: "Low",
            risk: "High",
            checkIn: "Today",
            status: "Requires immediate follow-up"
        },

        "Student #Q045": {
            mood: "Struggling",
            risk: "High",
            checkIn: "Yesterday",
            status: "Counsellor follow-up recommended"
        },

        "Student #120": {
            mood: "Good",
            risk: "Low",
            checkIn: "Today",
            status: "No immediate intervention required"
        }

    };


    // ==========================================
    // 6. PROFILE BUTTON
    // ==========================================

    const profileButtons =
        document.querySelectorAll(
            '.btn-ghost[href="#"]'
        );

    profileButtons.forEach(button => {

        button.addEventListener(
            "click",
            event => {

                event.preventDefault();

                const row =
                    button.closest("tr");

                const studentName =
                    row.children[0]
                        .textContent
                        .trim();

                const student =
                    students[studentName];

                if (student) {

                    showStudentProfile(
                        studentName,
                        student
                    );

                }

            }
        );

    });


    // ==========================================
    // 7. STUDENT PROFILE POPUP
    // ==========================================

    function showStudentProfile(
        studentName,
        student
    ) {

        const existingModal =
            document.querySelector(
                ".student-profile-modal"
            );

        if (existingModal) {
            existingModal.remove();
        }


        const modal =
            document.createElement("div");

        modal.className =
            "student-profile-modal";

        modal.innerHTML = `

            <div class="student-profile-box">

                <button
                    class="close-profile"
                    aria-label="Close profile">
                    ×
                </button>

                <p class="eyebrow">
                    Student Profile
                </p>

                <h2>${studentName}</h2>

                <div class="profile-info">

                    <p>
                        <strong>Mood:</strong>
                        ${student.mood}
                    </p>

                    <p>
                        <strong>Risk Level:</strong>
                        ${student.risk}
                    </p>

                    <p>
                        <strong>Last Check-in:</strong>
                        ${student.checkIn}
                    </p>

                    <p>
                        <strong>Status:</strong>
                        ${student.status}
                    </p>

                </div>

                <button
                    class="btn btn-blue close-profile-button">
                    Close
                </button>

            </div>

        `;

        document.body.appendChild(modal);


        const closeButton =
            modal.querySelector(
                ".close-profile"
            );

        const closeBottomButton =
            modal.querySelector(
                ".close-profile-button"
            );


        closeButton.addEventListener(
            "click",
            () => modal.remove()
        );


        closeBottomButton.addEventListener(
            "click",
            () => modal.remove()
        );


        modal.addEventListener(
            "click",
            event => {

                if (event.target === modal) {
                    modal.remove();
                }

            }
        );

    }


    // ==========================================
    // 8. HIGHLIGHT HIGH RISK ROWS
    // ==========================================

    rows.forEach(row => {

        const risk =
            row.children[2]
                .textContent
                .trim()
                .toLowerCase();

        if (risk === "high") {

            row.classList.add(
                "high-risk-row"
            );

        }

    });


    // ==========================================
    // 9. VIEW HIGH RISK STUDENT
    // ==========================================

    const viewButtons =
        document.querySelectorAll(
            '.btn-blue.btn-small'
        );

    viewButtons.forEach(button => {

        button.addEventListener(
            "click",
            event => {

                const row =
                    button.closest("tr");

                const studentName =
                    row.children[0]
                        .textContent
                        .trim();

                sessionStorage.setItem(
                    "selectedRiskStudent",
                    studentName
                );

            }
        );

    });


    // ==========================================
    // 10. LOGOUT
    // ==========================================

    const logoutLink =
        document.querySelector(
            '.side-nav a[href="counsellor-login.html"]'
        );

    if (logoutLink) {

        logoutLink.addEventListener(
            "click",
            event => {

                event.preventDefault();

                const confirmLogout =
                    confirm(
                        "Are you sure you want to logout?"
                    );

                if (confirmLogout) {

                    sessionStorage.removeItem(
                        "counsellorLoggedIn"
                    );

                    sessionStorage.removeItem(
                        "counsellorEmail"
                    );

                    sessionStorage.removeItem(
                        "selectedRiskStudent"
                    );

                    window.location.href =
                        "counsellor-login.html";
                }

            }
        );

    }


    // ==========================================
    // 11. ACTIVE SIDEBAR PAGE
    // ==========================================

    const navLinks =
        document.querySelectorAll(
            ".side-nav a"
        );

    const currentPage =
        window.location.pathname
            .split("/")
            .pop();

    navLinks.forEach(link => {

        const linkPage =
            link.getAttribute("href");

        if (linkPage === currentPage) {

            link.classList.add("active");

        } else {

            link.classList.remove("active");

        }

    });

});