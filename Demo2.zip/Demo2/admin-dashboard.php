<?php require_once __DIR__ . '/admin-auth.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Dashboard — WellnessHub</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body class="app-body admin-body">
  <div class="app-shell admin-shell">
    <aside class="sidebar admin-sidebar">
      <a class="brand-mini sidebar-brand" href="index.php">
        <span class="mini-leaf" aria-hidden="true">☘</span>
        <span>WellnessHub</span>
      </a>

      <nav class="side-nav" aria-label="Admin navigation">
        <a class="active" href="admin-dashboard.php"><span>▣</span> Dashboard</a>
        <a href="admin-users.php"><span>👥</span> Users</a>
        <a href="admin-counsellors.php"><span>♡</span> Counsellors</a>
        <a href="admin-reports.php"><span>📊</span> Reports</a>
        <a href="system-logs.php"><span>☷</span> System Logs</a>
        <a href="admin-settings.php"><span>⚙</span> Settings</a>
        <a href="logout.php"><span>↪</span> Logout</a>
      </nav>
    </aside>

    <main class="dashboard-main admin-main ">
      <header class="topbar admin-topbar">
        <div>
          <p class="eyebrow">Admin Side</p>
          <h1>Admin Dashboard</h1>
          <p class="page-subtitle">Overview of the WellnessHub platform.</p>
        </div>
        <div class="topbar-actions">
          <a class="icon-btn admin-icon" href="system-logs.php" aria-label="System logs">🔔</a>
          <?php $adminFirstName = explode(' ', $_SESSION['full_name'])[0]; ?>
          <div class="avatar admin-avatar"><?= htmlspecialchars(strtoupper(substr($adminFirstName, 0, 1))) ?></div>
        </div>
      </header>
      <section class="page-grid">
        <div class="kpi-grid">
          <div class="kpi-card"><span>Total Users</span><strong id="kpiTotalUsers">–</strong></div>
          <div class="kpi-card"><span>Active Students</span><strong id="kpiActiveStudents">–</strong></div>
          <div class="kpi-card"><span>Counsellors</span><strong id="kpiCounsellors">–</strong></div>
          <div class="kpi-card"><span>Sessions This Month</span><strong id="kpiSessions">–</strong></div>
        </div>
        <section class="two-col">
          <article class="panel">
            <h2>User Growth</h2>
            <svg class="svg-chart" id="growthChart" viewBox="0 0 420 180">
              <path class="chart-gridline" d="M20 35H400M20 80H400M20 125H400"/>
              <g id="growthLines"></g>
              <g id="growthDots"></g>
              <g id="growthLabels"></g>
            </svg>
          </article>
          <article class="panel">
            <h2 id="concernsHeading">Journal Mood Breakdown</h2>
            <div class="donut purple-donut" id="concernsDonut"></div>
            <ul class="legend" id="concernsLegend"></ul>
          </article>
        </section>
      </section>
    </main>
  </div>
  <script src="js/admin-dashboard.js"></script>
</body>
</html>
