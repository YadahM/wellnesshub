<?php require_once __DIR__ . '/counsellor-auth.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Welcome, <?= htmlspecialchars($_SESSION['full_name']) ?> — WellnessHub</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body class="app-body dark-body counsellor-body">
  <div class="app-shell dark-shell">
    <aside class="sidebar counsellor-sidebar">
      <a class="brand-mini sidebar-brand" href="index.php">
        <span class="mini-leaf" aria-hidden="true">☘</span>
        <span>WellnessHub</span>
      </a>

      <nav class="side-nav" aria-label="Counsellor navigation">
        <a class="active" href="counsellor-dashboard.php"><span>▣</span> Dashboard</a>
        <a href="counsellor-students.php"><span>👥</span> Students</a>
        <a href="risk-alerts.php"><span>⚠</span> Risk Alerts</a>
        <a href="counsellor-appointments.php"><span>📅</span> Appointments</a>
        <a href="counsellor-resources.php"><span>▤</span> Resources</a>
        <a href="logout.php"><span>↪</span> Logout</a>
      </nav>
    </aside>

    <main class="dashboard-main dark-main">
      <header class="topbar dark-topbar">
        <div>
          <p class="eyebrow">Counsellor Side</p>
          <h1>Welcome, <?= htmlspecialchars($_SESSION['full_name']) ?></h1>
          <p class="page-subtitle">Here is today's counselling overview.</p>
        </div>
        <div class="topbar-actions">
          <a class="icon-btn dark-icon" href="risk-alerts.php" aria-label="Alerts">🔔</a>
          <div class="avatar dark-avatar"><?= htmlspecialchars(strtoupper(substr($_SESSION['full_name'], 0, 1))) ?></div>
        </div>
      </header>

      <section class="page-grid">
        <div class="kpi-grid">
          <div class="kpi-card"><span>Students Checked In Today</span><strong id="kpiCheckins">—</strong><small class="green">Today</small></div>
          <div class="kpi-card"><span>High Risk Students</span><strong class="red" id="kpiHighRisk">—</strong><small class="red">Needs attention</small></div>
          <div class="kpi-card"><span>Appointments Today</span><strong id="kpiAppointments">—</strong><small class="green">Scheduled</small></div>
          <div class="kpi-card"><span>Resolved Alerts</span><strong id="kpiResolved">—</strong><small class="green">Last 7 days</small></div>
        </div>

        <section class="two-col">
          <article class="panel">
            <h2>Emotional Index Trend</h2>
            <div style="position:relative;height:260px;"><canvas id="emotionalIndexChart"></canvas></div>
          </article>
          <article class="panel">
            <h2>Mood Distribution</h2>
            <div style="position:relative;height:260px;"><canvas id="moodDistributionChart"></canvas></div>
          </article>
        </section>
      </section>
    </main>
  </div>

  <script src="js/vendor/chart.umd.min.js"></script>
  <script src="js/counsellor-dashboard.js"></script>
  <script src="js/counsellor-charts.js"></script>
</body>
</html>
