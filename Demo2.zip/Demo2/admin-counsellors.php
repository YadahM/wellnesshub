<?php require_once __DIR__ . '/admin-auth.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Counsellors — WellnessHub</title>
  <link rel="stylesheet" href="css/style.css" />
  <style>
    /* Supplementary styles for the Add Counsellor modal — same convention as other pages' additions */
    .modal-overlay{ position:fixed; inset:0; background:rgba(0,0,0,.45); display:flex; align-items:center; justify-content:center; z-index:50; }
    .modal-box{ width:min(420px, 90vw); max-height:85vh; overflow-y:auto; }
    .forgot-message.error{ color:#c44848; }
    .forgot-message.success{ color:#2f744d; }
  </style>
</head>
<body class="app-body admin-body">
  <div class="app-shell admin-shell">
    <aside class="sidebar admin-sidebar">
      <a class="brand-mini sidebar-brand" href="index.php">
        <span class="mini-leaf" aria-hidden="true">☘</span>
        <span>WellnessHub</span>
      </a>

      <nav class="side-nav" aria-label="Admin navigation">
        <a href="admin-dashboard.php"><span>▣</span> Dashboard</a>
        <a href="admin-users.php"><span>👥</span> Users</a>
        <a class="active" href="admin-counsellors.php"><span>♡</span> Counsellors</a>
        <a href="admin-reports.php"><span>📊</span> Reports</a>
        <a href="system-logs.php"><span>☷</span> System Logs</a>
        <a href="admin-settings.php"><span>⚙</span> Settings</a>
        <a href="logout.php"><span>↪</span> Logout</a>
      </nav>
    </aside>

    <main class="dashboard-main admin-main ">
      <header class="topbar admin-topbar">
        <div>
          <p class="eyebrow">Admin Side</p>
          <h1>Counsellors</h1>
          <p class="page-subtitle">Manage counsellor workload and availability.</p>
        </div>
        <div class="topbar-actions">
          <a class="icon-btn admin-icon" href="system-logs.php" aria-label="System logs">🔔</a>
          <?php $adminFirstName = explode(' ', $_SESSION['full_name'])[0]; ?>
          <div class="avatar admin-avatar"><?= htmlspecialchars(strtoupper(substr($adminFirstName, 0, 1))) ?></div>
        </div>
      </header>
      <div class="inline" style="margin-bottom:14px; justify-content:flex-end;">
        <button class="btn btn-purple btn-small" type="button" id="addCounsellorBtn">Add Counsellor</button>
      </div>
      <section class="three-col" id="counsellorGrid">
        <p class="muted">Loading counsellors…</p>
      </section>

      <!-- Add Counsellor modal -->
      <div id="addCounsellorModal" class="modal-overlay" style="display:none;">
        <div class="modal-box panel">
          <h2>Add Counsellor</h2>
          <p class="muted">Creates both a real login account and a booking-page profile.</p>
          <label class="field"><span>Full Name</span><input type="text" id="ccName" /></label>
          <label class="field"><span>Email</span><input type="email" id="ccEmail" placeholder="name@richfield.ac.za" /></label>
          <label class="field"><span>Password</span><input type="text" id="ccPassword" placeholder='Must start with "123"' /></label>
          <label class="field"><span>Specialties</span><input type="text" id="ccSpecialties" placeholder="e.g. Anxiety, Academic Stress" /></label>
          <label class="field"><span>Avatar Emoji</span><input type="text" id="ccAvatar" placeholder="🧑🏽" maxlength="4" /></label>
          <p id="ccMessage" class="forgot-message"></p>
          <div class="inline" style="margin-top:10px;">
            <button class="btn btn-ghost" type="button" id="ccCancel">Cancel</button>
            <button class="btn btn-primary" type="button" id="ccSubmit">Create Counsellor</button>
          </div>
        </div>
      </div>
    </main>
  </div>
  <script src="js/admin-counsellors.js"></script>
</body>
</html>
