<?php require_once __DIR__ . '/admin-auth.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Reports & Export — WellnessHub</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body class="app-body admin-body">
  <div class="app-shell admin-shell">
    <aside class="sidebar admin-sidebar">
      <a class="brand-mini sidebar-brand" href="index.php">
        <span class="mini-leaf" aria-hidden="true">☘</span>
        <span>WellnessHub</span>
      </a>

      <nav class="side-nav" aria-label="Admin navigation">
        <a href="admin-dashboard.php"><span>▣</span> Dashboard</a>
        <a href="admin-users.php"><span>👥</span> Users</a>
        <a href="admin-counsellors.php"><span>♡</span> Counsellors</a>
        <a class="active" href="admin-reports.php"><span>📊</span> Reports</a>
        <a href="system-logs.php"><span>☷</span> System Logs</a>
        <a href="admin-settings.php"><span>⚙</span> Settings</a>
        <a href="logout.php"><span>↪</span> Logout</a>
      </nav>
    </aside>

    <main class="dashboard-main admin-main ">
      <header class="topbar admin-topbar">
        <div>
          <p class="eyebrow">Admin Side</p>
          <h1>Reports & Export</h1>
          <p class="page-subtitle">Generate and export institutional wellness reports.</p>
        </div>
        <div class="topbar-actions">
          <a class="icon-btn admin-icon" href="system-logs.php" aria-label="System logs">🔔</a>
          <?php $adminFirstName = explode(' ', $_SESSION['full_name'])[0]; ?>
          <div class="avatar admin-avatar"><?= htmlspecialchars(strtoupper(substr($adminFirstName, 0, 1))) ?></div>
        </div>
      </header>
      <section class="page-grid">
        <article class="panel">
          <div class="panel-heading"><h2>Institution Wellness Report</h2></div>
          <div class="three-col">
            <label class="field"><span>Report Type</span>
              <select id="reportType">
                <option value="monthly">Monthly Report</option>
                <option value="risk">Risk Report</option>
                <option value="engagement">Engagement Report</option>
              </select>
            </label>
            <label class="field"><span>Month</span><select id="reportMonth"></select></label>
            <label class="field"><span>Department</span>
              <select id="reportDept">
                <option>All Departments</option>
                <option>DIT</option>
                <option>BAS</option>
                <option>NET</option>
              </select>
            </label>
          </div>
          <p class="muted" style="font-size:12px;">⚠ Department filtering isn't wired up yet — no department is tracked anywhere in the system, so this selector currently has no effect on the report below.</p>
        </article>
        <article class="panel">
          <h2>Report Summary</h2>
          <div class="report-summary">
            <div class="report-card"><span>Average Mood</span><strong id="rAvgMood">–</strong><small id="rAvgMoodChange"></small></div>
            <div class="report-card"><span title="Based on self-reported mood check-in averages — not a clinical risk assessment.">Elevated Concern ⓘ</span><strong id="rConcern">–</strong><small id="rConcernChange"></small></div>
            <div class="report-card"><span>Counselling Sessions</span><strong id="rSessions">–</strong><small id="rSessionsChange"></small></div>
          </div>
          <div class="inline" style="margin-top:18px">
            <button class="btn btn-purple" type="button" id="exportPdfBtn">Export as PDF</button>
            <button class="btn btn-light" type="button" id="exportCsvBtn">Export as CSV</button>
          </div>
        </article>
      </section>
    </main>
  </div>
  <script src="js/admin-reports.js"></script>
</body>
</html>
