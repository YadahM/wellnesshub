<?php require_once __DIR__ . '/counsellor-auth.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Student Overview — WellnessHub</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body class="app-body dark-body counsellor-body">
  <div class="app-shell dark-shell">
    <aside class="sidebar counsellor-sidebar">
      <a class="brand-mini sidebar-brand" href="index.php">
        <span class="mini-leaf" aria-hidden="true">☘</span>
        <span>WellnessHub</span>
      </a>

      <nav class="side-nav" aria-label="Counsellor navigation">
        <a href="counsellor-dashboard.php"><span>▣</span> Dashboard</a>
        <a class="active" href="counsellor-students.php"><span>👥</span> Students</a>
        <a href="risk-alerts.php"><span>⚠</span> Risk Alerts</a>
        <a href="counsellor-appointments.php"><span>📅</span> Appointments</a>
        <a href="counsellor-resources.php"><span>▤</span> Resources</a>
        <a href="logout.php"><span>↪</span> Logout</a>
      </nav>
    </aside>

    <main class="dashboard-main dark-main">
      <header class="topbar dark-topbar">
        <div>
          <p class="eyebrow">Counsellor Side</p>
          <h1>Student Overview</h1>
          <p class="page-subtitle">View student wellbeing summaries and follow-up status.</p>
        </div>
        <div class="topbar-actions">
          <a class="icon-btn dark-icon" href="risk-alerts.php" aria-label="Alerts">🔔</a>
          <div class="avatar dark-avatar"><?= htmlspecialchars(strtoupper(substr($_SESSION['full_name'], 0, 1))) ?></div>
        </div>
      </header>

      <section class="page-grid">
        <article class="panel">
          <div class="panel-heading">
            <h2>Students</h2>
            <input class="input-like" style="max-width:260px" id="studentSearch" placeholder="Search student..." />
          </div>
          <table class="data-table">
            <thead>
              <tr><th>Student</th><th>Mood</th><th>Risk</th><th>Last Check-in</th><th>Action</th></tr>
            </thead>
            <tbody id="studentsTableBody"></tbody>
          </table>
        </article>

        <article class="panel" id="noteEditor" style="display:none;">
          <h2 id="noteEditorTitle">Add follow-up note</h2>
          <input type="hidden" id="noteStudentId" value="" />
          <label class="field"><span>Note</span><textarea id="noteText" placeholder="Internal follow-up note..."></textarea></label>
          <button class="btn btn-blue btn-full" id="saveNoteBtn">Save Note</button>
        </article>
      </section>
    </main>
  </div>

  <script src="js/counsellor-students.js"></script>
</body>
</html>
