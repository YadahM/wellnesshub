<?php require_once __DIR__ . '/counsellor-auth.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Counsellor Appointment Calendar — WellnessHub</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body class="app-body dark-body counsellor-body">
  <div class="app-shell dark-shell">
    <aside class="sidebar counsellor-sidebar">
      <a class="brand-mini sidebar-brand" href="index.php">
        <span class="mini-leaf" aria-hidden="true">☘</span>
        <span>WellnessHub</span>
      </a>

      <nav class="side-nav" aria-label="Counsellor navigation">
        <a href="counsellor-dashboard.php"><span>▣</span> Dashboard</a>
        <a href="counsellor-students.php"><span>👥</span> Students</a>
        <a href="risk-alerts.php"><span>⚠</span> Risk Alerts</a>
        <a class="active" href="counsellor-appointments.php"><span>📅</span> Appointments</a>
        <a href="counsellor-resources.php"><span>▤</span> Resources</a>
        <a href="logout.php"><span>↪</span> Logout</a>
      </nav>
    </aside>

    <main class="dashboard-main dark-main">
      <header class="topbar dark-topbar">
        <div>
          <p class="eyebrow">Counsellor Side</p>
          <h1>Counsellor Appointment Calendar</h1>
          <p class="page-subtitle">Manage daily appointments and availability.</p>
        </div>
        <div class="topbar-actions">
          <a class="icon-btn dark-icon" href="risk-alerts.php" aria-label="Alerts">🔔</a>
          <div class="avatar dark-avatar"><?= htmlspecialchars(strtoupper(substr($_SESSION['full_name'], 0, 1))) ?></div>
        </div>
      </header>

      <section class="page-grid">
        <article class="panel">
          <div class="panel-heading">
            <h2 id="weekLabel">This Week</h2>
            <div class="inline">
              <button class="btn btn-ghost btn-small" id="prevWeekBtn">‹ Prev</button>
              <button class="btn btn-ghost btn-small" id="todayBtn">Today</button>
              <button class="btn btn-ghost btn-small" id="nextWeekBtn">Next ›</button>
            </div>
          </div>
          <div class="timeline-grid" id="timelineGrid"></div>
        </article>
      </section>
    </main>
  </div>

  <script src="js/counsellor-appointments.js"></script>
</body>
</html>
