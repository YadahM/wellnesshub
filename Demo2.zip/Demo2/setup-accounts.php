<?php
require_once __DIR__ . '/demoDB.php';

$admin = [
    'full_name' => 'WellnessHub Administrator',
    'email'     => 'Admin@Richfield.ac.za',
    'password'  => 'Password1',
];

$counsellors = [
    [
        'full_name' => 'Dr. Naidoo',
        'email'     => 'naidoo@richfield.ac.za',
        'password'  => '12345678',
    ],
];

function upsertStaffAccount(PDO $pdo, string $fullName, string $email, string $password, string $role): void {
    $hash = password_hash($password, PASSWORD_BCRYPT);

    $stmt = $pdo->prepare('
        INSERT INTO users (full_name, student_number, email, password_hash, role)
        VALUES (:full_name, NULL, :email, :password_hash, :role)
        ON DUPLICATE KEY UPDATE
            full_name = VALUES(full_name),
            password_hash = VALUES(password_hash),
            role = VALUES(role)
    ');
    $stmt->execute([
        ':full_name'     => $fullName,
        ':email'         => $email,
        ':password_hash' => $hash,
        ':role'          => $role,
    ]);
}

$results = [];

upsertStaffAccount($pdo, $admin['full_name'], $admin['email'], $admin['password'], 'admin');
$results[] = "Admin account ready: {$admin['email']}";

foreach ($counsellors as $c) {
    upsertStaffAccount($pdo, $c['full_name'], $c['email'], $c['password'], 'counsellor');
    $results[] = "Counsellor account ready: {$c['email']}";
}

$isCli = (php_sapi_name() === 'cli');
$output = "Done.\n" . implode("\n", $results) . "\nRemember to delete setup-accounts.php now.\n";

if ($isCli) {
    echo $output;
} else {
    header('Content-Type: text/plain');
    echo $output;
}
