const MOOD_SCORE_MAX = 5;

document.addEventListener('DOMContentLoaded', async () => {
  try {
    const res = await fetch('api/demoAPI.php?action=counsellor_dashboard_stats');
    const data = await res.json();
    if (!data.success) {
      console.error(data.message);
      return;
    }
    renderKpis(data.data);
    renderMoodTrend(data.data.mood_trend);
    renderMoodDistribution(data.data.mood_distribution);
  } catch (err) {
    console.error('Failed to load dashboard stats', err);
  }
});

function renderKpis(stats) {
  document.getElementById('kpiCheckins').textContent = stats.students_checked_in_today;
  document.getElementById('kpiHighRisk').textContent = stats.high_risk_students;
  document.getElementById('kpiAppointments').textContent = stats.appointments_today;
  document.getElementById('kpiResolved').textContent = stats.resolved_alerts_week;
}

function renderMoodTrend(trend) {
  const chartWidth = 420, left = 30, right = 390, top = 20, bottom = 150;
  const line = document.getElementById('moodTrendLine');
  const dots = document.getElementById('moodTrendDots');
  dots.innerHTML = '';

  if (!trend || trend.length === 0) {
    line.setAttribute('points', '');
    return;
  }

  const step = trend.length > 1 ? (right - left) / (trend.length - 1) : 0;
  const points = trend.map((row, i) => {
    const score = parseFloat(row.avg_score) || 0;
    const x = left + step * i;
    const y = bottom - ((score / MOOD_SCORE_MAX) * (bottom - top));
    return { x, y };
  });

  line.setAttribute('points', points.map((p) => `${p.x},${p.y}`).join(' '));

  points.forEach((p) => {
    const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    circle.setAttribute('class', 'chart-dot');
    circle.setAttribute('cx', p.x);
    circle.setAttribute('cy', p.y);
    circle.setAttribute('r', 5);
    dots.appendChild(circle);
  });
}

function renderMoodDistribution(dist) {
  const positive = dist.positive || 0;
  const neutral = dist.neutral || 0;
  const low = dist.low || 0;

  const posEnd = positive;
  const neuEnd = posEnd + neutral;

  const donut = document.getElementById('moodDonut');
  donut.style.background =
    `conic-gradient(#57a66f 0% ${posEnd}%, #4a7fd9 ${posEnd}% ${neuEnd}%, #f36d6d ${neuEnd}% 100%)`;

  document.getElementById('legendPositive').textContent = `${positive}% Positive`;
  document.getElementById('legendNeutral').textContent = `${neutral}% Neutral`;
  document.getElementById('legendLow').textContent = `${low}% Low`;
}
