document.addEventListener('DOMContentLoaded', () => {
  loadAlerts();

  document.getElementById('refreshBtn').addEventListener('click', (e) => {
    e.preventDefault();
    loadAlerts();
  });

  document.getElementById('markInProgressBtn').addEventListener('click', () => updateSelectedAlert('in_progress'));
  document.getElementById('resolveBtn').addEventListener('click', () => updateSelectedAlert('resolved'));
});

async function loadAlerts() {
  try {
    const res = await fetch('api/demoAPI.php?action=risk_alerts_list');
    const data = await res.json();
    if (!data.success) {
      console.error(data.message);
      return;
    }
    renderAlerts(data.data.alerts);
  } catch (err) {
    console.error('Failed to load risk alerts', err);
  }
}

function renderAlerts(alerts) {
  const list = document.getElementById('riskList');
  const empty = document.getElementById('riskEmpty');
  document.getElementById('alertCount').textContent = alerts.length;

  list.querySelectorAll('.risk-item').forEach((el) => el.remove());

  if (alerts.length === 0) {
    empty.style.display = 'block';
    clearSelection();
    return;
  }
  empty.style.display = 'none';

  alerts.forEach((alert) => {
    const item = document.createElement('div');
    item.className = 'risk-item';
    item.dataset.alertId = alert.alert_id;

    const severityPill = alert.severity === 'high'
      ? '<span class="pill pill-red">High</span>'
      : '<span class="pill pill-orange">Medium</span>';
    const statusPill = alert.status === 'in_progress'
      ? '<span class="pill pill-blue">In Progress</span>'
      : '<span class="pill pill-purple">Open</span>';

    item.innerHTML = `
      <div>
        <h3>Student: ${escapeHtml(alert.student_name)}</h3>
        <p class="risk-score">${severityPill} ${statusPill}</p>
        <p>${escapeHtml(alert.reason)}</p>
      </div>
      <div class="risk-actions">
        <button class="btn btn-ghost btn-small select-alert-btn" type="button">Review</button>
      </div>
    `;
    item.querySelector('.select-alert-btn').addEventListener('click', () => selectAlert(alert));
    list.appendChild(item);
  });
}

function selectAlert(alert) {
  document.getElementById('selectedAlertId').value = alert.alert_id;
  document.getElementById('selectedStudentLabel').textContent =
    `Acting on: ${alert.student_name} — ${alert.reason}`;
  document.getElementById('actionNote').value = alert.note || '';
  document.getElementById('markInProgressBtn').disabled = false;
  document.getElementById('resolveBtn').disabled = false;

  document.querySelectorAll('.risk-item').forEach((el) => {
    el.style.outline = el.dataset.alertId == alert.alert_id ? '2px solid #4a7fd9' : 'none';
  });
}

function clearSelection() {
  document.getElementById('selectedAlertId').value = '';
  document.getElementById('selectedStudentLabel').textContent = 'Select an alert on the left to act on it.';
  document.getElementById('actionNote').value = '';
  document.getElementById('markInProgressBtn').disabled = true;
  document.getElementById('resolveBtn').disabled = true;
}

async function updateSelectedAlert(status) {
  const alertId = document.getElementById('selectedAlertId').value;
  if (!alertId) return;

  const formData = new FormData();
  formData.append('alert_id', alertId);
  formData.append('status', status);
  formData.append('note', document.getElementById('actionNote').value);

  try {
    const res = await fetch('api/demoAPI.php?action=risk_alert_update', { method: 'POST', body: formData });
    const data = await res.json();
    if (!data.success) {
      alert(data.message);
      return;
    }
    clearSelection();
    loadAlerts();
  } catch (err) {
    console.error('Failed to update alert', err);
  }
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}
