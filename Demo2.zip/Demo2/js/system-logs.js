// system-logs.js — loaded by system-logs.php

const ACTION_META = {
  login_success: { icon: '🔐', label: 'Login successful' },
  login_failed: { icon: '⚠', label: 'Failed login attempt' },
  user_created: { icon: '👤', label: 'User account created' },
  user_updated: { icon: '✎', label: 'User account updated' },
  counsellor_created: { icon: '♡', label: 'Counsellor account created' },
  report_exported: { icon: '📊', label: 'Report exported' },
};

function timeAgo(mysqlDatetime) {
  const then = new Date(mysqlDatetime.replace(' ', 'T'));
  const diffMs = Date.now() - then.getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return mins + 'm ago';
  const hours = Math.floor(mins / 60);
  if (hours < 24) return hours + 'h ago';
  const days = Math.floor(hours / 24);
  if (days < 7) return days + 'd ago';
  return then.toLocaleDateString('default', { day: 'numeric', month: 'short', year: 'numeric' });
}

function logEntryEl(log) {
  const meta = ACTION_META[log.action] || { icon: '📋', label: log.action };
  const el = document.createElement('div');
  el.className = 'notice';

  const icon = document.createElement('span');
  icon.className = 'notice-icon';
  icon.textContent = meta.icon;

  const textWrap = document.createElement('div');
  const strong = document.createElement('strong');
  strong.textContent = meta.label;
  const p = document.createElement('p');
  p.className = 'muted';
  p.textContent = (log.actor_name ? log.actor_name + ' — ' : '') + (log.details || '');
  textWrap.appendChild(strong);
  textWrap.appendChild(p);

  const time = document.createElement('span');
  time.textContent = timeAgo(log.created_at);

  el.appendChild(icon);
  el.appendChild(textWrap);
  el.appendChild(time);
  return el;
}

async function loadLogs() {
  const list = document.getElementById('logList');
  try {
    const res = await fetch('api/demoAPI.php?action=admin_log_list');
    const data = await res.json();
    list.innerHTML = '';

    if (!data.success) {
      list.innerHTML = `<p class="muted">${data.message}</p>`;
      return;
    }
    if (data.data.logs.length === 0) {
      list.innerHTML = '<p class="muted">No activity recorded yet.</p>';
      return;
    }
    data.data.logs.forEach(log => list.appendChild(logEntryEl(log)));
  } catch (err) {
    list.innerHTML = '<p class="muted">Could not reach the server.</p>';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadLogs();

  document.getElementById('exportLogsBtn').addEventListener('click', () => {
    window.location.href = 'api/demoAPI.php?action=admin_log_export_csv';
  });
});
