// student forgot password js
document.addEventListener("DOMContentLoaded", () => {

    // =============================================
    // PAGE ELEMENTS
    // =============================================

    const emailStep =
        document.getElementById("emailStep");

    const codeStep =
        document.getElementById("codeStep");

    const passwordStep =
        document.getElementById("passwordStep");

    const successStep =
        document.getElementById("successStep");


    const forgotEmailForm =
        document.getElementById("forgotEmailForm");

    const verificationForm =
        document.getElementById("verificationForm");

    const newPasswordForm =
        document.getElementById("newPasswordForm");


    const resetEmail =
        document.getElementById("resetEmail");

    const verificationCode =
        document.getElementById("verificationCode");

    const newPassword =
        document.getElementById("newPassword");

    const confirmPassword =
        document.getElementById("confirmPassword");


    const emailMessage =
        document.getElementById("emailMessage");

    const codeMessage =
        document.getElementById("codeMessage");

    const passwordMessage =
        document.getElementById("passwordMessage");


    const resendButton =
        document.getElementById("resendCode");

    const backToEmailButton =
        document.getElementById("backToEmail");


    // (Prototype hardcoded DEMO_CODE removed — verification now goes
    // through the real forgot_password_verify/reset endpoints instead.)


    // =============================================
    // SWITCH BETWEEN STEPS
    // =============================================

    function showStep(step) {

        const steps = [
            emailStep,
            codeStep,
            passwordStep,
            successStep
        ];

        steps.forEach(item => {
            item.classList.remove("active-step");
        });

        step.classList.add("active-step");

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    }


    // =============================================
    // SHOW MESSAGE
    // =============================================

    function showMessage(
        element,
        text,
        type
    ) {

        element.textContent = text;

        element.classList.remove(
            "error",
            "success"
        );

        element.classList.add(type);
    }


    // =============================================
    // CLEAR MESSAGE
    // =============================================

    function clearMessage(element) {

        element.textContent = "";

        element.classList.remove(
            "error",
            "success"
        );
    }


    // =============================================
    // EMAIL VALIDATION
    // =============================================

    function validEmail(email) {

        const pattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        return pattern.test(email);
    }


    // =============================================
    // STEP 1 - EMAIL
    // =============================================

    forgotEmailForm.addEventListener(
        "submit",
        async event => {

            event.preventDefault();

            clearMessage(emailMessage);

            const email =
                resetEmail.value
                    .trim()
                    .toLowerCase();


            if (!email) {

                showMessage(
                    emailMessage,
                    "Please enter your counsellor email address.",
                    "error"
                );

                return;
            }


            if (!validEmail(email)) {

                showMessage(
                    emailMessage,
                    "Please enter a valid email address.",
                    "error"
                );

                return;
            }

            try {
                const res = await fetch('api/demoAPI.php?action=forgot_password_request', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({ email: email }),
                });
                const data = await res.json();

                if (!data.success) {
                    showMessage(emailMessage, data.message, "error");
                    return;
                }

                // Save email for the later verify/reset steps (not the
                // password itself — that's never stored client-side now).
                sessionStorage.setItem(
                    "passwordResetEmail",
                    email
                );

                // dev_code only ever appears when the server detected a
                // localhost request — see the note in demoAPI.php. There is
                // no real email system, so this is the only way to see the
                // code during local testing.
                const devNote = data.data && data.data.dev_code
                    ? ` (dev mode — code: ${data.data.dev_code})`
                    : '';

                showMessage(
                    emailMessage,
                    "If that account exists, a verification code has been sent." + devNote,
                    "success"
                );

                setTimeout(() => {

                    showStep(codeStep);

                    verificationCode.focus();

                }, 700);
            } catch (err) {
                showMessage(emailMessage, "Could not reach the server.", "error");
            }

        }
    );


    // =============================================
    // ONLY ALLOW NUMBERS IN CODE FIELD
    // =============================================

    verificationCode.addEventListener(
        "input",
        () => {

            verificationCode.value =
                verificationCode.value
                    .replace(/\D/g, "")
                    .slice(0, 6);

        }
    );


    // =============================================
    // STEP 2 - VERIFY CODE
    // =============================================

    verificationForm.addEventListener(
        "submit",
        async event => {

            event.preventDefault();

            clearMessage(codeMessage);

            const enteredCode =
                verificationCode.value.trim();


            if (enteredCode.length !== 6) {

                showMessage(
                    codeMessage,
                    "Please enter the complete 6-digit code.",
                    "error"
                );

                return;
            }

            const email = sessionStorage.getItem("passwordResetEmail");

            try {
                const res = await fetch('api/demoAPI.php?action=forgot_password_verify', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({ email: email, code: enteredCode }),
                });
                const data = await res.json();

                if (!data.success) {
                    showMessage(codeMessage, data.message, "error");
                    return;
                }

                showMessage(
                    codeMessage,
                    "Account verified successfully.",
                    "success"
                );


                setTimeout(() => {

                    showStep(passwordStep);

                    newPassword.focus();

                }, 600);
            } catch (err) {
                showMessage(codeMessage, "Could not reach the server.", "error");
            }

        }
    );


    // =============================================
    // RESEND CODE
    // =============================================

    resendButton.addEventListener(
        "click",
        async () => {

            const email = sessionStorage.getItem("passwordResetEmail");
            if (!email) return;

            try {
                const res = await fetch('api/demoAPI.php?action=forgot_password_request', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({ email: email }),
                });
                const data = await res.json();

                const devNote = data.data && data.data.dev_code
                    ? ` (dev mode — code: ${data.data.dev_code})`
                    : '';

                showMessage(
                    codeMessage,
                    "A new verification code has been sent." + devNote,
                    "success"
                );
            } catch (err) {
                showMessage(codeMessage, "Could not reach the server.", "error");
            }

        }
    );


    // =============================================
    // CHANGE EMAIL
    // =============================================

    backToEmailButton.addEventListener(
        "click",
        () => {

            verificationCode.value = "";

            clearMessage(codeMessage);

            showStep(emailStep);

            resetEmail.focus();

        }
    );


    // =============================================
    // PASSWORD SHOW / HIDE
    // =============================================

    const passwordToggleButtons =
        document.querySelectorAll(
            ".password-toggle"
        );


    passwordToggleButtons.forEach(
        button => {

            button.addEventListener(
                "click",
                () => {

                    const input =
                        button.parentElement
                            .querySelector("input");


                    if (input.type === "password") {

                        input.type = "text";

                        button.textContent = "◉";

                    } else {

                        input.type = "password";

                        button.textContent = "◎";

                    }

                }
            );

        }
    );


    // =============================================
    // PASSWORD REQUIREMENTS
    // =============================================

    const lengthRequirement =
        document.getElementById(
            "lengthRequirement"
        );

    const numberRequirement =
        document.getElementById(
            "numberRequirement"
        );

    const capitalRequirement =
        document.getElementById(
            "capitalRequirement"
        );


    newPassword.addEventListener(
        "input",
        () => {

            const password =
                newPassword.value;


            // At least 8 characters
            updateRequirement(
                lengthRequirement,
                password.length >= 8,
                "At least 8 characters"
            );


            // Contains number
            updateRequirement(
                numberRequirement,
                /\d/.test(password),
                "At least one number"
            );


            // Contains uppercase letter
            updateRequirement(
                capitalRequirement,
                /[A-Z]/.test(password),
                "At least one uppercase letter"
            );

        }
    );


    function updateRequirement(
        element,
        valid,
        text
    ) {

        if (valid) {

            element.classList.add("valid");

            element.textContent =
                "✓ " + text;

        } else {

            element.classList.remove("valid");

            element.textContent =
                "○ " + text;

        }

    }


    // =============================================
    // STEP 3 - RESET PASSWORD
    // =============================================

    newPasswordForm.addEventListener(
        "submit",
        async event => {

            event.preventDefault();

            clearMessage(passwordMessage);


            const password =
                newPassword.value;

            const confirm =
                confirmPassword.value;


            // Check length
            if (password.length < 8) {

                showMessage(
                    passwordMessage,
                    "Password must contain at least 8 characters.",
                    "error"
                );

                return;
            }


            // Check uppercase
            if (!/[A-Z]/.test(password)) {

                showMessage(
                    passwordMessage,
                    "Password must contain an uppercase letter.",
                    "error"
                );

                return;
            }


            // Check number
            if (!/\d/.test(password)) {

                showMessage(
                    passwordMessage,
                    "Password must contain at least one number.",
                    "error"
                );

                return;
            }


            // Passwords match
            if (password !== confirm) {

                showMessage(
                    passwordMessage,
                    "The passwords do not match.",
                    "error"
                );

                return;
            }


            const email =
                sessionStorage.getItem(
                    "passwordResetEmail"
                );

            const code =
                verificationCode.value.trim();

            try {
                const res = await fetch('api/demoAPI.php?action=forgot_password_reset', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({ email: email, code: code, new_password: password }),
                });
                const data = await res.json();

                if (!data.success) {
                    showMessage(passwordMessage, data.message, "error");
                    return;
                }

                // Remove temporary reset data
                sessionStorage.removeItem(
                    "passwordResetEmail"
                );

                // Show success screen
                showStep(successStep);
            } catch (err) {
                showMessage(passwordMessage, "Could not reach the server.", "error");
            }

        }
    );

});