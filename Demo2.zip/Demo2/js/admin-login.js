function setBanner(type, message) {
  var banner = document.getElementById('formBanner');
  banner.className = 'banner ' + type;
  banner.textContent = message;
}

function clearBanner() {
  var banner = document.getElementById('formBanner');
  banner.className = 'banner';
  banner.textContent = '';
}

document.getElementById('adminLoginForm').addEventListener('submit', function (event) {
  event.preventDefault();
  clearBanner();

  var submitBtn = document.getElementById('submitBtn');
  submitBtn.disabled = true;
  submitBtn.textContent = 'Logging in...';

  var formData = new FormData(document.getElementById('adminLoginForm'));

  fetch('api/demoAPI.php?action=admin_login', {
    method: 'POST',
    body: formData
  })
    .then(function (res) { return res.json(); })
    .then(function (data) {
      if (data.success) {
        setBanner('success', data.message);
        window.location.href = data.data && data.data.redirect ? data.data.redirect : 'admin-dashboard.php';
      } else {
        setBanner('error', data.message);
        submitBtn.disabled = false;
        submitBtn.textContent = 'Login';
      }
    })
    .catch(function () {
      setBanner('error', 'Something went wrong. Please try again.');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Login';
    });
});
