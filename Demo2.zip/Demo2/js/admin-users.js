// admin-users.js — loaded by admin-users.php

let allUsers = [];

function formatLastLogin(datetime) {
  if (!datetime) return 'Never';
  const d = new Date(datetime.replace(' ', 'T'));
  const today = new Date();
  const isToday = d.toDateString() === today.toDateString();
  if (isToday) return 'Today';
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
  return d.toLocaleDateString('default', { day: 'numeric', month: 'short', year: 'numeric' });
}

function statusPill(isActive) {
  return isActive
    ? '<span class="pill pill-green">Active</span>'
    : '<span class="pill pill-red">Suspended</span>';
}

function roleLabel(role) {
  return role.charAt(0).toUpperCase() + role.slice(1);
}

function renderUsers(users) {
  const tbody = document.getElementById('usersTableBody');
  tbody.innerHTML = '';

  if (users.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" class="muted">No users found.</td></tr>';
    return;
  }

  users.forEach(u => {
    const tr = document.createElement('tr');

    const nameTd = document.createElement('td');
    nameTd.textContent = u.full_name;

    const roleTd = document.createElement('td');
    roleTd.textContent = roleLabel(u.role);

    const statusTd = document.createElement('td');
    statusTd.innerHTML = statusPill(u.is_active);

    const lastLoginTd = document.createElement('td');
    lastLoginTd.textContent = formatLastLogin(u.last_login_at);

    const actionTd = document.createElement('td');
    const editBtn = document.createElement('button');
    editBtn.className = 'btn btn-ghost btn-small';
    editBtn.textContent = 'Edit';
    editBtn.addEventListener('click', () => openEditModal(u));
    actionTd.appendChild(editBtn);

    tr.appendChild(nameTd);
    tr.appendChild(roleTd);
    tr.appendChild(statusTd);
    tr.appendChild(lastLoginTd);
    tr.appendChild(actionTd);
    tbody.appendChild(tr);
  });
}

async function loadUsers(query) {
  const tbody = document.getElementById('usersTableBody');
  tbody.innerHTML = '<tr><td colspan="5" class="muted">Loading users…</td></tr>';

  try {
    const url = 'api/demoAPI.php?action=admin_user_list' + (query ? '&q=' + encodeURIComponent(query) : '');
    const res = await fetch(url);
    const data = await res.json();

    if (!data.success) {
      tbody.innerHTML = `<tr><td colspan="5" class="muted">${data.message}</td></tr>`;
      return;
    }
    allUsers = data.data.users;
    renderUsers(allUsers);
  } catch (err) {
    tbody.innerHTML = '<tr><td colspan="5" class="muted">Could not reach the server.</td></tr>';
  }
}

// --- Add User modal ---
function toggleStudentField() {
  const isStudent = document.getElementById('newRole').value === 'student';
  document.getElementById('studentNumberField').style.display = isStudent ? '' : 'none';
  document.getElementById('newUserHint').textContent = isStudent
    ? 'Student email must be studentnumber@my.richfield.ac.za'
    : document.getElementById('newRole').value === 'counsellor'
      ? 'Counsellor email must end in @richfield.ac.za, password must start with "123"'
      : '';
}

function openAddModal() {
  document.getElementById('newFullName').value = '';
  document.getElementById('newRole').value = 'student';
  document.getElementById('newStudentNumber').value = '';
  document.getElementById('newEmail').value = '';
  document.getElementById('newPassword').value = '';
  document.getElementById('addUserMessage').textContent = '';
  toggleStudentField();
  document.getElementById('addUserModal').style.display = 'flex';
}

async function submitAddUser() {
  const msg = document.getElementById('addUserMessage');
  msg.className = 'forgot-message';
  msg.textContent = '';

  const body = new URLSearchParams({
    full_name: document.getElementById('newFullName').value.trim(),
    role: document.getElementById('newRole').value,
    student_number: document.getElementById('newStudentNumber').value.trim(),
    email: document.getElementById('newEmail').value.trim(),
    password: document.getElementById('newPassword').value,
  });

  try {
    const res = await fetch('api/demoAPI.php?action=admin_user_create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
    });
    const data = await res.json();

    if (!data.success) {
      msg.classList.add('error');
      msg.textContent = data.message;
      return;
    }

    document.getElementById('addUserModal').style.display = 'none';
    loadUsers(document.getElementById('userSearch').value.trim());
  } catch (err) {
    msg.classList.add('error');
    msg.textContent = 'Could not reach the server.';
  }
}

// --- Edit User modal ---
let editingUserId = null;

function openEditModal(user) {
  editingUserId = user.user_id;
  document.getElementById('editUserName').textContent = `${user.full_name} (${user.email})`;
  document.getElementById('editRole').value = user.role;
  document.getElementById('editActive').value = user.is_active ? '1' : '0';
  document.getElementById('editUserMessage').textContent = '';
  document.getElementById('editUserModal').style.display = 'flex';
}

async function submitEditUser() {
  const msg = document.getElementById('editUserMessage');
  msg.className = 'forgot-message';
  msg.textContent = '';

  const body = new URLSearchParams({
    user_id: editingUserId,
    role: document.getElementById('editRole').value,
    is_active: document.getElementById('editActive').value,
  });

  try {
    const res = await fetch('api/demoAPI.php?action=admin_user_update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
    });
    const data = await res.json();

    if (!data.success) {
      msg.classList.add('error');
      msg.textContent = data.message;
      return;
    }

    document.getElementById('editUserModal').style.display = 'none';
    loadUsers(document.getElementById('userSearch').value.trim());
  } catch (err) {
    msg.classList.add('error');
    msg.textContent = 'Could not reach the server.';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadUsers('');

  let searchTimer;
  document.getElementById('userSearch').addEventListener('input', (e) => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => loadUsers(e.target.value.trim()), 300);
  });

  document.getElementById('addUserBtn').addEventListener('click', openAddModal);
  document.getElementById('cancelAddUser').addEventListener('click', () => {
    document.getElementById('addUserModal').style.display = 'none';
  });
  document.getElementById('submitAddUser').addEventListener('click', submitAddUser);
  document.getElementById('newRole').addEventListener('change', toggleStudentField);

  document.getElementById('cancelEditUser').addEventListener('click', () => {
    document.getElementById('editUserModal').style.display = 'none';
  });
  document.getElementById('submitEditUser').addEventListener('click', submitEditUser);
});
