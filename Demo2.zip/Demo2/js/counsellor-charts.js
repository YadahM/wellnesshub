const MOOD_LABELS = ['Great', 'Good', 'Okay', 'Low', 'Struggling'];
const MOOD_KEYS = ['great', 'good', 'okay', 'low', 'struggling'];
const MOOD_COLOURS = ['#2f744d', '#57a66f', '#4a7fd9', '#f2a65a', '#f36d6d'];

let indexChart = null;
let distributionChart = null;

document.addEventListener('DOMContentLoaded', loadAggregate);

async function loadAggregate() {
  if (typeof Chart === 'undefined') {
    console.error('Chart.js is missing. Place chart.umd.min.js in js/vendor/.');
    return;
  }

  Chart.defaults.color = '#c9d4e5';

  try {
    const res = await fetch('api/demoAPI.php?action=emotional_index_aggregate&days=7');
    const data = await res.json();
    if (!data.success) {
      console.error(data.message);
      return;
    }
    drawIndexChart(data.data);
    drawDistributionChart(data.data.distribution);
  } catch (err) {
    console.error('Failed to load aggregate data', err);
  }
}

function drawIndexChart(agg) {
  if (indexChart) indexChart.destroy();
  indexChart = new Chart(document.getElementById('emotionalIndexChart'), {
    type: 'line',
    data: {
      labels: agg.labels,
      datasets: [{
        label: 'Average emotional index (1-5)',
        data: agg.emotional_index,
        borderColor: '#4a7fd9',
        backgroundColor: 'rgba(74,127,217,0.15)',
        fill: true,
        tension: 0.3,
        pointRadius: 4,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: { y: { min: 1, max: 5, ticks: { stepSize: 1 } } },
    },
  });
}

function drawDistributionChart(distribution) {
  if (distributionChart) distributionChart.destroy();
  distributionChart = new Chart(document.getElementById('moodDistributionChart'), {
    type: 'doughnut',
    data: {
      labels: MOOD_LABELS,
      datasets: [{
        data: MOOD_KEYS.map((key) => distribution[key] || 0),
        backgroundColor: MOOD_COLOURS,
        borderWidth: 0,
      }],
    },
    options: { responsive: true, maintainAspectRatio: false },
  });
}
