const CRISIS_STYLES = `
.crisis-overlay{position:fixed;inset:0;z-index:9999;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,0.88);padding:20px;}
.crisis-overlay.is-open{display:flex;}
.crisis-dialog{max-width:480px;width:100%;background:#000000;color:#ffffff;border:4px solid #ffd400;border-radius:18px;padding:28px;text-align:center;}
.crisis-dialog h2{margin:0 0 12px;font-size:26px;color:#ffd400;}
.crisis-dialog p{margin:0 0 20px;font-size:17px;line-height:1.5;color:#ffffff;}
.crisis-btn{display:block;width:100%;box-sizing:border-box;margin-top:12px;padding:14px 16px;border-radius:12px;border:3px solid #ffffff;font-size:17px;font-weight:800;text-align:center;text-decoration:none;cursor:pointer;}
.crisis-call{background:#ffd400;color:#000000;border-color:#ffd400;}
.crisis-book{background:#ffffff;color:#000000;}
.crisis-close{background:#000000;color:#ffffff;}
.crisis-btn:focus{outline:4px solid #ffffff;outline-offset:3px;}
`;

function buildCrisisModal() {
  if (document.getElementById('crisisModal')) return;

  const style = document.createElement('style');
  style.textContent = CRISIS_STYLES;
  document.head.appendChild(style);

  const overlay = document.createElement('div');
  overlay.className = 'crisis-overlay';
  overlay.id = 'crisisModal';
  overlay.setAttribute('role', 'alertdialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.setAttribute('aria-labelledby', 'crisisTitle');
  overlay.setAttribute('aria-hidden', 'true');
  overlay.innerHTML = `
    <div class="crisis-dialog">
      <h2 id="crisisTitle">You are not alone</h2>
      <p>What you wrote suggests you may be going through something very hard. Please reach out to someone right now.</p>
      <a class="crisis-btn crisis-call" href="tel:0800567567">Call SADAG 24/7 Helpline: 0800 567 567</a>
      <a class="crisis-btn crisis-book" href="counselling-booking.php">Contact campus counselling</a>
      <button type="button" class="crisis-btn crisis-close" id="crisisCloseBtn">I understand, close</button>
    </div>
  `;
  document.body.appendChild(overlay);

  overlay.querySelector('#crisisCloseBtn').addEventListener('click', hideCrisisModal);
}

function showCrisisModal() {
  buildCrisisModal();
  const modal = document.getElementById('crisisModal');
  modal.classList.add('is-open');
  modal.setAttribute('aria-hidden', 'false');
  document.getElementById('crisisCloseBtn').focus();
}

function hideCrisisModal() {
  const modal = document.getElementById('crisisModal');
  if (!modal) return;
  modal.classList.remove('is-open');
  modal.setAttribute('aria-hidden', 'true');
}

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') hideCrisisModal();
});

const nativeFetch = window.fetch.bind(window);
window.fetch = async (...args) => {
  const response = await nativeFetch(...args);
  const target = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) || '';

  if (target.includes('action=journal_create')) {
    response.clone().json().then((data) => {
      if (data && data.success && data.data && data.data.crisis_alert) {
        showCrisisModal();
      }
    }).catch(() => {});
  }

  return response;
};
