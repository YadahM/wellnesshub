// profile.js — loaded by profile.php

const MAX_PICTURE_BYTES = 2 * 1024 * 1024; // 2MB, same limit as journal photos

function renderAvatar(fullName, profilePicture) {
  const el = document.getElementById('avatarPreview');
  const removeBtn = document.getElementById('removeBtn');

  if (profilePicture) {
    el.innerHTML = '';
    el.style.backgroundImage = `url("${profilePicture}")`;
    el.style.backgroundSize = 'cover';
    el.style.backgroundPosition = 'center';
    removeBtn.style.display = '';
  } else {
    el.style.backgroundImage = 'none';
    el.textContent = fullName.trim().charAt(0).toUpperCase();
    removeBtn.style.display = 'none';
  }
}

async function loadProfile() {
  try {
    const res = await fetch('api/demoAPI.php?action=profile_get');
    const data = await res.json();
    if (!data.success) {
      alert(data.message);
      return;
    }
    const p = data.data;
    document.getElementById('profileFullName').textContent = p.full_name;
    document.getElementById('profileStudentNumber').textContent = p.student_number || '—';
    document.getElementById('profileEmail').textContent = p.email;
    renderAvatar(p.full_name, p.profile_picture);
  } catch (err) {
    alert('Could not reach the server.');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadProfile();

  const fileInput = document.getElementById('pictureInput');
  const msg = document.getElementById('pictureMessage');

  document.getElementById('uploadBtn').addEventListener('click', () => fileInput.click());

  fileInput.addEventListener('change', () => {
    const file = fileInput.files[0];
    if (!file) return;

    msg.className = 'profile-message';
    msg.textContent = '';

    if (!file.type.startsWith('image/')) {
      msg.classList.add('error');
      msg.textContent = 'Please choose an image file.';
      fileInput.value = '';
      return;
    }
    if (file.size > MAX_PICTURE_BYTES) {
      msg.classList.add('error');
      msg.textContent = 'Image is too large — please choose one under 2MB.';
      fileInput.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const res = await fetch('api/demoAPI.php?action=profile_picture_upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({ image: reader.result }),
        });
        const data = await res.json();
        if (!data.success) {
          msg.classList.add('error');
          msg.textContent = data.message;
          return;
        }
        msg.classList.add('success');
        msg.textContent = 'Profile picture updated.';
        renderAvatar(document.getElementById('profileFullName').textContent, reader.result);
      } catch (err) {
        msg.classList.add('error');
        msg.textContent = 'Could not reach the server.';
      } finally {
        fileInput.value = '';
      }
    };
    reader.onerror = () => {
      msg.classList.add('error');
      msg.textContent = 'Could not read that image.';
      fileInput.value = '';
    };
    reader.readAsDataURL(file);
  });

  document.getElementById('removeBtn').addEventListener('click', async () => {
    if (!confirm('Remove your profile picture?')) return;
    try {
      const res = await fetch('api/demoAPI.php?action=profile_picture_remove', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        renderAvatar(document.getElementById('profileFullName').textContent, null);
        msg.className = 'profile-message success';
        msg.textContent = 'Profile picture removed.';
      } else {
        alert(data.message);
      }
    } catch (err) {
      alert('Could not reach the server.');
    }
  });
});
