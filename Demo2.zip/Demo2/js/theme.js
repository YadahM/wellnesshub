// theme.js — included on every student page. Applies dark mode by reusing
// the .dark-body/.dark-shell/.dark-main/.dark-icon/.dark-avatar classes
// already built for the counsellor side (see css/style.css) — this just
// makes them toggleable instead of hardcoded to one set of pages.

(function () {
  function applyTheme(isDark) {
    document.body.classList.toggle('dark-body', isDark);
    const shell = document.querySelector('.app-shell');
    if (shell) shell.classList.toggle('dark-shell', isDark);
    const main = document.querySelector('.dashboard-main');
    if (main) main.classList.toggle('dark-main', isDark);
    document.querySelectorAll('.icon-btn').forEach(el => el.classList.toggle('dark-icon', isDark));
    document.querySelectorAll('.avatar').forEach(el => el.classList.toggle('dark-avatar', isDark));
  }

  // Reveals the page once theming is actually resolved. Called only from
  // the authoritative DOMContentLoaded pass below (or its timeout
  // fallback) — never from the early fast-path call, since at that point
  // .app-shell/.dashboard-main don't exist in the DOM yet (this script
  // runs before them), so revealing now would show a half-styled page:
  // dark body, still-light sidebar and panels. That half-second
  // inconsistency was the actual flash being reported.
  let revealed = false;
  function revealBody() {
    if (revealed) return;
    revealed = true;
    document.documentElement.classList.remove('theme-pending-dark');
    document.body.style.visibility = '';
  }

  // Fast path: apply a cached preference immediately. This alone can't
  // prevent the flash (see above) — the real fix is the <html> being
  // hidden via the inline head script until revealBody() runs — but it
  // means if the safety timeout below ever fires, the fallback shown is
  // "probably dark" rather than plain light.
  if (localStorage.getItem('wellnesshub_dark_mode') === '1') {
    applyTheme(true);
  }

  // Safety net: never leave the page blank indefinitely if the network
  // request below is slow or fails to fire for some reason.
  const timeoutId = setTimeout(revealBody, 1500);

  // Authoritative source is always the DB setting, fetched on every load.
  document.addEventListener('DOMContentLoaded', async () => {
    try {
      const res = await fetch('api/demoAPI.php?action=settings_get');
      const data = await res.json();
      if (data.success) {
        applyTheme(data.data.dark_mode);
        localStorage.setItem('wellnesshub_dark_mode', data.data.dark_mode ? '1' : '0');
      }
    } catch (err) {
      // Fail silently — cached/light theme stays as-is.
    } finally {
      clearTimeout(timeoutId);
      revealBody();
    }
  });

  // Exposed so settings.php can flip the theme instantly on toggle, without
  // waiting for a page reload.
  window.WellnessHubTheme = { applyTheme };
})();
