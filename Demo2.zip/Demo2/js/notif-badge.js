// notif-badge.js — included on every student page. Shows/hides the red
// dot on the 🔔 bell icon based on the real unread notification count.

async function refreshNotifBadge() {
  const dot = document.getElementById('notifDot');
  if (!dot) return;

  try {
    const res = await fetch('api/demoAPI.php?action=notification_unread_count');
    const data = await res.json();
    dot.style.display = (data.success && data.data.unread_count > 0) ? 'block' : 'none';
  } catch (err) {
    // Fail silently — a missing badge is better than a broken page.
  }
}

document.addEventListener('DOMContentLoaded', refreshNotifBadge);
