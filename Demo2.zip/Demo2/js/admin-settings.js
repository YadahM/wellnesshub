// admin-settings.js — loaded by admin-settings.php

document.addEventListener('DOMContentLoaded', async () => {
  const toggle = document.getElementById('switchAuditLogging');
  let enabled = true;

  function render() {
    toggle.classList.toggle('on', enabled);
  }

  try {
    const res = await fetch('api/demoAPI.php?action=admin_platform_settings_get');
    const data = await res.json();
    if (data.success) {
      enabled = data.data.audit_logging_enabled;
      render();
    }
  } catch (err) {
    console.error('Failed to load platform settings', err);
  }

  toggle.addEventListener('click', async () => {
    const next = !enabled;
    if (!next) {
      const confirmed = confirm(
        'Turning off audit logging stops ALL logging immediately, including security-relevant actions like account creation and suspension. Continue?'
      );
      if (!confirmed) return;
    }

    try {
      const res = await fetch('api/demoAPI.php?action=admin_platform_settings_update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ audit_logging_enabled: next ? '1' : '0' }),
      });
      const data = await res.json();
      if (data.success) {
        enabled = next;
        render();
      } else {
        alert(data.message);
      }
    } catch (err) {
      alert('Could not reach the server.');
    }
  });
});
