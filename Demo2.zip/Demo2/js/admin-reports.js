// admin-reports.js — loaded by admin-reports.php

function populateMonths() {
  const select = document.getElementById('reportMonth');
  const now = new Date();
  for (let i = 0; i < 6; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const ym = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const label = d.toLocaleString('default', { month: 'long', year: 'numeric' });
    const opt = document.createElement('option');
    opt.value = ym;
    opt.textContent = label;
    select.appendChild(opt);
  }
}

function formatChange(el, value) {
  if (value === null) {
    el.textContent = 'No prior data';
    el.className = 'muted';
    return;
  }
  const sign = value >= 0 ? '+' : '';
  el.textContent = `${sign}${value}% from last month`;
  el.className = value >= 0 ? 'green' : 'red';
}

async function loadReport() {
  const month = document.getElementById('reportMonth').value;
  const department = document.getElementById('reportDept').value;
  try {
    const res = await fetch('api/demoAPI.php?action=admin_report_summary&month=' + month + '&department=' + department);
    const data = await res.json();
    if (!data.success) {
      alert(data.message);
      return;
    }
    const d = data.data;
    document.getElementById('rAvgMood').textContent = d.avg_mood !== null ? `${d.avg_mood} / 5.0` : 'No data';
    document.getElementById('rConcern').textContent = d.elevated_concern_count;
    document.getElementById('rSessions').textContent = d.sessions;
    formatChange(document.getElementById('rAvgMoodChange'), d.avg_mood_change);
    formatChange(document.getElementById('rConcernChange'), d.elevated_concern_change);
    formatChange(document.getElementById('rSessionsChange'), d.sessions_change);
  } catch (err) {
    alert('Could not reach the server.');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  populateMonths();
  loadReport();

  document.getElementById('reportMonth').addEventListener('change', loadReport);
  document.getElementById('reportDept').addEventListener('change', loadReport);
  // reportType still doesn't change which stats are computed — Monthly,
  // Risk and Engagement all show the same underlying numbers for now.

  document.getElementById('exportCsvBtn').addEventListener('click', () => {
    const month = document.getElementById('reportMonth').value;
    const department = document.getElementById('reportDept').value;
    window.location.href = 'api/demoAPI.php?action=admin_report_export_csv&month=' + month + '&department=' + department;
  });

  document.getElementById('exportPdfBtn').addEventListener('click', () => {
    const month = document.getElementById('reportMonth').value;
    const department = document.getElementById('reportDept').value;
    window.location.href = 'api/demoAPI.php?action=admin_report_export_pdf&month=' + month + '&department=' + department;
  });
});
