// admin-counsellors.js — loaded by admin-counsellors.php

function availabilityPill(availability) {
  if (availability === 'Available') return '<span class="pill pill-green">Available</span>';
  if (availability === 'Busy') return '<span class="pill pill-orange">Busy</span>';
  return '<span class="pill pill-blue">' + availability + '</span>';
}

function counsellorCardEl(c) {
  const card = document.createElement('article');
  card.className = 'panel';

  const face = document.createElement('div');
  face.className = 'face';
  face.textContent = c.avatar || '🧑🏽';

  const h2 = document.createElement('h2');
  h2.textContent = c.name;

  const p = document.createElement('p');
  p.className = 'muted';
  p.textContent = `${c.appointments_this_month} appointment${c.appointments_this_month === 1 ? '' : 's'} this month`;

  const statusWrap = document.createElement('div');
  statusWrap.innerHTML = availabilityPill(c.availability);

  card.appendChild(face);
  card.appendChild(h2);
  card.appendChild(p);
  card.appendChild(statusWrap);

  if (c.user_id === null) {
    const warn = document.createElement('p');
    warn.className = 'muted';
    warn.style.color = '#ad651d';
    warn.textContent = '⚠ No linked login account';
    card.appendChild(warn);
  } else if (!c.is_active) {
    const warn = document.createElement('p');
    warn.className = 'muted';
    warn.style.color = '#c44848';
    warn.textContent = 'Account suspended';
    card.appendChild(warn);
  }

  return card;
}

async function loadCounsellors() {
  const grid = document.getElementById('counsellorGrid');
  grid.innerHTML = '<p class="muted">Loading counsellors…</p>';

  try {
    const res = await fetch('api/demoAPI.php?action=admin_counsellor_list');
    const data = await res.json();
    grid.innerHTML = '';

    if (!data.success) {
      grid.innerHTML = `<p class="muted">${data.message}</p>`;
      return;
    }
    if (data.data.counsellors.length === 0) {
      grid.innerHTML = '<p class="muted">No counsellors yet.</p>';
      return;
    }
    data.data.counsellors.forEach(c => grid.appendChild(counsellorCardEl(c)));
  } catch (err) {
    grid.innerHTML = '<p class="muted">Could not reach the server.</p>';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadCounsellors();

  const modal = document.getElementById('addCounsellorModal');
  const msg = document.getElementById('ccMessage');

  document.getElementById('addCounsellorBtn').addEventListener('click', () => {
    document.getElementById('ccName').value = '';
    document.getElementById('ccEmail').value = '';
    document.getElementById('ccPassword').value = '';
    document.getElementById('ccSpecialties').value = '';
    document.getElementById('ccAvatar').value = '';
    msg.textContent = '';
    msg.className = 'forgot-message';
    modal.style.display = 'flex';
  });

  document.getElementById('ccCancel').addEventListener('click', () => {
    modal.style.display = 'none';
  });

  document.getElementById('ccSubmit').addEventListener('click', async () => {
    msg.textContent = '';
    msg.className = 'forgot-message';

    const body = new URLSearchParams({
      full_name: document.getElementById('ccName').value.trim(),
      email: document.getElementById('ccEmail').value.trim(),
      password: document.getElementById('ccPassword').value,
      specialties: document.getElementById('ccSpecialties').value.trim(),
      avatar: document.getElementById('ccAvatar').value.trim(),
    });

    try {
      const res = await fetch('api/demoAPI.php?action=admin_counsellor_create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body,
      });
      const data = await res.json();

      if (!data.success) {
        msg.classList.add('error');
        msg.textContent = data.message;
        return;
      }

      modal.style.display = 'none';
      loadCounsellors();
    } catch (err) {
      msg.classList.add('error');
      msg.textContent = 'Could not reach the server.';
    }
  });
});
