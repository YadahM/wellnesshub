const MOOD_EMOJI = { great: '😊', good: '🙂', okay: '😐', low: '😟', struggling: '😣' };
let searchDebounce = null;

document.addEventListener('DOMContentLoaded', () => {
  loadStudents('');

  document.getElementById('studentSearch').addEventListener('input', (e) => {
    clearTimeout(searchDebounce);
    const q = e.target.value;
    searchDebounce = setTimeout(() => loadStudents(q), 250);
  });

  document.getElementById('saveNoteBtn').addEventListener('click', saveNote);
});

async function loadStudents(query) {
  try {
    const res = await fetch(`api/demoAPI.php?action=counsellor_students_list&q=${encodeURIComponent(query)}`);
    const data = await res.json();
    if (!data.success) {
      console.error(data.message);
      return;
    }
    renderTable(data.data.students);
  } catch (err) {
    console.error('Failed to load students', err);
  }
}

function renderTable(students) {
  const body = document.getElementById('studentsTableBody');
  body.innerHTML = '';

  if (students.length === 0) {
    const row = document.createElement('tr');
    row.innerHTML = '<td colspan="5">No students found.</td>';
    body.appendChild(row);
    return;
  }

  students.forEach((s) => {
    const row = document.createElement('tr');

    const moodCell = s.last_mood
      ? `${MOOD_EMOJI[s.last_mood] || ''} ${s.last_mood}`
      : '—';

    let riskCell = '<span class="pill pill-green">Low</span>';
    if (Number(s.has_high_risk) === 1) {
      riskCell = '<span class="pill pill-red">High</span>';
    } else if (Number(s.open_alerts) > 0) {
      riskCell = '<span class="pill pill-orange">Medium</span>';
    }

    row.innerHTML = `
      <td>${escapeHtml(s.full_name)}</td>
      <td>${moodCell}</td>
      <td>${riskCell}</td>
      <td>${s.last_checkin || '—'}</td>
      <td><button class="btn btn-ghost btn-small note-btn" type="button">Add Note</button></td>
    `;
    row.querySelector('.note-btn').addEventListener('click', () => openNoteEditor(s));
    body.appendChild(row);
  });
}

function openNoteEditor(student) {
  document.getElementById('noteEditor').style.display = 'block';
  document.getElementById('noteEditorTitle').textContent = `Add follow-up note — ${student.full_name}`;
  document.getElementById('noteStudentId').value = student.user_id;
  document.getElementById('noteText').value = '';
  document.getElementById('noteEditor').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

async function saveNote() {
  const userId = document.getElementById('noteStudentId').value;
  const note = document.getElementById('noteText').value.trim();
  if (!userId || !note) return;

  const formData = new FormData();
  formData.append('user_id', userId);
  formData.append('note', note);

  try {
    const res = await fetch('api/demoAPI.php?action=counsellor_note_save', { method: 'POST', body: formData });
    const data = await res.json();
    if (!data.success) {
      alert(data.message);
      return;
    }
    document.getElementById('noteEditor').style.display = 'none';
  } catch (err) {
    console.error('Failed to save note', err);
  }
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}
