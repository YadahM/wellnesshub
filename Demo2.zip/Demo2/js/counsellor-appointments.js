// Counsellor-appointment js
document.addEventListener("DOMContentLoaded", function () {

  // =========================================================
  // WELLNESSHUB - COUNSELLOR APPOINTMENTS
  // =========================================================

  const panel = document.querySelector(".panel");
  const timelineGrid = document.querySelector(".timeline-grid");

  const buttons = document.querySelectorAll(".panel-heading .btn");

  const calendarButton = buttons[0];
  const listButton = buttons[1];

  if (!panel || !timelineGrid) {
    console.log("Appointment calendar could not be found.");
    return;
  }


  // =========================================================
  // APPOINTMENT DATA
  // =========================================================

  const appointments = [
    {
      student: "Student #213",
      day: "Monday",
      date: "2 June 2026",
      time: "09:00",
      status: "Booked",
      type: "Counselling Session"
    },

    {
      student: "Student #045",
      day: "Wednesday",
      date: "4 June 2026",
      time: "09:30",
      status: "Booked",
      type: "Counselling Session"
    },

    {
      student: "Student #120",
      day: "Friday",
      date: "6 June 2026",
      time: "09:00",
      status: "Confirmed",
      type: "Follow-up Session"
    },

    {
      student: "Student #116",
      day: "Tuesday",
      date: "3 June 2026",
      time: "10:30",
      status: "Confirmed",
      type: "Counselling Session"
    },

    {
      student: "Student #390",
      day: "Thursday",
      date: "5 June 2026",
      time: "10:00",
      status: "Booked",
      type: "Counselling Session"
    },

    {
      student: "Student #305",
      day: "Wednesday",
      date: "4 June 2026",
      time: "11:30",
      status: "Booked",
      type: "Follow-up Session"
    }
  ];


  // =========================================================
  // CREATE LIST VIEW
  // =========================================================

  const listView = document.createElement("div");

  listView.className = "appointment-list-view";

  listView.style.display = "none";
  listView.style.marginTop = "20px";
  listView.style.gap = "12px";


  function createListView() {

    listView.innerHTML = "";

    appointments.forEach(function (appointment) {

      const card = document.createElement("div");

      card.className = "appointment-card";

      card.style.padding = "16px";
      card.style.border = "1px solid #283b58";
      card.style.borderRadius = "14px";
      card.style.marginBottom = "12px";
      card.style.background = "#0f1b2c";
      card.style.cursor = "pointer";

      card.innerHTML = `
        <div style="
          display:flex;
          justify-content:space-between;
          align-items:center;
          gap:15px;
          flex-wrap:wrap;
        ">

          <div>
            <strong style="
              color:#ffffff;
              font-size:15px;
            ">
              ${appointment.student}
            </strong>

            <p style="
              margin:6px 0 0;
              color:#9fb2ca;
              font-size:13px;
            ">
              ${appointment.day}, ${appointment.date}
            </p>
          </div>

          <div>
            <strong style="color:#ffffff;">
              ${appointment.time}
            </strong>
          </div>

          <div>
            <span style="
              padding:7px 12px;
              border-radius:20px;
              background:${
                appointment.status === "Confirmed"
                  ? "#163b2e"
                  : "#17365d"
              };
              color:${
                appointment.status === "Confirmed"
                  ? "#86e3b5"
                  : "#8cc3ff"
              };
              font-size:12px;
              font-weight:800;
            ">
              ${appointment.status}
            </span>
          </div>

          <div>
            <button
              class="btn btn-blue btn-small view-appointment"
              type="button"
            >
              View
            </button>
          </div>

        </div>
      `;

      card
        .querySelector(".view-appointment")
        .addEventListener("click", function () {

          showAppointmentDetails(appointment);

        });

      listView.appendChild(card);

    });

  }


  createListView();

  timelineGrid.after(listView);


  // =========================================================
  // CALENDAR VIEW BUTTON
  // =========================================================

  calendarButton.addEventListener("click", function () {

    timelineGrid.style.display = "grid";

    listView.style.display = "none";

    calendarButton.classList.remove("btn-ghost");
    calendarButton.classList.add("btn-blue");

    listButton.classList.remove("btn-blue");
    listButton.classList.add("btn-ghost");

  });


  // =========================================================
  // LIST VIEW BUTTON
  // =========================================================

  listButton.addEventListener("click", function () {

    timelineGrid.style.display = "none";

    listView.style.display = "block";

    listButton.classList.remove("btn-ghost");
    listButton.classList.add("btn-blue");

    calendarButton.classList.remove("btn-blue");
    calendarButton.classList.add("btn-ghost");

  });


  // =========================================================
  // CLICK APPOINTMENTS IN CALENDAR
  // =========================================================

  const appointmentBlocks =
    document.querySelectorAll(".appointment-block");

  appointmentBlocks.forEach(function (block) {

    block.style.cursor = "pointer";

    block.addEventListener("click", function () {

      const text =
        block.innerText
          .trim()
          .split("\n");

      const student = text[0];

      const time = text[1];


      // AVAILABLE SLOT
      if (student.toLowerCase().includes("available")) {

        showAvailableSlot(time);

        return;
      }


      // FIND APPOINTMENT DATA
      const appointment =
        appointments.find(function (item) {

          return (
            item.student === student &&
            item.time === time
          );

        });


      if (appointment) {

        showAppointmentDetails(appointment);

      } else {

        showSimpleMessage(
          student,
          "Appointment scheduled for " + time
        );

      }

    });

  });


  // =========================================================
  // APPOINTMENT DETAILS MODAL
  // =========================================================

  function showAppointmentDetails(appointment) {

    removeExistingModal();

    const overlay =
      document.createElement("div");

    overlay.className = "appointment-modal-overlay";

    overlay.style.position = "fixed";
    overlay.style.top = "0";
    overlay.style.left = "0";
    overlay.style.width = "100%";
    overlay.style.height = "100%";
    overlay.style.background = "rgba(0,0,0,.65)";
    overlay.style.display = "flex";
    overlay.style.alignItems = "center";
    overlay.style.justifyContent = "center";
    overlay.style.zIndex = "9999";
    overlay.style.padding = "20px";


    const modal =
      document.createElement("div");

    modal.style.width = "100%";
    modal.style.maxWidth = "430px";
    modal.style.background = "#15243a";
    modal.style.border = "1px solid #283b58";
    modal.style.borderRadius = "20px";
    modal.style.padding = "24px";
    modal.style.color = "#ffffff";
    modal.style.boxShadow =
      "0 20px 50px rgba(0,0,0,.45)";


    modal.innerHTML = `

      <div style="
        display:flex;
        justify-content:space-between;
        align-items:center;
        margin-bottom:20px;
      ">

        <div>
          <p style="
            margin:0 0 4px;
            color:#79b6ff;
            font-size:12px;
            font-weight:800;
            text-transform:uppercase;
          ">
            Appointment
          </p>

          <h2 style="
            margin:0;
            color:#ffffff;
          ">
            ${appointment.student}
          </h2>
        </div>

        <button
          class="close-appointment-modal"
          style="
            border:none;
            background:#0e1a2a;
            color:#ffffff;
            width:36px;
            height:36px;
            border-radius:10px;
            cursor:pointer;
            font-size:18px;
          "
        >
          ✕
        </button>

      </div>


      <div style="
        background:#0f1b2c;
        border:1px solid #283b58;
        border-radius:14px;
        padding:16px;
      ">

        <p>
          <strong>Student:</strong>
          ${appointment.student}
        </p>

        <p>
          <strong>Date:</strong>
          ${appointment.day}, ${appointment.date}
        </p>

        <p>
          <strong>Time:</strong>
          ${appointment.time}
        </p>

        <p>
          <strong>Session:</strong>
          ${appointment.type}
        </p>

        <p style="margin-bottom:0;">
          <strong>Status:</strong>
          ${appointment.status}
        </p>

      </div>


      <div style="
        display:flex;
        gap:10px;
        margin-top:20px;
        flex-wrap:wrap;
      ">

        <button
          class="btn btn-blue confirm-appointment"
          type="button"
        >
          Confirm
        </button>

        <button
          class="btn btn-ghost reschedule-appointment"
          type="button"
        >
          Reschedule
        </button>

        <button
          class="btn btn-ghost close-bottom"
          type="button"
        >
          Close
        </button>

      </div>

    `;


    overlay.appendChild(modal);

    document.body.appendChild(overlay);


    // CLOSE BUTTON
    modal
      .querySelector(".close-appointment-modal")
      .addEventListener("click", function () {

        overlay.remove();

      });


    modal
      .querySelector(".close-bottom")
      .addEventListener("click", function () {

        overlay.remove();

      });


    // CONFIRM
    modal
      .querySelector(".confirm-appointment")
      .addEventListener("click", function () {

        appointment.status = "Confirmed";

        alert(
          appointment.student +
          "'s appointment has been confirmed."
        );

        overlay.remove();

        createListView();

      });


    // RESCHEDULE
    modal
      .querySelector(".reschedule-appointment")
      .addEventListener("click", function () {

        const newTime =
          prompt(
            "Enter a new appointment time:",
            appointment.time
          );

        if (newTime && newTime.trim() !== "") {

          appointment.time =
            newTime.trim();

          alert(
            appointment.student +
            " has been rescheduled to " +
            appointment.time
          );

          createListView();

          overlay.remove();

        }

      });


    // CLICK OUTSIDE MODAL TO CLOSE
    overlay.addEventListener(
      "click",
      function (event) {

        if (event.target === overlay) {

          overlay.remove();

        }

      }
    );

  }


  // =========================================================
  // AVAILABLE SLOT
  // =========================================================

  function showAvailableSlot(time) {

    const confirmBooking =
      confirm(
        "This time slot is available at " +
        time +
        ".\n\nWould you like to create an appointment?"
      );


    if (!confirmBooking) {
      return;
    }


    const studentNumber =
      prompt(
        "Enter the student number:"
      );


    if (!studentNumber) {
      return;
    }


    const student =
      studentNumber
        .trim()
        .toUpperCase();


    appointments.push({
      student: student.startsWith("STUDENT")
        ? student
        : "Student #" + student,
      day: "Friday",
      date: "6 June 2026",
      time: time,
      status: "Booked",
      type: "Counselling Session"
    });


    createListView();


    alert(
      "Appointment successfully created for " +
      student +
      " at " +
      time +
      "."
    );

  }


  // =========================================================
  // SIMPLE MESSAGE MODAL
  // =========================================================

  function showSimpleMessage(title, message) {

    alert(
      title +
      "\n\n" +
      message
    );

  }


  // =========================================================
  // REMOVE EXISTING MODAL
  // =========================================================

  function removeExistingModal() {

    const existingModal =
      document.querySelector(
        ".appointment-modal-overlay"
      );

    if (existingModal) {

      existingModal.remove();

    }

  }


});