const SLOT_TIMES = ['09:00', '11:30', '14:00', '15:30'];
const DAY_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];

let currentWeekStart = mondayOf(new Date());

document.addEventListener('DOMContentLoaded', () => {
  loadWeek();

  document.getElementById('prevWeekBtn').addEventListener('click', () => shiftWeek(-7));
  document.getElementById('nextWeekBtn').addEventListener('click', () => shiftWeek(7));
  document.getElementById('todayBtn').addEventListener('click', () => {
    currentWeekStart = mondayOf(new Date());
    loadWeek();
  });
});

function mondayOf(date) {
  const d = new Date(date);
  const day = d.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  d.setDate(d.getDate() + diff);
  return formatDateLocal(d);
}

function formatDateLocal(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function shiftWeek(days) {
  const d = new Date(currentWeekStart + 'T00:00:00');
  d.setDate(d.getDate() + days);
  currentWeekStart = mondayOf(d);
  loadWeek();
}

async function loadWeek() {
  try {
    const res = await fetch(`api/demoAPI.php?action=counsellor_appointments_list&week_start=${currentWeekStart}`);
    const data = await res.json();
    if (!data.success) {
      console.error(data.message);
      return;
    }
    renderGrid(data.data.week_start, data.data.appointments);
  } catch (err) {
    console.error('Failed to load appointments', err);
  }
}

function renderGrid(weekStart, appointments) {
  const start = new Date(weekStart + 'T00:00:00');
  const dayDates = DAY_LABELS.map((_, i) => {
    const d = new Date(start);
    d.setDate(d.getDate() + i);
    return formatDateLocal(d);
  });

  document.getElementById('weekLabel').textContent =
    `${dayDates[0]} — ${dayDates[4]}`;

  const byCell = {};
  appointments.forEach((a) => {
    const key = `${a.session_date}|${a.session_time.slice(0, 5)}`;
    byCell[key] = a;
  });

  const grid = document.getElementById('timelineGrid');
  grid.innerHTML = '';

  grid.appendChild(cell('time-cell time-head', 'Time'));
  DAY_LABELS.forEach((label, i) => {
    grid.appendChild(cell('time-cell time-head', `${label} ${dayDates[i].slice(8, 10)}`));
  });

  SLOT_TIMES.forEach((time) => {
    grid.appendChild(cell('time-cell', time));
    dayDates.forEach((date) => {
      const appt = byCell[`${date}|${time}`];
      const wrap = document.createElement('div');
      wrap.className = 'time-cell';
      if (appt) {
        const block = document.createElement('div');
        block.className = 'appointment-block';
        block.textContent = `Student: ${appt.student_name}`;
        wrap.appendChild(block);
      }
      grid.appendChild(wrap);
    });
  });
}

function cell(className, text) {
  const el = document.createElement('div');
  el.className = className;
  el.textContent = text;
  return el;
}
