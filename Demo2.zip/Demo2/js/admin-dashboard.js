// admin-dashboard.js — loaded by admin-dashboard.php

const EMOTION_PILL = {
  Grateful: 'pill-green',
  Calm: 'pill-blue',
  Hopeful: 'pill-purple',
  Anxious: 'pill-orange',
  Frustrated: 'pill-red',
};

document.addEventListener('DOMContentLoaded', async () => {
  try {
    const res = await fetch('api/demoAPI.php?action=admin_dashboard_summary');
    const data = await res.json();
    if (!data.success) {
      document.getElementById('concernsLegend').innerHTML = `<li>${data.message}</li>`;
      return;
    }

    const d = data.data;

    document.getElementById('kpiTotalUsers').textContent = d.kpis.total_users.toLocaleString();
    document.getElementById('kpiActiveStudents').textContent = d.kpis.active_students.toLocaleString();
    document.getElementById('kpiCounsellors').textContent = d.kpis.counsellor_accounts.toLocaleString();
    document.getElementById('kpiSessions').textContent = d.kpis.sessions_this_month.toLocaleString();

    renderGrowthChart(d.user_growth);
    renderEmotionBreakdown(d.emotion_breakdown);
  } catch (err) {
    console.error('Failed to load admin dashboard summary', err);
    document.getElementById('concernsLegend').innerHTML = '<li>Could not reach the server.</li>';
  }
});

function renderGrowthChart(rows) {
  const linesGroup = document.getElementById('growthLines');
  const dotsGroup = document.getElementById('growthDots');
  const labelsGroup = document.getElementById('growthLabels');
  linesGroup.innerHTML = '';
  dotsGroup.innerHTML = '';
  labelsGroup.innerHTML = '';

  if (rows.length === 0) {
    const msg = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    msg.setAttribute('x', 120);
    msg.setAttribute('y', 90);
    msg.textContent = 'No signups in the last 6 months.';
    labelsGroup.appendChild(msg);
    return;
  }

  const counts = rows.map(r => r.cnt);
  const max = Math.max(...counts, 1);
  const xFor = i => rows.length > 1 ? 30 + i * (360 / (rows.length - 1)) : 210;
  const yFor = count => 150 - (count / max) * 110; // scales to the real max, not a fixed range

  const points = rows.map((r, i) => ({ x: xFor(i), y: yFor(r.cnt) }));

  for (let i = 0; i < points.length - 1; i++) {
    const line = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    line.setAttribute('class', 'chart-line');
    line.setAttribute('style', 'stroke:#e87ac8');
    line.setAttribute('d', `M${points[i].x} ${points[i].y} L${points[i + 1].x} ${points[i + 1].y}`);
    linesGroup.appendChild(line);
  }

  points.forEach((p, i) => {
    const dot = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    dot.setAttribute('class', 'chart-dot');
    dot.setAttribute('style', 'stroke:#e87ac8');
    dot.setAttribute('cx', p.x);
    dot.setAttribute('cy', p.y);
    dot.setAttribute('r', 5);
    const title = document.createElementNS('http://www.w3.org/2000/svg', 'title');
    title.textContent = `${rows[i].label}: ${rows[i].cnt} new users`;
    dot.appendChild(title);
    dotsGroup.appendChild(dot);

    const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    label.setAttribute('class', 'chart-label');
    label.setAttribute('x', p.x - 8);
    label.setAttribute('y', 172);
    label.textContent = rows[i].label;
    labelsGroup.appendChild(label);
  });
}

function renderEmotionBreakdown(rows) {
  const legend = document.getElementById('concernsLegend');
  const donut = document.getElementById('concernsDonut');
  legend.innerHTML = '';

  if (rows.length === 0) {
    legend.innerHTML = '<li>No journal entries with an emotion tag yet.</li>';
    donut.style.background = '#e5e7eb';
    return;
  }

  rows.forEach(r => {
    const li = document.createElement('li');
    const pill = document.createElement('span');
    pill.className = 'pill ' + (EMOTION_PILL[r.emotion] || 'pill-blue');
    pill.style.marginRight = '6px';
    pill.textContent = ' ';
    li.appendChild(pill);
    li.appendChild(document.createTextNode(`${r.emotion} ${r.percentage}%`));
    legend.appendChild(li);
  });

  // Build the donut from the same colors as the legend pills, read live
  // from CSS rather than guessed hex values.
  let acc = 0;
  const stops = [];
  rows.forEach(r => {
    const pillClass = EMOTION_PILL[r.emotion] || 'pill-blue';
    const probe = document.querySelector('.pill.' + pillClass);
    const color = probe ? getComputedStyle(probe).backgroundColor : '#ccc';
    const start = acc;
    acc += r.percentage;
    stops.push(`${color} ${start}% ${acc}%`);
  });
  donut.style.background = `conic-gradient(${stops.join(', ')})`;
}
