<?php require_once __DIR__ . '/auth-check.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>My Profile — WellnessHub</title>
  <link rel="stylesheet" href="css/style.css" />
  <style>
    /* Supplementary styles for the profile picture area — same convention as other pages' additions */
    .profile-picture-wrap{ display:flex; flex-direction:column; align-items:center; gap:14px; padding:20px 0 28px; }
    .profile-avatar{ width:120px; height:120px; border-radius:50%; object-fit:cover; background:#4b73d9; color:#fff; display:flex; align-items:center; justify-content:center; font-size:48px; font-weight:800; }
    .profile-field{ margin-bottom:18px; }
    .profile-field span{ display:block; font-size:12px; font-weight:800; color:var(--muted); text-transform:uppercase; letter-spacing:.04em; margin-bottom:4px; }
    .profile-field strong{ font-size:16px; }
    .profile-message{ font-size:13px; font-weight:700; margin-top:10px; }
    .profile-message.error{ color:#c44848; }
    .profile-message.success{ color:#2f744d; }
  </style>
</head>
<body class="app-body">
  <script src="js/theme.js"></script>
  <div class="app-shell">
    <aside class="sidebar student-sidebar">
      <a class="brand-mini sidebar-brand" href="index.php">
        <span class="mini-leaf" aria-hidden="true">☘</span>
        <span>WellnessHub</span>
      </a>

      <nav class="side-nav" aria-label="Student navigation">
        <a href="dashboard.php"><span>▣</span> Dashboard</a>
        <a href="mood-tracking.php"><span>☺</span> Mood Tracking</a>
        <a href="journal.php"><span>✎</span> Journal</a>
        <a href="self-help-library.php"><span>▤</span> Self-Help Library</a>
        <a href="counselling-booking.php"><span>♡</span> Book Counselling</a>
        <a href="peer-support.php"><span>☷</span> Peer Support</a>
        <a href="achievements.php"><span>★</span> Achievements</a>
        <a href="notifications.php"><span>🔔</span> Notifications</a>
        <a href="settings.php"><span>⚙</span> Settings</a>
        <a href="logout.php"><span>↪</span> Logout</a>
      </nav>
    </aside>

    <main class="dashboard-main">
      <header class="topbar">
        <div>
          <p class="eyebrow">Student Side</p>
          <h1>My Profile</h1>
          <p class="page-subtitle">Your account details and profile picture.</p>
        </div>
        <div class="topbar-actions">
          <a class="icon-btn" href="notifications.php" aria-label="Notifications">🔔</a>
          <?php $firstName = explode(' ', $_SESSION['full_name'])[0]; ?>
          <div class="avatar"><?= htmlspecialchars(strtoupper(substr($firstName, 0, 1))) ?></div>
        </div>
      </header>

      <section class="panel" style="max-width:480px;">
        <div class="profile-picture-wrap">
          <div id="avatarPreview" class="profile-avatar"><?= htmlspecialchars(strtoupper(substr($firstName, 0, 1))) ?></div>
          <input type="file" id="pictureInput" accept="image/png,image/jpeg,image/gif,image/webp" style="display:none;" />
          <div class="inline">
            <button class="btn btn-ghost btn-small" type="button" id="uploadBtn">Upload Picture</button>
            <button class="btn btn-ghost btn-small" type="button" id="removeBtn" style="display:none;">Remove Picture</button>
          </div>
          <p id="pictureMessage" class="profile-message"></p>
        </div>

        <div class="profile-field">
          <span>Full Name</span>
          <strong id="profileFullName">Loading…</strong>
        </div>
        <div class="profile-field">
          <span>Student Number</span>
          <strong id="profileStudentNumber">Loading…</strong>
        </div>
        <div class="profile-field">
          <span>Email Address</span>
          <strong id="profileEmail">Loading…</strong>
        </div>
        <div class="profile-field">
          <span>Gender</span>
          <strong id="profileGender">Loading…</strong>
        </div>
      </section>
    </main>
  </div>
  <script src="js/profile.js"></script>
</body>
</html>
