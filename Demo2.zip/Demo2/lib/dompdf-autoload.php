<?php
/*
 * dompdf-autoload.php — hand-written PSR-4 autoloader for DOMPDF and its
 * dependencies, since Composer/Packagist isn't reachable from this
 * environment. Each package was fetched directly from its GitHub repo.
 * Namespace-to-path mappings below were read directly from each package's
 * own composer.json "psr-4" section, not guessed.
 */

$__dompdf_namespace_map = [
    'Dompdf\\' => __DIR__ . '/vendor/dompdf/src/',
    'FontLib\\' => __DIR__ . '/vendor/php-font-lib/src/FontLib/',
    'Svg\\' => __DIR__ . '/vendor/php-svg-lib/src/Svg/',
    'Masterminds\\' => __DIR__ . '/vendor/html5-php/src/',
    'Sabberworm\\CSS\\' => __DIR__ . '/vendor/php-css-parser/src/',
];

spl_autoload_register(function ($class) use ($__dompdf_namespace_map) {
    foreach ($__dompdf_namespace_map as $prefix => $baseDir) {
        if (strncmp($prefix, $class, strlen($prefix)) === 0) {
            $relative = substr($class, strlen($prefix));
            $file = $baseDir . str_replace('\\', '/', $relative) . '.php';
            if (file_exists($file)) {
                require $file;
                return;
            }
        }
    }
});

// php-css-parser's composer.json explicitly force-includes these two files
// outside normal PSR-4 resolution (some kind of legacy class-alias setup) —
// mirroring that here since our autoloader alone wouldn't load them.
require_once __DIR__ . '/vendor/php-css-parser/src/Rule/Rule.php';
require_once __DIR__ . '/vendor/php-css-parser/src/RuleSet/RuleContainer.php';

// dompdf's composer.json also classmaps lib/Cpdf.php (a legacy, non-
// namespaced global class dompdf wraps) outside PSR-4.
require_once __DIR__ . '/vendor/dompdf/lib/Cpdf.php';
