<?php require_once __DIR__ . '/counsellor-auth.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Crisis Detection / Risk Alerts — WellnessHub</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body class="app-body dark-body counsellor-body">
  <div class="app-shell dark-shell">
    <aside class="sidebar counsellor-sidebar">
      <a class="brand-mini sidebar-brand" href="index.php">
        <span class="mini-leaf" aria-hidden="true">☘</span>
        <span>WellnessHub</span>
      </a>

      <nav class="side-nav" aria-label="Counsellor navigation">
        <a href="counsellor-dashboard.php"><span>▣</span> Dashboard</a>
        <a href="counsellor-students.php"><span>👥</span> Students</a>
        <a class="active" href="risk-alerts.php"><span>⚠</span> Risk Alerts</a>
        <a href="counsellor-appointments.php"><span>📅</span> Appointments</a>
        <a href="counsellor-resources.php"><span>▤</span> Resources</a>
        <a href="logout.php"><span>↪</span> Logout</a>
      </nav>
    </aside>

    <main class="dashboard-main dark-main">
      <header class="topbar dark-topbar">
        <div>
          <p class="eyebrow">Counsellor Side</p>
          <h1>Crisis Detection / Risk Alerts</h1>
          <p class="page-subtitle">Early warning alerts from mood trends and journal risk markers.</p>
        </div>
        <div class="topbar-actions">
          <a class="icon-btn dark-icon" href="risk-alerts.php" aria-label="Alerts">🔔</a>
          <div class="avatar dark-avatar"><?= htmlspecialchars(strtoupper(substr($_SESSION['full_name'], 0, 1))) ?></div>
        </div>
      </header>

      <section class="two-col">
        <article class="panel">
          <div class="panel-heading">
            <h2>AI Alerts <span class="pill pill-red" id="alertCount">0</span></h2>
            <a href="#" id="refreshBtn">Refresh</a>
          </div>
          <div class="risk-list" id="riskList">
            <p class="muted" id="riskEmpty" style="display:none;">No open risk alerts right now.</p>
          </div>
        </article>

        <article class="panel">
          <h2>Action Note</h2>
          <p class="page-subtitle" id="selectedStudentLabel">Select an alert on the left to act on it.</p>
          <input type="hidden" id="selectedAlertId" value="" />
          <label class="field"><span>Next Step</span><textarea id="actionNote" placeholder="Add internal note for follow-up..."></textarea></label>
          <div class="inline" style="display:flex; gap:10px;">
            <button class="btn btn-ghost btn-full" id="markInProgressBtn" disabled>Mark In Progress</button>
            <button class="btn btn-blue btn-full" id="resolveBtn" disabled>Resolve & Save Note</button>
          </div>
        </article>
      </section>
    </main>
  </div>

  <script src="js/risk-alerts.js"></script>
</body>
</html>
