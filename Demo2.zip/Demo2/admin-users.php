<?php require_once __DIR__ . '/admin-auth.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>User Management — WellnessHub</title>
  <link rel="stylesheet" href="css/style.css" />
  <style>
    /* Supplementary styles for the Add/Edit User modals — same convention as other pages' additions */
    .modal-overlay{ position:fixed; inset:0; background:rgba(0,0,0,.45); display:flex; align-items:center; justify-content:center; z-index:50; }
    .modal-box{ width:min(420px, 90vw); max-height:85vh; overflow-y:auto; }
    .forgot-message.error{ color:#c44848; }
    .forgot-message.success{ color:#2f744d; }
  </style>
</head>
<body class="app-body admin-body">
  <div class="app-shell admin-shell">
    <aside class="sidebar admin-sidebar">
      <a class="brand-mini sidebar-brand" href="index.php">
        <span class="mini-leaf" aria-hidden="true">☘</span>
        <span>WellnessHub</span>
      </a>

      <nav class="side-nav" aria-label="Admin navigation">
        <a href="admin-dashboard.php"><span>▣</span> Dashboard</a>
        <a class="active" href="admin-users.php"><span>👥</span> Users</a>
        <a href="admin-counsellors.php"><span>♡</span> Counsellors</a>
        <a href="admin-reports.php"><span>📊</span> Reports</a>
        <a href="system-logs.php"><span>☷</span> System Logs</a>
        <a href="admin-settings.php"><span>⚙</span> Settings</a>
        <a href="logout.php"><span>↪</span> Logout</a>
      </nav>
    </aside>

    <main class="dashboard-main admin-main ">
      <header class="topbar admin-topbar">
        <div>
          <p class="eyebrow">Admin Side</p>
          <h1>User Management</h1>
          <p class="page-subtitle">Manage student, counsellor and admin accounts.</p>
        </div>
        <div class="topbar-actions">
          <a class="icon-btn admin-icon" href="system-logs.php" aria-label="System logs">🔔</a>
          <?php $adminFirstName = explode(' ', $_SESSION['full_name'])[0]; ?>
          <div class="avatar admin-avatar"><?= htmlspecialchars(strtoupper(substr($adminFirstName, 0, 1))) ?></div>
        </div>
      </header>
      <section class="panel">
        <div class="panel-heading">
          <h2>Users</h2>
          <div class="inline">
            <input type="search" id="userSearch" placeholder="Search name or email…" style="padding:8px 12px; border:1px solid var(--line); border-radius:8px;" />
            <button class="btn btn-purple btn-small" type="button" id="addUserBtn">Add User</button>
          </div>
        </div>
        <table class="data-table">
          <thead><tr><th></th><th>Name</th><th>Role</th><th>Status</th><th>Last Login</th><th>Action</th></tr></thead>
          <tbody id="usersTableBody">
            <tr><td colspan="6" class="muted">Loading users…</td></tr>
          </tbody>
        </table>
      </section>

      <!-- Add User modal -->
      <div id="addUserModal" class="modal-overlay" style="display:none;">
        <div class="modal-box panel">
          <h2>Add User</h2>
          <label class="field"><span>Full Name</span><input type="text" id="newFullName" /></label>
          <label class="field"><span>Role</span>
            <select id="newRole">
              <option value="student">Student</option>
              <option value="counsellor">Counsellor</option>
              <option value="admin">Admin</option>
            </select>
          </label>
          <label class="field" id="studentNumberField"><span>Student Number</span><input type="text" id="newStudentNumber" placeholder="e.g. 402311336" /></label>
          <label class="field"><span>Email</span><input type="email" id="newEmail" /></label>
          <label class="field"><span>Password</span><input type="text" id="newPassword" placeholder="Min 8 characters" /></label>
          <p class="muted" id="newUserHint">Student email must be studentnumber@my.richfield.ac.za</p>
          <p id="addUserMessage" class="forgot-message"></p>
          <div class="inline" style="margin-top:10px;">
            <button class="btn btn-ghost" type="button" id="cancelAddUser">Cancel</button>
            <button class="btn btn-primary" type="button" id="submitAddUser">Create Account</button>
          </div>
        </div>
      </div>

      <!-- Edit User modal -->
      <div id="editUserModal" class="modal-overlay" style="display:none;">
        <div class="modal-box panel">
          <h2>Edit User</h2>
          <div class="profile-picture-wrap" style="padding:10px 0 18px;">
            <div id="editAvatarPreview" class="profile-avatar" style="width:72px; height:72px; font-size:28px;"></div>
          </div>
          <label class="field"><span>Full Name</span><input type="text" id="editFullName" /></label>
          <label class="field"><span>Email</span><input type="email" id="editEmail" /></label>
          <label class="field" id="editStudentNumberField"><span>Student Number</span><input type="text" id="editStudentNumber" /></label>
          <label class="field"><span>Gender</span>
            <select id="editGender">
              <option value="Prefer not to say">Prefer not to say</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Non-binary">Non-binary</option>
            </select>
          </label>
          <label class="field" id="editDepartmentField"><span>Department</span>
            <select id="editDepartment">
              <option value="DIT">DIT — Information Technology</option>
              <option value="BAS">BAS — Business Analysis</option>
              <option value="NET">NET — Networks</option>
            </select>
          </label>
          <label class="field"><span>Role</span>
            <select id="editRole">
              <option value="student">Student</option>
              <option value="counsellor">Counsellor</option>
              <option value="admin">Admin</option>
            </select>
          </label>
          <label class="field"><span>Status</span>
            <select id="editActive">
              <option value="1">Active</option>
              <option value="0">Suspended</option>
            </select>
          </label>
          <p id="editUserMessage" class="forgot-message"></p>
          <div class="inline" style="margin-top:10px;">
            <button class="btn btn-ghost" type="button" id="cancelEditUser">Cancel</button>
            <button class="btn btn-primary" type="button" id="submitEditUser">Save Changes</button>
          </div>
          <hr style="margin:18px 0; border:0; border-top:1px solid var(--line);" />
          <p class="muted" style="font-size:13px;">Resetting a password sets it to a known default for that role, which the user can then change themselves once logged back in.</p>
          <button class="btn btn-ghost btn-small" type="button" id="resetPasswordBtn" style="color:#c44848;">Reset Password to Default</button>
          <p id="resetPasswordMessage" class="forgot-message"></p>
          <hr style="margin:18px 0; border:0; border-top:1px solid var(--line);" />
          <p class="muted" style="font-size:13px;">Deleting a student permanently removes all of their mood check-ins, journal entries, posts, and bookings — this cannot be undone. Deleting a counsellor only removes their login; their profile and booking history stay intact.</p>
          <button class="btn btn-ghost btn-small" type="button" id="deleteUserBtn" style="color:#fff; background:#c44848;">Delete User</button>
          <p id="deleteUserMessage" class="forgot-message"></p>
        </div>
      </div>
    </main>
  </div>
  <script src="js/admin-users.js"></script>
</body>
</html>
