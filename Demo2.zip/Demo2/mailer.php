<?php
/*
 * mailer.php — sends the real password-reset email via Gmail SMTP.
 * Requires mail-config.php to have real credentials filled in.
 */

require_once __DIR__ . '/lib/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/lib/PHPMailer/SMTP.php';
require_once __DIR__ . '/lib/PHPMailer/Exception.php';
require_once __DIR__ . '/mail-config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

/**
 * Sends the reset code to a counsellor's real email address.
 * Returns true on success. On failure, logs the real error server-side
 * (via error_log — check your PHP/Apache error log to debug SMTP issues)
 * and returns false, WITHOUT leaking SMTP details back to the client.
 */
function sendPasswordResetEmail(string $toEmail, string $toName, string $code): bool {
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;

        $mail->setFrom(SMTP_USERNAME, SMTP_FROM_NAME);
        $mail->addAddress($toEmail, $toName);

        $mail->isHTML(true);
        $mail->Subject = 'Your WellnessHub password reset code';
        $mail->Body    = "
            <p>Hi {$toName},</p>
            <p>Your WellnessHub counsellor account password reset code is:</p>
            <p style=\"font-size:28px; font-weight:800; letter-spacing:4px;\">{$code}</p>
            <p>This code expires in 10 minutes. If you didn't request this, you can safely ignore this email.</p>
        ";
        $mail->AltBody = "Your WellnessHub password reset code is {$code}. It expires in 10 minutes.";

        $mail->send();
        return true;
    } catch (PHPMailerException $e) {
        error_log('Password reset email failed to send: ' . $mail->ErrorInfo);
        return false;
    }
}
