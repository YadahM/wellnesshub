<?php
/*
 * UPDATE: this page previously had no role check because no
 * counsellor auth system existed yet. Now that counsellor-auth.php exists
 * (built by the counsellor-side team), this page uses it — properly
 * restricting this screen to logged-in counsellors, closing the gap that
 * was explicitly flagged as temporary/insecure when this page was built.
 */
require_once __DIR__ . '/counsellor-auth.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Peer Support Moderation (DEV ONLY) — WellnessHub</title>
  <link rel="stylesheet" href="css/style.css" />
  <style>
    .dev-warning{ background:#fff1dd; border:2px solid #ad651d; color:#7a4813; padding:14px 18px; border-radius:12px; font-weight:700; margin-bottom:18px; }
    .mod-post-card{ border:1px solid var(--line); border-radius:12px; padding:16px; margin-bottom:14px; }
    .mod-post-card.removed{ opacity:0.5; }
    .mod-actions{ display:flex; gap:10px; margin-top:10px; }
  </style>
</head>
<body class="app-body">
  <div class="app-shell">
    <main class="dashboard-main" style="width:100%;">
      <header class="topbar">
        <div>
          <p class="eyebrow">Moderation</p>
          <h1>Reported Posts</h1>
          <p class="page-subtitle">Posts with unreviewed reports from the Peer Support board.</p>
        </div>
      </header>
      <section>
        <div id="queueList"><p class="muted">Loading reported posts…</p></div>
      </section>
    </main>
  </div>
  <script src="js/moderation.js"></script>
</body>
</html>
