<?php
/*
 * mail-config.php — Gmail SMTP credentials for sending real password-reset
 * emails via PHPMailer.
 *
 * ⚠ IMPORTANT: add this file to .gitignore. It contains a real credential
 * (a Gmail app password) tied to an actual Google account — unlike the
 * demo/prototype passwords used elsewhere in this project, this one
 * matters for real security if it ever leaks (e.g. committed to a public
 * GitHub repo).
 *
 * SMTP_PASSWORD must be a Gmail APP PASSWORD (16 characters, generated at
 * myaccount.google.com/apppasswords), never your real Google account
 * password — Gmail will reject a real password for SMTP login anyway.
 */

define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'PUT_YOUR_GMAIL_ADDRESS_HERE@gmail.com');
define('SMTP_PASSWORD', 'PUT_YOUR_16_CHAR_APP_PASSWORD_HERE');
define('SMTP_FROM_NAME', 'WellnessHub');
