<?php
function handleEmotionalIndexAggregate(PDO $pdo): void {
    requireStaff();

    $days = (int) ($_GET['days'] ?? 7);
    if (!in_array($days, [7, 14, 30], true)) {
        $days = 7;
    }
    $span = $days - 1;

    $rows = $pdo->query("
        SELECT checkin_date,
               COUNT(*) AS checkins,
               AVG(CASE mood
                   WHEN 'struggling' THEN 1 WHEN 'low' THEN 2 WHEN 'okay' THEN 3
                   WHEN 'good' THEN 4 WHEN 'great' THEN 5 END) AS emotional_index
        FROM mood_checkins
        WHERE checkin_date >= DATE_SUB(CURDATE(), INTERVAL {$span} DAY)
        GROUP BY checkin_date
        ORDER BY checkin_date ASC
    ")->fetchAll();

    $distribution = ['great' => 0, 'good' => 0, 'okay' => 0, 'low' => 0, 'struggling' => 0];
    $moodRows = $pdo->query("
        SELECT mood, COUNT(*) AS cnt
        FROM mood_checkins
        WHERE checkin_date >= DATE_SUB(CURDATE(), INTERVAL {$span} DAY)
        GROUP BY mood
    ")->fetchAll();
    foreach ($moodRows as $row) {
        $distribution[$row['mood']] = (int) $row['cnt'];
    }

    jsonResponse(true, 'Emotional index retrieved.', [
        'days' => $days,
        'labels' => array_column($rows, 'checkin_date'),
        'emotional_index' => array_map(fn($r) => round((float) $r['emotional_index'], 2), $rows),
        'checkins' => array_map(fn($r) => (int) $r['checkins'], $rows),
        'distribution' => $distribution,
    ]);
}
