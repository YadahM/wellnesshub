<?php
require_once __DIR__ . '/threatLexicon.php';

function saveJournalWithAlert(PDO $pdo, int $userId, string $content, ?string $emotion): array {
    $alertTier = screenJournalText($content) ? 'critical' : 'normal';

    $stmt = $pdo->prepare('
        INSERT INTO journal_entries (user_id, content, emotion, alert_tier)
        VALUES (:user_id, :content, :emotion, :alert_tier)
    ');
    $stmt->execute([
        ':user_id' => $userId,
        ':content' => $content,
        ':emotion' => $emotion,
        ':alert_tier' => $alertTier,
    ]);

    return [
        'entry_id' => $pdo->lastInsertId(),
        'content' => $content,
        'emotion' => $emotion,
        'created_at' => date('Y-m-d H:i:s'),
        'crisis_alert' => $alertTier === 'critical',
    ];
}

function syncCriticalJournalAlerts(PDO $pdo): void {
    $rows = $pdo->query("
        SELECT entry_id, user_id, created_at
        FROM journal_entries
        WHERE alert_tier = 'critical'
          AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ")->fetchAll();

    $insert = $pdo->prepare('
        INSERT INTO risk_alerts (user_id, source, source_id, severity, reason)
        VALUES (:user_id, "journal_entry", :source_id, "high", :reason)
        ON DUPLICATE KEY UPDATE severity = VALUES(severity), reason = VALUES(reason)
    ');

    foreach ($rows as $row) {
        $insert->execute([
            ':user_id' => $row['user_id'],
            ':source_id' => $row['entry_id'],
            ':reason' => 'Journal entry from ' . date('Y-m-d', strtotime($row['created_at'])) . ' was placed in the critical alert tier by the screening engine.',
        ]);
    }
}
