<?php
function threatLexicon(): array {
    static $lexicon = null;
    if ($lexicon === null) {
        $lexicon = [
            'words' => array_flip(['suicide', 'suicidal', 'harm']),
            'phrases' => [
                'end life', 'end my life', 'kill myself', 'want to die',
                'hurting myself', 'no reason to live',
            ],
        ];
    }
    return $lexicon;
}

function normaliseThreatText(string $text): string {
    $plain = preg_replace('/<[^>]*>/', ' ', $text);
    $plain = html_entity_decode($plain, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $plain = mb_strtolower($plain, 'UTF-8');
    $plain = preg_replace('/[^\p{L}\p{N}\']+/u', ' ', $plain);
    return trim(preg_replace('/\s+/u', ' ', $plain));
}

function screenJournalText(string $text): bool {
    $normalised = normaliseThreatText($text);
    if ($normalised === '') {
        return false;
    }

    $lexicon = threatLexicon();

    foreach (explode(' ', $normalised) as $token) {
        if (isset($lexicon['words'][$token])) {
            return true;
        }
    }

    $padded = ' ' . $normalised . ' ';
    foreach ($lexicon['phrases'] as $phrase) {
        if (str_contains($padded, ' ' . $phrase . ' ')) {
            return true;
        }
    }

    return false;
}
