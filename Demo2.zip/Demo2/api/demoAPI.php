<?php
// This file NEVER outputs HTML. It is called only via fetch() from
// register.php (?action=register) and login.php (?action=login).
// header() and session_start() are safe here because nothing is echoed before them.

session_start();
header('Content-Type: application/json');

// demoDB.php lives in the Demo/ root, one level up from here.
require_once __DIR__ . '/../demoDB.php';
require_once __DIR__ . '/journalAlert.php';
require_once __DIR__ . '/emotionalIndex.php';

const COUNSELLOR_SHARED_CODE = '123';
const COUNSELLOR_EMAIL_DOMAIN = '@richfield.ac.za';

// Fixed weekday slot template — no per-counsellor availability management
// exists yet, so every counsellor offers the same 4 daily slots, weekdays
// only. Must be declared here, before the router dispatch below — PHP does
// NOT hoist top-level const declarations the way it hoists functions, so a
// const defined further down the file is undefined at the moment match()
// calls into any handler that references it.
const BOOKING_SLOT_TEMPLATE = ['09:00:00', '11:30:00', '14:00:00', '15:30:00'];

// Crisis-keyword screening for journal entries is now handled by
// threatLexicon.php's screenJournalText(), called live at save time via
// saveJournalWithAlert() — see journalAlert.php. (Previously this constant
// lived here and was scanned only during syncRiskAlerts(); superseded.)

$action = $_GET['action'] ?? '';

match ($action) {
    'register' => handleRegister($pdo),
    'login'    => handleLogin($pdo),
    'admin_login' => handleAdminLogin($pdo),
    'counsellor_login' => handleCounsellorLogin($pdo),
    'checkin'  => handleCheckin($pdo),  
	'mood_history' => handleMoodHistory($pdo),
    'weekly_mood_summary' => handleWeeklyMoodSummary($pdo),
    'journal_create' => handleJournalCreate($pdo),
    'journal_list' => handleJournalList($pdo),
    'resource_list' => handleResourceList($pdo),
    'counsellor_list' => handleCounsellorList($pdo),
    'slot_list' => handleSlotList($pdo),
    'booking_create' => handleBookingCreate($pdo),
    'booking_current' => handleBookingCurrent($pdo),
    'booking_cancel' => handleBookingCancel($pdo),
    'post_create' => handlePostCreate($pdo),
    'post_list' => handlePostList($pdo),
    'post_like' => handlePostLike($pdo),
    'post_reply_create' => handlePostReplyCreate($pdo),
    'post_reply_list' => handlePostReplyList($pdo),
    'post_report' => handlePostReport($pdo),
    'achievements_summary' => handleAchievementsSummary($pdo),
    'notification_list' => handleNotificationList($pdo),
    'notification_unread_count' => handleNotificationUnreadCount($pdo),
    'notification_mark_all_read' => handleNotificationMarkAllRead($pdo),
    'moderation_queue' => handleModerationQueue($pdo),
    'moderation_dismiss' => handleModerationDismiss($pdo),
    'moderation_remove' => handleModerationRemove($pdo),
    'settings_get' => handleSettingsGet($pdo),
    'settings_update' => handleSettingsUpdate($pdo),
    'forgot_password_request' => handleForgotPasswordRequest($pdo),
    'forgot_password_verify' => handleForgotPasswordVerify($pdo),
    'forgot_password_reset' => handleForgotPasswordReset($pdo),
    'admin_dashboard_summary' => handleAdminDashboardSummary($pdo),
    'admin_user_list' => handleAdminUserList($pdo),
    'admin_user_create' => handleAdminUserCreate($pdo),
    'admin_user_update' => handleAdminUserUpdate($pdo),
    'admin_counsellor_list' => handleAdminCounsellorList($pdo),
    'admin_counsellor_create' => handleAdminCounsellorCreate($pdo),
    'admin_report_summary' => handleAdminReportSummary($pdo),
    'admin_report_export_csv' => handleAdminReportExportCsv($pdo),
    'admin_report_export_pdf' => handleAdminReportExportPdf($pdo),
    'admin_log_list' => handleAdminLogList($pdo),
    'admin_log_export_csv' => handleAdminLogExportCsv($pdo),
    'admin_platform_settings_get' => handleAdminPlatformSettingsGet($pdo),
    'admin_platform_settings_update' => handleAdminPlatformSettingsUpdate($pdo),
    'counsellor_dashboard_stats' => handleCounsellorDashboardStats($pdo),
    'counsellor_appointments_list' => handleCounsellorAppointmentsList($pdo),
    'counsellor_students_list' => handleCounsellorStudentsList($pdo),
    'counsellor_note_save' => handleCounsellorNoteSave($pdo),
    'risk_alerts_list' => handleRiskAlertsList($pdo),
    'risk_alert_update' => handleRiskAlertUpdate($pdo),
    'emotional_index_aggregate' => handleEmotionalIndexAggregate($pdo),
    'profile_get' => handleProfileGet($pdo),
    'profile_picture_upload' => handleProfilePictureUpload($pdo),
    'profile_picture_remove' => handleProfilePictureRemove($pdo),
    default    => jsonResponse(false, 'Invalid action.'),
};


// HELPERS

function jsonResponse(bool $success, string $message, array $data = []): void {
    echo json_encode(['success' => $success, 'message' => $message, 'data' => $data]);
    exit;
}

function sanitize(string $value): string {
    return htmlspecialchars(strip_tags(trim($value)));
}

// REGISTER

function handleRegister(PDO $pdo): void {
    // NOTE: names below match the "name" attributes in register.php's <form>
    // (full_name, student_number, email, password) — keep these in sync.
    $full_name      = sanitize($_POST['full_name'] ?? '');
    $student_number = sanitize($_POST['student_number'] ?? '');
    $email          = sanitize($_POST['email'] ?? '');
    $password       = $_POST['password'] ?? '';
    $popiaAgree     = $_POST['popiaAgree'] ?? '';

    if ($full_name === '' || $student_number === '' || $email === '' || $password === '') {
        jsonResponse(false, 'Make sure you do not leave any field empty.');
    }

    // Full name: at least two words (name + surname), each more than 2
    // characters, letters only.
    if (!preg_match('/^[A-Za-z]{3,}(\s[A-Za-z]{3,})+$/', $full_name)) {
        jsonResponse(false, 'Please enter your name and surname.');
    }

    // Student number: exactly 9 digits, must start with 402.
    if (!preg_match('/^402\d{6}$/', $student_number)) {
        jsonResponse(false, 'Please enter a valid student number.');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        jsonResponse(false, 'Invalid email address.');
    }

    $expected_email = $student_number . '@my.richfield.ac.za';
    if (strtolower($email) !== strtolower($expected_email)) {
        jsonResponse(false, 'Email must match your student number (' . $expected_email . ').');
    }

    // Password: at least 8 characters, one uppercase letter, one special character.
    if (strlen($password) < 8) {
        jsonResponse(false, 'Password must be at least 8 characters long.');
    }
    if (!preg_match('/[A-Z]/', $password)) {
        jsonResponse(false, 'Password must include at least one uppercase letter.');
    }
    if (!preg_match('/[!@#$%^&*()_+\-=\[\]{};\':"\\\\|,.<>\/?]/', $password)) {
        jsonResponse(false, 'Password must include at least one special character.');
    }

    if ($popiaAgree === '') {
        jsonResponse(false, 'You must agree to the POPIA Privacy Policy to register.');
    }

    // Check if email already exists
    $stmt = $pdo->prepare('SELECT user_id FROM users WHERE email = ?');
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        jsonResponse(false, 'An account with this email already exists.');
    }

    // Check if student number already exists
    $stmt = $pdo->prepare('SELECT user_id FROM users WHERE student_number = ?');
    $stmt->execute([$student_number]);
    if ($stmt->fetch()) {
        jsonResponse(false, 'This student number is already registered.');
    }

    $password_hash = password_hash($password, PASSWORD_BCRYPT);

    // Every public registration is hardcoded to the student role.
    // Counsellor and admin accounts are created separately by an admin — never through this endpoint.
    $stmt = $pdo->prepare('
        INSERT INTO users (full_name, student_number, email, password_hash, role)
        VALUES (?, ?, ?, ?, ?)
    ');
    $stmt->execute([$full_name, $student_number, $email, $password_hash, 'student']);

    jsonResponse(true, 'Registration successful. You can now log in.');
}

// LOGIN


function createAuditLog(PDO $pdo, ?int $actorUserId, string $action, ?string $targetTable = null, ?int $targetId = null, ?string $details = null): void {
    // Global kill switch — see platform_settings note in wellnesshub.sql.
    // When off, NOTHING gets logged, including security-relevant actions
    // like user suspension or account creation. There is no carve-out.
    $stmt = $pdo->query('SELECT audit_logging_enabled FROM platform_settings WHERE id = 1');
    $row = $stmt->fetch();
    if ($row && !(int) $row['audit_logging_enabled']) {
        return;
    }

    $stmt = $pdo->prepare('
        INSERT INTO auditlog (actor_user_id, action, target_table, target_id, details)
        VALUES (:actor, :action, :target_table, :target_id, :details)
    ');
    $stmt->execute([
        ':actor' => $actorUserId,
        ':action' => $action,
        ':target_table' => $targetTable,
        ':target_id' => $targetId,
        ':details' => $details,
    ]);
}

function recordLogin(PDO $pdo, array $user): void {
    session_regenerate_id(true);
    $_SESSION['user_id']   = $user['user_id'];
    $_SESSION['full_name'] = $user['full_name'];
    $_SESSION['email']     = $user['email'];
    $_SESSION['role']      = $user['role'];
    $_SESSION['profile_picture'] = $user['profile_picture'];

    $stmt = $pdo->prepare('UPDATE users SET last_login_at = NOW() WHERE user_id = :id');
    $stmt->execute([':id' => $user['user_id']]);

    createAuditLog($pdo, $user['user_id'], 'login_success', 'users', $user['user_id'], ucfirst($user['role']) . ' login successful.');
}

function handleLogin(PDO $pdo): void {
    // NOTE: names below match the "name" attributes in login.php's <form>
    // (email, password) — keep these in sync.
    $email    = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        jsonResponse(false, 'Please enter both email and password.');
    }

    $stmt = $pdo->prepare('SELECT user_id, full_name, email, password_hash, role, is_active, profile_picture FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // Deliberately vague on failure — do not reveal whether the email
    // exists or the password was wrong, so this endpoint can't be used
    // to enumerate registered accounts.
    if (!$user || !password_verify($password, $user['password_hash'])) {
        createAuditLog($pdo, null, 'login_failed', 'users', null, "Failed student login attempt for {$email}.");
        jsonResponse(false, 'Invalid email or password.');
    }

    if (!(int) $user['is_active']) {
        jsonResponse(false, 'Your account has been suspended. Contact an administrator.');
    }

    recordLogin($pdo, $user);

    jsonResponse(true, 'Login successful.', ['role' => $user['role']]);
}

function handleAdminLogin(PDO $pdo): void {
    $email    = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        jsonResponse(false, 'Please enter both email and password.');
    }

    $stmt = $pdo->prepare('SELECT user_id, full_name, email, password_hash, role, is_active, profile_picture FROM users WHERE email = ? AND role = ?');
    $stmt->execute([$email, 'admin']);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        createAuditLog($pdo, null, 'login_failed', 'users', null, "Failed admin login attempt for {$email}.");
        jsonResponse(false, 'Invalid email or password.');
    }

    if (!(int) $user['is_active']) {
        jsonResponse(false, 'Your account has been suspended. Contact another administrator.');
    }

    recordLogin($pdo, $user);

    jsonResponse(true, 'Login successful.', ['redirect' => 'admin-dashboard.php']);
}

function handleCounsellorLogin(PDO $pdo): void {
    $email    = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        jsonResponse(false, 'Please enter both email and password.');
    }

    if (!str_ends_with(strtolower($email), strtolower(COUNSELLOR_EMAIL_DOMAIN))) {
        createAuditLog($pdo, null, 'login_failed', 'users', null, "Failed counsellor login attempt for {$email}.");
        jsonResponse(false, 'Invalid email or password.');
    }

    if (strlen($password) < 3 || substr($password, 0, 3) !== COUNSELLOR_SHARED_CODE) {
        createAuditLog($pdo, null, 'login_failed', 'users', null, "Failed counsellor login attempt for {$email}.");
        jsonResponse(false, 'Invalid email or password.');
    }

    $stmt = $pdo->prepare('SELECT user_id, full_name, email, password_hash, role, is_active, profile_picture FROM users WHERE email = ? AND role = ?');
    $stmt->execute([$email, 'counsellor']);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        createAuditLog($pdo, null, 'login_failed', 'users', null, "Failed counsellor login attempt for {$email}.");
        jsonResponse(false, 'Invalid email or password.');
    }

    if (!(int) $user['is_active']) {
        jsonResponse(false, 'Your account has been suspended. Contact an administrator.');
    }

    recordLogin($pdo, $user);

    jsonResponse(true, 'Login successful.', ['redirect' => 'counsellor-dashboard.php']);
}

 
// CHECK-IN
 
function handleCheckin(PDO $pdo): void {
    // Must be logged in — session set by handleLogin()
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in to check in.');
    }
 
    $user_id      = $_SESSION['user_id'];
    $mood         = $_POST['mood'] ?? '';
    $stress_level = $_POST['stress_level'] ?? null;
 
    $allowed_moods = ['great', 'good', 'okay', 'low', 'struggling'];
    if (!in_array($mood, $allowed_moods, true)) {
        jsonResponse(false, 'Invalid mood value.');
    }
 
    if (!is_numeric($stress_level) || $stress_level < 0 || $stress_level > 10) {
        jsonResponse(false, 'Stress level must be a number between 0 and 10.');
    }
    $stress_level = (int) $stress_level;
 
    $checkin_date = date('Y-m-d'); // server date — one check-in per calendar day
 
    // Insert, or overwrite today's entry if the student already checked in
    $stmt = $pdo->prepare('
        INSERT INTO mood_checkins (user_id, mood, stress_level, checkin_date)
        VALUES (:user_id, :mood, :stress_level, :checkin_date)
        ON DUPLICATE KEY UPDATE
            mood = VALUES(mood),
            stress_level = VALUES(stress_level)
    ');
    $stmt->execute([
        ':user_id'      => $user_id,
        ':mood'         => $mood,
        ':stress_level' => $stress_level,
        ':checkin_date' => $checkin_date,
    ]);
 
    jsonResponse(true, 'Check-in saved.', [
        'mood'         => $mood,
        'stress_level' => $stress_level,
        'checkin_date' => $checkin_date,
    ]);
}
 
//Mood History
  
function handleMoodHistory(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $user_id = $_SESSION['user_id'];
 
    $month = isset($_GET['month']) ? (int) $_GET['month'] : (int) date('n');
    $year  = isset($_GET['year'])  ? (int) $_GET['year']  : (int) date('Y');
 
    if ($month < 1 || $month > 12) {
        jsonResponse(false, 'Invalid month.');
    }
 
    // Calendar view: every check-in in the requested month (for the emoji grid)
    $stmt = $pdo->prepare('
        SELECT DAY(checkin_date) AS day, mood
        FROM mood_checkins
        WHERE user_id = :user_id
          AND YEAR(checkin_date) = :year
          AND MONTH(checkin_date) = :month
        ORDER BY checkin_date ASC
    ');
    $stmt->execute([':user_id' => $user_id, ':year' => $year, ':month' => $month]);
    $calendar = $stmt->fetchAll();
 
    // Last 7 days: trend line (needs a numeric mood_score) + stress bars
    $stmt = $pdo->prepare("
        SELECT
            checkin_date,
            mood,
            stress_level,
            CASE mood
                WHEN 'struggling' THEN 1
                WHEN 'low'        THEN 2
                WHEN 'okay'       THEN 3
                WHEN 'good'       THEN 4
                WHEN 'great'      THEN 5
            END AS mood_score
        FROM mood_checkins
        WHERE user_id = :user_id
          AND checkin_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
        ORDER BY checkin_date ASC
    ");
    $stmt->execute([':user_id' => $user_id]);
    $week = $stmt->fetchAll();
 
    jsonResponse(true, 'Mood history retrieved.', [
        'calendar' => $calendar,  // [{day: 4, mood: 'good'}, ...]
        'week'     => $week,      // [{checkin_date, mood, stress_level, mood_score}, ...]
    ]);
}
 
// WEEKLY MOOD SUMMARY

/*
 * ASSUMPTION FLAGGED FOR THE TEAM:
 * The dashboard mockup's legend has 4 buckets (Fine/Positive/Neutral/Low with
 * CSS classes calm/neutral/low/risk) but mood_checkins has 5 mood values.
 * Mapped as: calm=great, neutral=good, low=okay, risk=low+struggling (merged).
 * This is a clinical-ish categorization choice, not just a coding one —
 * worth confirming with your supervisor/team rather than treating as final.
 */
function handleWeeklyMoodSummary(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $user_id = $_SESSION['user_id'];

    $stmt = $pdo->prepare('
        SELECT mood, COUNT(*) AS cnt
        FROM mood_checkins
        WHERE user_id = :user_id
          AND checkin_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
        GROUP BY mood
    ');
    $stmt->execute([':user_id' => $user_id]);
    $rows = $stmt->fetchAll();

    $counts = ['great' => 0, 'good' => 0, 'okay' => 0, 'low' => 0, 'struggling' => 0];
    foreach ($rows as $row) {
        $counts[$row['mood']] = (int) $row['cnt'];
    }

    $total = array_sum($counts);

    $buckets = [
        'calm'    => $counts['great'],
        'neutral' => $counts['good'],
        'low'     => $counts['okay'],
        'risk'    => $counts['low'] + $counts['struggling'],
    ];

    $percentages = [];
    foreach ($buckets as $key => $count) {
        $percentages[$key] = $total > 0 ? round(($count / $total) * 100) : 0;
    }

    jsonResponse(true, 'Weekly summary retrieved.', [
        'total_checkins' => $total,
        'percentages'     => $percentages,
    ]);
}

// JOURNAL

function handleJournalCreate(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $user_id = $_SESSION['user_id'];

    $raw_content = $_POST['content'] ?? '';
    $emotion = trim($_POST['emotion'] ?? '');

    // Byte-size guard BEFORE parsing — a large pasted image should fail fast
    // rather than spend CPU running it through DOMDocument first.
    if (strlen($raw_content) > 4 * 1024 * 1024) {
        jsonResponse(false, 'Journal entry is too large (max ~4MB, including any photo).');
    }

    $content = sanitizeJournalHtml($raw_content);
    $plainCheck = trim(strip_tags($content));
    $hasImage = stripos($content, '<img') !== false;

    if ($plainCheck === '' && !$hasImage) {
        jsonResponse(false, 'Journal entry cannot be empty.');
    }

    $allowed_emotions = ['Grateful', 'Calm', 'Hopeful', 'Anxious', 'Frustrated'];
    if ($emotion !== '' && !in_array($emotion, $allowed_emotions, true)) {
        jsonResponse(false, 'Invalid emotion tag.');
    }
    $emotion_value = $emotion === '' ? null : $emotion;

    jsonResponse(true, 'Journal entry saved.', saveJournalWithAlert($pdo, (int) $user_id, $content, $emotion_value));
}

/*
 * Allowlist HTML sanitizer for journal entries.
 *
 * The editor is a contenteditable div, so incoming content is real HTML,
 * not plain text — arbitrary markup can arrive via paste, not just via the
 * toolbar. This walks the DOM and:
 *   - drops <script>/<style> entirely (tag + contents)
 *   - unwraps any other disallowed tag (keeps the text/children, drops the tag)
 *   - strips ALL attributes except a hand-checked href on <a> (http/https only)
 *     and a hand-checked src on <img> (must be a base64 image data: URI —
 *     no remote image URLs, so nothing here ever makes an outbound request)
 * This is intentionally conservative — it never trusts an attribute value
 * just because the tag is allowed.
 */
function sanitizeJournalHtml(string $html): string {
    $html = trim($html);
    if ($html === '') {
        return '';
    }

    libxml_use_internal_errors(true);
    $doc = new DOMDocument();
    $doc->loadHTML(
        '<?xml encoding="utf-8" ?><div id="__root">' . $html . '</div>',
        LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD
    );
    libxml_clear_errors();

    $root = $doc->getElementById('__root');
    if (!$root) {
        return '';
    }

    $allowedTags = ['b', 'strong', 'i', 'em', 'u', 'ul', 'ol', 'li', 'br', 'p', 'div', 'span', 'a', 'img'];
    sanitizeJournalNode($root, $allowedTags);

    $result = '';
    foreach ($root->childNodes as $child) {
        $result .= $doc->saveHTML($child);
    }
    return $result;
}

function sanitizeJournalNode(DOMNode $node, array $allowedTags): void {
    // Snapshot child list first — we mutate the tree (unwrap/remove) while iterating.
    $children = iterator_to_array($node->childNodes);

    foreach ($children as $child) {
        if ($child->nodeType !== XML_ELEMENT_NODE) {
            continue;
        }
        $tag = strtolower($child->nodeName);

        if ($tag === 'script' || $tag === 'style') {
            $child->parentNode->removeChild($child);
            continue;
        }

        if (!in_array($tag, $allowedTags, true)) {
            while ($child->firstChild) {
                $child->parentNode->insertBefore($child->firstChild, $child);
            }
            $child->parentNode->removeChild($child);
            continue;
        }

        $href = $tag === 'a' ? $child->getAttribute('href') : null;
        $src  = $tag === 'img' ? $child->getAttribute('src') : null;

        foreach (iterator_to_array($child->attributes ?? []) as $attr) {
            $child->removeAttribute($attr->name);
        }

        if ($tag === 'a') {
            if ($href !== null && preg_match('#^https?://#i', $href)) {
                $child->setAttribute('href', $href);
                $child->setAttribute('target', '_blank');
                $child->setAttribute('rel', 'noopener noreferrer');
            } else {
                // No valid http(s) href — unwrap rather than leave a dead/unsafe link
                while ($child->firstChild) {
                    $child->parentNode->insertBefore($child->firstChild, $child);
                }
                $child->parentNode->removeChild($child);
                continue;
            }
        }

        if ($tag === 'img') {
            $validImage = $src !== null
                && preg_match('#^data:image/(png|jpe?g|gif|webp);base64,[A-Za-z0-9+/=]+$#', $src)
                && strlen($src) <= 3 * 1024 * 1024; // ~3MB per image after base64 overhead
            if ($validImage) {
                $child->setAttribute('src', $src);
                $child->setAttribute('style', 'max-width:100%; border-radius:8px; margin:8px 0; display:block;');
            } else {
                $child->parentNode->removeChild($child);
                continue;
            }
        }

        sanitizeJournalNode($child, $allowedTags);
    }
}

function handleJournalList(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $user_id = $_SESSION['user_id'];

    // Bounded, server-controlled int — safe to interpolate directly since
    // LIMIT placeholders are unreliable under PDO's emulated prepares.
    $limit = isset($_GET['limit']) ? (int) $_GET['limit'] : 5;
    $limit = max(1, min($limit, 50));

    $stmt = $pdo->prepare("
        SELECT entry_id, content, emotion, created_at
        FROM journal_entries
        WHERE user_id = :user_id
        ORDER BY created_at DESC
        LIMIT {$limit}
    ");
    $stmt->execute([':user_id' => $user_id]);
    $entries = $stmt->fetchAll();

    jsonResponse(true, 'Journal entries retrieved.', ['entries' => $entries]);
}

// SELF-HELP LIBRARY (read-only for students — curated by counsellors/admins)

function handleResourceList(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }

    $category = trim($_GET['category'] ?? '');
    $allowed_categories = ['Anxiety', 'Academic Stress', 'Sleep', 'Relationships', 'Self Confidence'];

    if ($category !== '' && !in_array($category, $allowed_categories, true)) {
        jsonResponse(false, 'Invalid category.');
    }

    // Crisis Support resources are always included, regardless of the
    // selected category — a crisis contact should never be filterable out.
    if ($category === '') {
        $stmt = $pdo->prepare('SELECT resource_id, title, subtitle, category, resource_type, icon, url FROM resources ORDER BY category, resource_id');
        $stmt->execute();
    } else {
        $stmt = $pdo->prepare("
            SELECT resource_id, title, subtitle, category, resource_type, icon, url
            FROM resources
            WHERE category = :category OR category = 'Crisis Support'
            ORDER BY (category = 'Crisis Support'), resource_id
        ");
        $stmt->execute([':category' => $category]);
    }

    jsonResponse(true, 'Resources retrieved.', ['resources' => $stmt->fetchAll()]);
}

// COUNSELLING BOOKING

function handleCounsellorList(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $stmt = $pdo->query('SELECT counsellor_id, name, specialties, avatar FROM counsellors ORDER BY name');
    jsonResponse(true, 'Counsellors retrieved.', ['counsellors' => $stmt->fetchAll()]);
}

function handleSlotList(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }

    $counsellor_id = (int) ($_GET['counsellor_id'] ?? 0);
    $date = $_GET['date'] ?? '';

    if ($counsellor_id <= 0 || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        jsonResponse(false, 'Counsellor and date are required.');
    }

    $dt = DateTime::createFromFormat('Y-m-d', $date);
    if (!$dt || $dt->format('Y-m-d') !== $date) {
        jsonResponse(false, 'Invalid date.');
    }

    $today = new DateTime('today');
    if ($dt < $today) {
        jsonResponse(true, 'No slots — date is in the past.', ['slots' => []]);
    }

    $weekday = (int) $dt->format('N'); // 1=Mon .. 7=Sun
    if ($weekday >= 6) {
        jsonResponse(true, 'No slots — counsellors are only available on weekdays.', ['slots' => []]);
    }

    $stmt = $pdo->prepare('
        SELECT session_time FROM bookings
        WHERE counsellor_id = :counsellor_id AND session_date = :date AND status = "booked"
    ');
    $stmt->execute([':counsellor_id' => $counsellor_id, ':date' => $date]);
    $taken = array_column($stmt->fetchAll(), 'session_time');

    $slots = [];
    foreach (BOOKING_SLOT_TEMPLATE as $time) {
        $slots[] = ['time' => substr($time, 0, 5), 'available' => !in_array($time, $taken, true)];
    }

    jsonResponse(true, 'Slots retrieved.', ['slots' => $slots]);
}

function handleBookingCreate(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $user_id = $_SESSION['user_id'];

    $counsellor_id = (int) ($_POST['counsellor_id'] ?? 0);
    $date = $_POST['date'] ?? '';
    $time = $_POST['time'] ?? '';

    if ($counsellor_id <= 0 || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        jsonResponse(false, 'Counsellor and date are required.');
    }
    if (!preg_match('/^\d{2}:\d{2}$/', $time)) {
        jsonResponse(false, 'Invalid time slot.');
    }
    $time_full = $time . ':00';
    if (!in_array($time_full, BOOKING_SLOT_TEMPLATE, true)) {
        jsonResponse(false, 'That time slot does not exist.');
    }

    $dt = DateTime::createFromFormat('Y-m-d', $date);
    if (!$dt || $dt->format('Y-m-d') !== $date || $dt < new DateTime('today')) {
        jsonResponse(false, 'Invalid or past date.');
    }
    if ((int) $dt->format('N') >= 6) {
        jsonResponse(false, 'Counsellors are only available on weekdays.');
    }

    // Enforce: one active upcoming appointment per student at a time —
    // matches the UI, which only ever shows a single "Upcoming Appointment" card.
    $stmt = $pdo->prepare('
        SELECT booking_id FROM bookings
        WHERE user_id = :user_id AND status = "booked" AND session_date >= CURDATE()
    ');
    $stmt->execute([':user_id' => $user_id]);
    if ($stmt->fetch()) {
        jsonResponse(false, 'You already have an upcoming appointment. Cancel or reschedule it first.');
    }

    // Re-check the slot is still free right before inserting (best-effort —
    // a true race condition would need a DB-level lock, out of scope here).
    $stmt = $pdo->prepare('
        SELECT booking_id FROM bookings
        WHERE counsellor_id = :counsellor_id AND session_date = :date AND session_time = :time AND status = "booked"
    ');
    $stmt->execute([':counsellor_id' => $counsellor_id, ':date' => $date, ':time' => $time_full]);
    if ($stmt->fetch()) {
        jsonResponse(false, 'That slot was just booked by someone else. Please pick another.');
    }

    $stmt = $pdo->prepare('
        INSERT INTO bookings (user_id, counsellor_id, session_date, session_time)
        VALUES (:user_id, :counsellor_id, :date, :time)
    ');
    $stmt->execute([
        ':user_id' => $user_id,
        ':counsellor_id' => $counsellor_id,
        ':date' => $date,
        ':time' => $time_full,
    ]);

    $stmt = $pdo->prepare('SELECT name FROM counsellors WHERE counsellor_id = :id');
    $stmt->execute([':id' => $counsellor_id]);
    $counsellorName = $stmt->fetch()['name'] ?? 'your counsellor';
    $displayDate = $dt->format('l, j F Y');
    if (userWantsBookingReminders($pdo, $user_id)) {
        createNotification(
            $pdo, $user_id, 'booking_created',
            'Counselling session booked',
            "Your session with {$counsellorName} is on {$displayDate} at {$time}."
        );
    }

    jsonResponse(true, 'Session booked.', ['booking_id' => $pdo->lastInsertId()]);
}

function handleBookingCurrent(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $user_id = $_SESSION['user_id'];

    $stmt = $pdo->prepare('
        SELECT b.booking_id, b.session_date, b.session_time, c.name AS counsellor_name, c.avatar
        FROM bookings b
        JOIN counsellors c ON c.counsellor_id = b.counsellor_id
        WHERE b.user_id = :user_id AND b.status = "booked" AND b.session_date >= CURDATE()
        ORDER BY b.session_date, b.session_time
        LIMIT 1
    ');
    $stmt->execute([':user_id' => $user_id]);
    $booking = $stmt->fetch();

    jsonResponse(true, 'Current booking retrieved.', ['booking' => $booking ?: null]);
}

function handleBookingCancel(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $user_id = $_SESSION['user_id'];
    $booking_id = (int) ($_POST['booking_id'] ?? 0);

    if ($booking_id <= 0) {
        jsonResponse(false, 'Invalid booking.');
    }

    // Fetch details before cancelling so the notification can name the slot.
    $stmt = $pdo->prepare('SELECT session_date, session_time FROM bookings WHERE booking_id = :id AND user_id = :user_id');
    $stmt->execute([':id' => $booking_id, ':user_id' => $user_id]);
    $bookingDetails = $stmt->fetch();

    // WHERE includes user_id so a student can never cancel someone else's booking.
    $stmt = $pdo->prepare('
        UPDATE bookings SET status = "cancelled"
        WHERE booking_id = :booking_id AND user_id = :user_id AND status = "booked"
    ');
    $stmt->execute([':booking_id' => $booking_id, ':user_id' => $user_id]);

    if ($stmt->rowCount() === 0) {
        jsonResponse(false, 'Booking not found, not yours, or already cancelled.');
    }

    if ($bookingDetails && userWantsBookingReminders($pdo, $user_id)) {
        $displayDate = (new DateTime($bookingDetails['session_date']))->format('l, j F Y');
        $displayTime = substr($bookingDetails['session_time'], 0, 5);
        createNotification(
            $pdo, $user_id, 'booking_cancelled',
            'Counselling session cancelled',
            "Your session on {$displayDate} at {$displayTime} was cancelled."
        );
    }

    jsonResponse(true, 'Appointment cancelled.');
}

// PEER SUPPORT BOARD
//
// Posts are pseudonymous, not anonymous in the database — every post,
// reply, and report is tied to user_id so staff could follow up if needed.
// Only the DISPLAY hides identity (frontend always shows "Anonymous
// Student"). See peer_support.sql for the moderation-gap note: reporting a
// post currently just saves a row — there is no admin/counsellor screen
// that reads post_reports yet.

function handlePostCreate(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $user_id = $_SESSION['user_id'];

    $content = trim(strip_tags($_POST['content'] ?? ''));
    $category = trim($_POST['category'] ?? 'Support');
    $allowed_categories = ['Support', 'Vent', 'Advice', 'Encouragement'];

    if ($content === '') {
        jsonResponse(false, 'Write something before posting.');
    }
    if (mb_strlen($content) > 2000) {
        jsonResponse(false, 'Post is too long (max 2000 characters).');
    }
    if (!in_array($category, $allowed_categories, true)) {
        $category = 'Support';
    }

    $stmt = $pdo->prepare('INSERT INTO posts (user_id, content, category) VALUES (:user_id, :content, :category)');
    $stmt->execute([':user_id' => $user_id, ':content' => $content, ':category' => $category]);

    jsonResponse(true, 'Posted.', [
        'post_id' => $pdo->lastInsertId(),
        'content' => $content,
        'category' => $category,
        'created_at' => date('Y-m-d H:i:s'),
        'like_count' => 0,
        'reply_count' => 0,
        'liked_by_me' => false,
        'is_mine' => true,
    ]);
}

function handlePostList(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $user_id = $_SESSION['user_id'];
    $tab = $_GET['tab'] ?? 'recent';

    $where = 'WHERE p.is_removed = 0';
    $order = 'p.created_at DESC';
    if ($tab === 'mine') {
        $where .= ' AND p.user_id = :me';
    } elseif ($tab === 'popular') {
        $order = 'like_count DESC, p.created_at DESC';
    }

    $stmt = $pdo->prepare("
        SELECT
            p.post_id, p.content, p.category, p.created_at,
            (SELECT COUNT(*) FROM post_likes pl WHERE pl.post_id = p.post_id) AS like_count,
            (SELECT COUNT(*) FROM post_replies pr WHERE pr.post_id = p.post_id) AS reply_count,
            EXISTS(SELECT 1 FROM post_likes pl2 WHERE pl2.post_id = p.post_id AND pl2.user_id = :me) AS liked_by_me,
            (p.user_id = :me) AS is_mine
        FROM posts p
        {$where}
        ORDER BY {$order}
        LIMIT 50
    ");
    $stmt->execute([':me' => $user_id]);
    $posts = $stmt->fetchAll();

    // Cast MySQL's 0/1 to real booleans for a cleaner frontend contract
    foreach ($posts as &$p) {
        $p['liked_by_me'] = (bool) $p['liked_by_me'];
        $p['is_mine'] = (bool) $p['is_mine'];
        $p['like_count'] = (int) $p['like_count'];
        $p['reply_count'] = (int) $p['reply_count'];
    }

    jsonResponse(true, 'Posts retrieved.', ['posts' => $posts]);
}

function handlePostLike(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $user_id = $_SESSION['user_id'];
    $post_id = (int) ($_POST['post_id'] ?? 0);
    if ($post_id <= 0) {
        jsonResponse(false, 'Invalid post.');
    }

    $stmt = $pdo->prepare('SELECT like_id FROM post_likes WHERE post_id = :post_id AND user_id = :user_id');
    $stmt->execute([':post_id' => $post_id, ':user_id' => $user_id]);
    $existing = $stmt->fetch();

    if ($existing) {
        $stmt = $pdo->prepare('DELETE FROM post_likes WHERE like_id = :like_id');
        $stmt->execute([':like_id' => $existing['like_id']]);
        $liked = false;
    } else {
        $stmt = $pdo->prepare('INSERT INTO post_likes (post_id, user_id) VALUES (:post_id, :user_id)');
        $stmt->execute([':post_id' => $post_id, ':user_id' => $user_id]);
        $liked = true;
    }

    $stmt = $pdo->prepare('SELECT COUNT(*) AS cnt FROM post_likes WHERE post_id = :post_id');
    $stmt->execute([':post_id' => $post_id]);
    $count = (int) $stmt->fetch()['cnt'];

    jsonResponse(true, $liked ? 'Liked.' : 'Unliked.', ['liked_by_me' => $liked, 'like_count' => $count]);
}

function handlePostReplyCreate(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $user_id = $_SESSION['user_id'];
    $post_id = (int) ($_POST['post_id'] ?? 0);
    $content = trim(strip_tags($_POST['content'] ?? ''));

    if ($post_id <= 0) {
        jsonResponse(false, 'Invalid post.');
    }
    if ($content === '') {
        jsonResponse(false, 'Write a reply before submitting.');
    }
    if (mb_strlen($content) > 1000) {
        jsonResponse(false, 'Reply is too long (max 1000 characters).');
    }

    $stmt = $pdo->prepare('SELECT post_id FROM posts WHERE post_id = :post_id');
    $stmt->execute([':post_id' => $post_id]);
    if (!$stmt->fetch()) {
        jsonResponse(false, 'That post no longer exists.');
    }

    $stmt = $pdo->prepare('INSERT INTO post_replies (post_id, user_id, content) VALUES (:post_id, :user_id, :content)');
    $stmt->execute([':post_id' => $post_id, ':user_id' => $user_id, ':content' => $content]);

    jsonResponse(true, 'Reply posted.', [
        'reply_id' => $pdo->lastInsertId(),
        'content' => $content,
        'created_at' => date('Y-m-d H:i:s'),
    ]);
}

function handlePostReplyList(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $post_id = (int) ($_GET['post_id'] ?? 0);
    if ($post_id <= 0) {
        jsonResponse(false, 'Invalid post.');
    }

    $stmt = $pdo->prepare('SELECT reply_id, content, created_at FROM post_replies WHERE post_id = :post_id ORDER BY created_at ASC');
    $stmt->execute([':post_id' => $post_id]);

    jsonResponse(true, 'Replies retrieved.', ['replies' => $stmt->fetchAll()]);
}

function handlePostReport(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $user_id = $_SESSION['user_id'];
    $post_id = (int) ($_POST['post_id'] ?? 0);
    if ($post_id <= 0) {
        jsonResponse(false, 'Invalid post.');
    }

    $stmt = $pdo->prepare('SELECT report_id FROM post_reports WHERE post_id = :post_id AND user_id = :user_id');
    $stmt->execute([':post_id' => $post_id, ':user_id' => $user_id]);
    if ($stmt->fetch()) {
        jsonResponse(false, 'You already reported this post.');
    }

    $stmt = $pdo->prepare('INSERT INTO post_reports (post_id, user_id) VALUES (:post_id, :user_id)');
    $stmt->execute([':post_id' => $post_id, ':user_id' => $user_id]);

    jsonResponse(true, 'Post reported. Thank you for helping keep this space safe.');
}

// ACHIEVEMENTS
//
// XP weights below are MY OWN invented default (+10 check-in, +15 journal
// entry, +5 peer post, +5 peer reply, +20 counselling booking; 1000 XP per
// level) — nothing in the spec defined a scoring system, so this is a
// placeholder game-design choice, not something to treat as agreed/final.
//
// "Resources Used" has no real number behind it: nothing tracks resource
// views/clicks anywhere in the project. Rather than fabricate a count, the
// stat is returned as null and the frontend shows it as untracked.

function longestCheckinStreak(array $sortedDates): int {
    if (empty($sortedDates)) return 0;
    $longest = 1;
    $current = 1;
    for ($i = 1; $i < count($sortedDates); $i++) {
        $prev = new DateTime($sortedDates[$i - 1]);
        $cur = new DateTime($sortedDates[$i]);
        $diff = (int) $prev->diff($cur)->days;
        $current = ($diff === 1) ? $current + 1 : 1;
        $longest = max($longest, $current);
    }
    return $longest;
}

function handleAchievementsSummary(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $user_id = $_SESSION['user_id'];

    $stmt = $pdo->prepare('SELECT checkin_date FROM mood_checkins WHERE user_id = :id ORDER BY checkin_date ASC');
    $stmt->execute([':id' => $user_id]);
    $checkinDates = array_column($stmt->fetchAll(), 'checkin_date');
    $checkinCount = count($checkinDates);

    $stmt = $pdo->prepare('SELECT COUNT(*) AS cnt FROM journal_entries WHERE user_id = :id');
    $stmt->execute([':id' => $user_id]);
    $journalCount = (int) $stmt->fetch()['cnt'];

    $stmt = $pdo->prepare('SELECT COUNT(*) AS cnt FROM posts WHERE user_id = :id');
    $stmt->execute([':id' => $user_id]);
    $postCount = (int) $stmt->fetch()['cnt'];

    $stmt = $pdo->prepare('SELECT COUNT(*) AS cnt FROM post_replies WHERE user_id = :id');
    $stmt->execute([':id' => $user_id]);
    $replyCount = (int) $stmt->fetch()['cnt'];

    $stmt = $pdo->prepare("SELECT COUNT(*) AS cnt FROM bookings WHERE user_id = :id AND status IN ('booked','completed')");
    $stmt->execute([':id' => $user_id]);
    $bookingCount = (int) $stmt->fetch()['cnt'];

    $stmt = $pdo->prepare('
        SELECT d FROM (
            SELECT checkin_date AS d FROM mood_checkins WHERE user_id = :id
            UNION
            SELECT DATE(created_at) AS d FROM journal_entries WHERE user_id = :id
            UNION
            SELECT DATE(created_at) AS d FROM posts WHERE user_id = :id
            UNION
            SELECT DATE(created_at) AS d FROM post_replies WHERE user_id = :id
        ) AS activity
    ');
    $stmt->execute([':id' => $user_id]);
    $daysActive = count($stmt->fetchAll());

    $xpPerLevel = 1000;
    $xp = ($checkinCount * 10) + ($journalCount * 15) + ($postCount * 5) + ($replyCount * 5) + ($bookingCount * 20);
    $level = intdiv($xp, $xpPerLevel) + 1;
    $xpIntoLevel = $xp % $xpPerLevel;

    $streak = longestCheckinStreak($checkinDates);
    $featuresUsedCount = (int) ($checkinCount > 0) + (int) ($journalCount > 0) + (int) ($bookingCount > 0) + (int) (($postCount + $replyCount) > 0);

    $badges = [
        ['key' => 'streak', 'name' => '7 Day Check-in Streak', 'icon' => '🔥', 'unlocked' => $streak >= 7],
        ['key' => 'first_journal', 'name' => 'First Journal Entry', 'icon' => '🛡', 'unlocked' => $journalCount >= 1],
        ['key' => 'explorer', 'name' => 'Wellness Explorer', 'icon' => '🏆', 'unlocked' => $featuresUsedCount >= 3],
        ['key' => 'peer_helper', 'name' => 'Peer Helper', 'icon' => '☘', 'unlocked' => $replyCount >= 1],
    ];

    jsonResponse(true, 'Achievements retrieved.', [
        'xp' => $xp,
        'level' => $level,
        'xp_into_level' => $xpIntoLevel,
        'xp_per_level' => $xpPerLevel,
        'stats' => [
            'checkins' => $checkinCount,
            'journal_entries' => $journalCount,
            'resources_used' => null, // not tracked anywhere — see note above
            'days_active' => $daysActive,
        ],
        'badges' => $badges,
    ]);
}

// NOTIFICATIONS
//
// Only booking_created / booking_cancelled are real, stored notifications
// (triggered directly from handleBookingCreate/handleBookingCancel). A
// weekly "mood report ready" notice and a "new resource" notice both
// existed in the original mockup but aren't generated here — see
// notifications.sql for why (no cron/scheduler, no admin resource-add
// trigger exists in this project).

function createNotification(PDO $pdo, int $user_id, string $type, string $title, string $message): void {
    $stmt = $pdo->prepare('
        INSERT INTO notifications (user_id, type, title, message)
        VALUES (:user_id, :type, :title, :message)
    ');
    $stmt->execute([
        ':user_id' => $user_id,
        ':type' => $type,
        ':title' => $title,
        ':message' => $message,
    ]);
}

function handleNotificationList(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $user_id = $_SESSION['user_id'];

    $stmt = $pdo->prepare('
        SELECT notification_id, type, title, message, is_read, created_at
        FROM notifications
        WHERE user_id = :user_id
        ORDER BY created_at DESC
        LIMIT 30
    ');
    $stmt->execute([':user_id' => $user_id]);
    $notifications = $stmt->fetchAll();
    foreach ($notifications as &$n) {
        $n['is_read'] = (bool) $n['is_read'];
    }

    jsonResponse(true, 'Notifications retrieved.', ['notifications' => $notifications]);
}

function handleNotificationMarkAllRead(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $user_id = $_SESSION['user_id'];

    $stmt = $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = :user_id AND is_read = 0');
    $stmt->execute([':user_id' => $user_id]);

    jsonResponse(true, 'All notifications marked as read.');
}

// PEER SUPPORT MODERATION
//
// UPDATE: now gated to counsellor accounts only, via the same
// $_SESSION['role'] check used by counsellor-auth.php. This closes what was
// previously flagged as a real gap (any logged-in student could reach
// these endpoints) now that real counsellor login/roles exist.

function requireCounsellorRole(): void {
    if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'counsellor') {
        http_response_code(403);
        jsonResponse(false, 'Counsellor access required.');
    }
}

function handleModerationQueue(PDO $pdo): void {
    requireCounsellorRole();

    $stmt = $pdo->query('
        SELECT
            p.post_id, p.content, p.category, p.created_at, p.is_removed,
            (SELECT COUNT(*) FROM post_reports pr WHERE pr.post_id = p.post_id AND pr.reviewed = 0) AS pending_report_count
        FROM posts p
        WHERE p.post_id IN (SELECT post_id FROM post_reports WHERE reviewed = 0)
        ORDER BY pending_report_count DESC, p.created_at DESC
    ');
    $posts = $stmt->fetchAll();
    foreach ($posts as &$p) {
        $p['is_removed'] = (bool) $p['is_removed'];
        $p['pending_report_count'] = (int) $p['pending_report_count'];
    }

    jsonResponse(true, 'Moderation queue retrieved.', ['posts' => $posts]);
}

function handleModerationDismiss(PDO $pdo): void {
    requireCounsellorRole();
    $post_id = (int) ($_POST['post_id'] ?? 0);
    if ($post_id <= 0) {
        jsonResponse(false, 'Invalid post.');
    }

    $stmt = $pdo->prepare('UPDATE post_reports SET reviewed = 1 WHERE post_id = :post_id');
    $stmt->execute([':post_id' => $post_id]);

    jsonResponse(true, 'Reports dismissed — post stays up.');
}

function handleModerationRemove(PDO $pdo): void {
    requireCounsellorRole();
    $post_id = (int) ($_POST['post_id'] ?? 0);
    if ($post_id <= 0) {
        jsonResponse(false, 'Invalid post.');
    }

    $stmt = $pdo->prepare('UPDATE posts SET is_removed = 1 WHERE post_id = :post_id');
    $stmt->execute([':post_id' => $post_id]);

    $stmt = $pdo->prepare('UPDATE post_reports SET reviewed = 1 WHERE post_id = :post_id');
    $stmt->execute([':post_id' => $post_id]);

    jsonResponse(true, 'Post removed from the board.');
}

// SETTINGS

function handleSettingsGet(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $user_id = $_SESSION['user_id'];

    $stmt = $pdo->prepare('SELECT dark_mode, booking_reminders, weekly_mood_email FROM user_settings WHERE user_id = :id');
    $stmt->execute([':id' => $user_id]);
    $row = $stmt->fetch();

    // No row yet — a student who never touched settings gets sensible
    // defaults rather than an error.
    $settings = $row ?: ['dark_mode' => 0, 'booking_reminders' => 1, 'weekly_mood_email' => 1];
    $settings['dark_mode'] = (bool) $settings['dark_mode'];
    $settings['booking_reminders'] = (bool) $settings['booking_reminders'];
    $settings['weekly_mood_email'] = (bool) $settings['weekly_mood_email'];

    jsonResponse(true, 'Settings retrieved.', $settings);
}

function handleSettingsUpdate(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $user_id = $_SESSION['user_id'];

    $dark_mode = ($_POST['dark_mode'] ?? '0') === '1' ? 1 : 0;
    $booking_reminders = ($_POST['booking_reminders'] ?? '1') === '1' ? 1 : 0;
    $weekly_mood_email = ($_POST['weekly_mood_email'] ?? '1') === '1' ? 1 : 0;

    $stmt = $pdo->prepare('
        INSERT INTO user_settings (user_id, dark_mode, booking_reminders, weekly_mood_email)
        VALUES (:user_id, :dark_mode, :booking_reminders, :weekly_mood_email)
        ON DUPLICATE KEY UPDATE
            dark_mode = VALUES(dark_mode),
            booking_reminders = VALUES(booking_reminders),
            weekly_mood_email = VALUES(weekly_mood_email)
    ');
    $stmt->execute([
        ':user_id' => $user_id,
        ':dark_mode' => $dark_mode,
        ':booking_reminders' => $booking_reminders,
        ':weekly_mood_email' => $weekly_mood_email,
    ]);

    jsonResponse(true, 'Settings saved.');
}

function userWantsBookingReminders(PDO $pdo, int $user_id): bool {
    $stmt = $pdo->prepare('SELECT booking_reminders FROM user_settings WHERE user_id = :id');
    $stmt->execute([':id' => $user_id]);
    $row = $stmt->fetch();
    return $row ? (bool) $row['booking_reminders'] : true; // default on if never set
}

// PASSWORD RESET (students, counsellors, and admins — email is globally
// unique across roles, so these endpoints work for any account type)
//
// SECURITY NOTE — read before treating this as production-ready:
// There is no email-sending system in this project (no PHPMailer wiring
// exists despite being in the planned stack). To make this flow actually
// work end-to-end, the reset code is returned directly in the API
// response instead of being emailed — but ONLY when the request comes
// from localhost, as a stopgap so this doesn't leak a live reset code to
// anyone on a real network who simply knows/guesses a counsellor's email.
// This is NOT equivalent to a real password-reset system. If this project
// is ever deployed anywhere network-accessible, a genuine email-based
// delivery mechanism is required before this feature is safe to expose.

function isLocalRequest(): bool {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    return in_array($ip, ['127.0.0.1', '::1', 'localhost'], true);
}

function handleForgotPasswordRequest(PDO $pdo): void {
    $email = trim($_POST['email'] ?? '');
    if ($email === '') {
        jsonResponse(false, 'Please enter your email address.');
    }

    $stmt = $pdo->prepare("SELECT user_id, full_name FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // Always respond the same way whether or not the account exists —
    // never confirm/deny account existence through this endpoint.
    $response = ['message' => 'If that account exists, a verification code has been sent to that email address.'];

    if ($user) {
        $code = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        $codeHash = password_hash($code, PASSWORD_BCRYPT);
        $expiresAt = date('Y-m-d H:i:s', time() + 10 * 60); // 10 minutes

        // Invalidate any earlier unused codes for this account first.
        $stmt = $pdo->prepare('DELETE FROM password_reset_codes WHERE user_id = :user_id AND used = 0');
        $stmt->execute([':user_id' => $user['user_id']]);

        $stmt = $pdo->prepare('
            INSERT INTO password_reset_codes (user_id, code_hash, expires_at)
            VALUES (:user_id, :code_hash, :expires_at)
        ');
        $stmt->execute([
            ':user_id' => $user['user_id'],
            ':code_hash' => $codeHash,
            ':expires_at' => $expiresAt,
        ]);

        require_once __DIR__ . '/../mailer.php';
        $sent = sendPasswordResetEmail($email, $user['full_name'], $code);

        if (!$sent && isLocalRequest()) {
            // Email didn't go out (likely mail-config.php still has
            // placeholder credentials, or a real SMTP error — check the
            // PHP error log). Fall back to showing the code directly so
            // local testing still works, same stopgap as before.
            $response['dev_code'] = $code;
            $response['message'] = 'Email could not be sent (check mail-config.php) — showing dev code instead.';
        } elseif (!$sent) {
            error_log('Password reset email failed to send and this is not a local request — no fallback shown to client.');
        }
    }

    jsonResponse(true, $response['message'], $response);
}

function handleForgotPasswordVerify(PDO $pdo): void {
    $email = trim($_POST['email'] ?? '');
    $code = trim($_POST['code'] ?? '');

    if ($email === '' || $code === '') {
        jsonResponse(false, 'Missing email or code.');
    }

    $stmt = $pdo->prepare('
        SELECT prc.reset_id, prc.code_hash, prc.attempts
        FROM password_reset_codes prc
        JOIN users u ON u.user_id = prc.user_id
        WHERE u.email = :email
          AND prc.used = 0
          AND prc.expires_at >= NOW()
        ORDER BY prc.created_at DESC
        LIMIT 1
    ');
    $stmt->execute([':email' => $email]);
    $row = $stmt->fetch();

    if (!$row) {
        jsonResponse(false, 'Incorrect or expired verification code.');
    }

    // Attempt limiting — lock this code out after 5 wrong guesses rather
    // than letting a 6-digit code be brute-forced indefinitely.
    if ((int) $row['attempts'] >= 5) {
        jsonResponse(false, 'Too many incorrect attempts. Please request a new code.');
    }

    if (!password_verify($code, $row['code_hash'])) {
        $stmt = $pdo->prepare('UPDATE password_reset_codes SET attempts = attempts + 1 WHERE reset_id = :id');
        $stmt->execute([':id' => $row['reset_id']]);
        jsonResponse(false, 'Incorrect verification code.');
    }

    // Correct code — issue a one-time reset token rather than letting the
    // final reset step re-use the same 6-digit code. The code's only job
    // was to prove identity; the token is what actually authorizes the
    // password change, and only this verify step ever hands it out.
    $resetToken = bin2hex(random_bytes(32));
    $tokenHash = hash('sha256', $resetToken);

    $stmt = $pdo->prepare('
        UPDATE password_reset_codes
        SET verified_at = NOW(), reset_token_hash = :token_hash
        WHERE reset_id = :id
    ');
    $stmt->execute([':token_hash' => $tokenHash, ':id' => $row['reset_id']]);

    jsonResponse(true, 'Code verified.', ['reset_token' => $resetToken]);
}

function handleForgotPasswordReset(PDO $pdo): void {
    $email = trim($_POST['email'] ?? '');
    $token = trim($_POST['reset_token'] ?? '');
    $newPassword = $_POST['new_password'] ?? '';

    if ($email === '' || $token === '' || $newPassword === '') {
        jsonResponse(false, 'Missing required fields.');
    }
    if (strlen($newPassword) < 8 || !preg_match('/[A-Z]/', $newPassword) || !preg_match('/\d/', $newPassword)) {
        jsonResponse(false, 'Password must be at least 8 characters and include an uppercase letter and a number.');
    }

    $stmt = $pdo->prepare('
        SELECT prc.reset_id, prc.user_id, prc.reset_token_hash
        FROM password_reset_codes prc
        JOIN users u ON u.user_id = prc.user_id
        WHERE u.email = :email
          AND prc.verified_at IS NOT NULL
          AND prc.used = 0
          AND prc.expires_at >= NOW()
        ORDER BY prc.created_at DESC
        LIMIT 1
    ');
    $stmt->execute([':email' => $email]);
    $row = $stmt->fetch();

    if (!$row || !$row['reset_token_hash'] || !hash_equals($row['reset_token_hash'], hash('sha256', $token))) {
        jsonResponse(false, 'Invalid or expired password reset session. Please start over.');
    }

    $stmt = $pdo->prepare('UPDATE users SET password_hash = :hash WHERE user_id = :user_id');
    $stmt->execute([
        ':hash' => password_hash($newPassword, PASSWORD_BCRYPT),
        ':user_id' => $row['user_id'],
    ]);

    $stmt = $pdo->prepare('UPDATE password_reset_codes SET used = 1 WHERE reset_id = :reset_id');
    $stmt->execute([':reset_id' => $row['reset_id']]);

    jsonResponse(true, 'Password has been reset.');
}

// ADMIN DASHBOARD

function requireAdminRole(): void {
    if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
        http_response_code(403);
        jsonResponse(false, 'Admin access required.');
    }
}

/*
 * NOTE — "Top Concerns" in the mockup shows Stress/Anxiety/Academic
 * Pressure/Other, but nothing in this schema tracks those specific
 * categories. This uses REAL journal_entries.emotion data instead (the
 * actual 5 emotions students tag entries with) rather than inventing
 * numbers for labels the data doesn't support. Whoever owns this page
 * should either relabel the panel to "Journal Mood Breakdown" or have the
 * team add real concern-category tracking if the original labels matter.
 *
 * NOTE — "Counsellors" counts real accounts (users WHERE role='counsellor'),
 * NOT the separate `counsellors` lookup table used by the booking page —
 * those two are still disconnected (see counselling-booking's schema note).
 */
function handleAdminDashboardSummary(PDO $pdo): void {
    requireAdminRole();

    $totalUsers = (int) $pdo->query("SELECT COUNT(*) AS c FROM users")->fetch()['c'];
    $counsellorAccounts = (int) $pdo->query("SELECT COUNT(*) AS c FROM users WHERE role = 'counsellor'")->fetch()['c'];

    // "Active" = a student with at least one tracked action (check-in,
    // journal entry, peer post/reply, or booking) in the last 30 days —
    // there's no login/last-active tracking to use instead.
    $stmt = $pdo->query("
        SELECT COUNT(DISTINCT u.user_id) AS c
        FROM users u
        WHERE u.role = 'student'
          AND u.user_id IN (
              SELECT user_id FROM mood_checkins WHERE checkin_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
              UNION SELECT user_id FROM journal_entries WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
              UNION SELECT user_id FROM posts WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
              UNION SELECT user_id FROM post_replies WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
              UNION SELECT user_id FROM bookings WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
          )
    ");
    $activeStudents = (int) $stmt->fetch()['c'];

    $stmt = $pdo->query("
        SELECT COUNT(*) AS c FROM bookings
        WHERE status IN ('booked','completed')
          AND MONTH(session_date) = MONTH(CURDATE())
          AND YEAR(session_date) = YEAR(CURDATE())
    ");
    $sessionsThisMonth = (int) $stmt->fetch()['c'];

    // User growth: signups per month for the last 6 months, oldest first.
    $stmt = $pdo->query("
        SELECT DATE_FORMAT(created_at, '%Y-%m') AS ym, DATE_FORMAT(created_at, '%b') AS label, COUNT(*) AS cnt
        FROM users
        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
        GROUP BY ym, label
        ORDER BY ym ASC
    ");
    $userGrowth = $stmt->fetchAll();
    foreach ($userGrowth as &$row) {
        $row['cnt'] = (int) $row['cnt'];
        unset($row['ym']);
    }

    // Real journal emotion breakdown (see note above on why this replaces
    // the mockup's invented "Top Concerns" categories).
    $stmt = $pdo->query("SELECT emotion, COUNT(*) AS cnt FROM journal_entries WHERE emotion IS NOT NULL GROUP BY emotion");
    $emotionRows = $stmt->fetchAll();
    $emotionTotal = array_sum(array_column($emotionRows, 'cnt'));
    $emotionBreakdown = [];
    foreach ($emotionRows as $row) {
        $emotionBreakdown[] = [
            'emotion' => $row['emotion'],
            'count' => (int) $row['cnt'],
            'percentage' => $emotionTotal > 0 ? round(($row['cnt'] / $emotionTotal) * 100) : 0,
        ];
    }

    jsonResponse(true, 'Admin dashboard summary retrieved.', [
        'kpis' => [
            'total_users' => $totalUsers,
            'active_students' => $activeStudents,
            'counsellor_accounts' => $counsellorAccounts,
            'sessions_this_month' => $sessionsThisMonth,
        ],
        'user_growth' => $userGrowth,
        'emotion_breakdown' => $emotionBreakdown,
    ]);
}

// ADMIN USER MANAGEMENT

function handleAdminUserList(PDO $pdo): void {
    requireAdminRole();

    $search = trim($_GET['q'] ?? '');
    if ($search !== '') {
        $stmt = $pdo->prepare("
            SELECT user_id, full_name, email, role, is_active, last_login_at, student_number, created_at
            FROM users
            WHERE full_name LIKE :q OR email LIKE :q
            ORDER BY created_at DESC
        ");
        $stmt->execute([':q' => '%' . $search . '%']);
    } else {
        $stmt = $pdo->query("
            SELECT user_id, full_name, email, role, is_active, last_login_at, student_number, created_at
            FROM users
            ORDER BY created_at DESC
        ");
    }
    $users = $stmt->fetchAll();
    foreach ($users as &$u) {
        $u['is_active'] = (bool) $u['is_active'];
    }

    jsonResponse(true, 'Users retrieved.', ['users' => $users]);
}

function handleAdminUserCreate(PDO $pdo): void {
    requireAdminRole();

    $full_name = sanitize($_POST['full_name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';
    $student_number = sanitize($_POST['student_number'] ?? '');

    if ($full_name === '' || $email === '' || $password === '') {
        jsonResponse(false, 'Name, email and password are required.');
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        jsonResponse(false, 'Invalid email address.');
    }
    if (strlen($password) < 8) {
        jsonResponse(false, 'Password must be at least 8 characters long.');
    }
    if (!in_array($role, ['student', 'counsellor', 'admin'], true)) {
        jsonResponse(false, 'Invalid role.');
    }

    // Role-specific rules — these mirror what the real login endpoints for
    // each role actually check, so an admin-created account can log in.
    if ($role === 'student') {
        if ($student_number === '') {
            jsonResponse(false, 'Student number is required for student accounts.');
        }
        $expected_email = $student_number . '@my.richfield.ac.za';
        if (strtolower($email) !== strtolower($expected_email)) {
            jsonResponse(false, 'Student email must match their student number (' . $expected_email . ').');
        }
    } elseif ($role === 'counsellor') {
        if (!str_ends_with(strtolower($email), strtolower(COUNSELLOR_EMAIL_DOMAIN))) {
            jsonResponse(false, 'Counsellor email must end in ' . COUNSELLOR_EMAIL_DOMAIN . '.');
        }
        if (substr($password, 0, 3) !== COUNSELLOR_SHARED_CODE) {
            jsonResponse(false, 'Counsellor passwords must start with the shared code "' . COUNSELLOR_SHARED_CODE . '".');
        }
        $student_number = null;
    } else {
        $student_number = null;
    }

    $stmt = $pdo->prepare('SELECT user_id FROM users WHERE email = ?');
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        jsonResponse(false, 'An account with this email already exists.');
    }

    $stmt = $pdo->prepare('
        INSERT INTO users (full_name, student_number, email, password_hash, role, is_active)
        VALUES (:full_name, :student_number, :email, :password_hash, :role, 1)
    ');
    $stmt->execute([
        ':full_name' => $full_name,
        ':student_number' => $student_number ?: null,
        ':email' => $email,
        ':password_hash' => password_hash($password, PASSWORD_BCRYPT),
        ':role' => $role,
    ]);

    $newUserId = $pdo->lastInsertId();
    createAuditLog($pdo, $_SESSION['user_id'], 'user_created', 'users', (int) $newUserId, "Created {$role} account for {$email}.");

    jsonResponse(true, 'Account created.', ['user_id' => $newUserId]);
}

function handleAdminUserUpdate(PDO $pdo): void {
    requireAdminRole();

    $user_id = (int) ($_POST['user_id'] ?? 0);
    if ($user_id <= 0) {
        jsonResponse(false, 'Invalid user.');
    }

    $updates = [];
    $params = [':user_id' => $user_id];

    if (isset($_POST['role'])) {
        $role = $_POST['role'];
        if (!in_array($role, ['student', 'counsellor', 'admin'], true)) {
            jsonResponse(false, 'Invalid role.');
        }
        $updates[] = 'role = :role';
        $params[':role'] = $role;
    }

    if (isset($_POST['is_active'])) {
        // Guard against an admin accidentally locking themselves out.
        if ($user_id === (int) $_SESSION['user_id'] && $_POST['is_active'] === '0') {
            jsonResponse(false, 'You cannot deactivate your own account.');
        }
        $updates[] = 'is_active = :is_active';
        $params[':is_active'] = $_POST['is_active'] === '1' ? 1 : 0;
    }

    if (empty($updates)) {
        jsonResponse(false, 'Nothing to update.');
    }

    $sql = 'UPDATE users SET ' . implode(', ', $updates) . ' WHERE user_id = :user_id';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    $changeDesc = [];
    if (isset($_POST['role'])) $changeDesc[] = "role set to {$_POST['role']}";
    if (isset($_POST['is_active'])) $changeDesc[] = ($_POST['is_active'] === '1' ? 'reactivated' : 'suspended');
    createAuditLog($pdo, $_SESSION['user_id'], 'user_updated', 'users', $user_id, 'User ' . implode(', ', $changeDesc) . '.');

    jsonResponse(true, 'User updated.');
}

// ADMIN COUNSELLOR MANAGEMENT
//
// counsellors.user_id links a booking-page profile to a real login account.
// The 3 originally-seeded counsellor rows predate this link and are NOT
// automatically connected to any real account — they'll show as
// "No linked account" until someone manually links or recreates them.
// Every counsellor created THROUGH this admin page from now on creates
// both the real account and the linked profile in one step.

function handleAdminCounsellorList(PDO $pdo): void {
    requireAdminRole();

    $stmt = $pdo->query("
        SELECT c.counsellor_id, c.name, c.specialties, c.avatar, c.user_id,
               u.email, u.is_active
        FROM counsellors c
        LEFT JOIN users u ON u.user_id = c.user_id
        ORDER BY c.name
    ");
    $counsellors = $stmt->fetchAll();

    $todayIsWeekday = (int) date('N') < 6;

    foreach ($counsellors as &$c) {
        $c['is_active'] = $c['is_active'] === null ? null : (bool) $c['is_active'];

        $stmt2 = $pdo->prepare("
            SELECT COUNT(*) AS cnt FROM bookings
            WHERE counsellor_id = :id AND status IN ('booked','completed')
              AND MONTH(session_date) = MONTH(CURDATE()) AND YEAR(session_date) = YEAR(CURDATE())
        ");
        $stmt2->execute([':id' => $c['counsellor_id']]);
        $c['appointments_this_month'] = (int) $stmt2->fetch()['cnt'];

        // Real availability check: is EVERY one of today's fixed slots
        // already booked for this counsellor? Reuses the same slot
        // template as the student booking page.
        if (!$todayIsWeekday) {
            $c['availability'] = 'No sessions today';
        } else {
            $stmt3 = $pdo->prepare("
                SELECT COUNT(*) AS cnt FROM bookings
                WHERE counsellor_id = :id AND session_date = CURDATE() AND status = 'booked'
            ");
            $stmt3->execute([':id' => $c['counsellor_id']]);
            $bookedToday = (int) $stmt3->fetch()['cnt'];
            $c['availability'] = $bookedToday >= count(BOOKING_SLOT_TEMPLATE) ? 'Busy' : 'Available';
        }
    }

    jsonResponse(true, 'Counsellors retrieved.', ['counsellors' => $counsellors]);
}

function handleAdminCounsellorCreate(PDO $pdo): void {
    requireAdminRole();

    $full_name = sanitize($_POST['full_name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $specialties = sanitize($_POST['specialties'] ?? '');
    $avatar = trim($_POST['avatar'] ?? '') ?: '🧑🏽';

    if ($full_name === '' || $email === '' || $password === '') {
        jsonResponse(false, 'Name, email and password are required.');
    }
    if (!str_ends_with(strtolower($email), strtolower(COUNSELLOR_EMAIL_DOMAIN))) {
        jsonResponse(false, 'Counsellor email must end in ' . COUNSELLOR_EMAIL_DOMAIN . '.');
    }
    if (strlen($password) < 8 || substr($password, 0, 3) !== COUNSELLOR_SHARED_CODE) {
        jsonResponse(false, 'Password must be at least 8 characters and start with the shared code "' . COUNSELLOR_SHARED_CODE . '".');
    }

    $stmt = $pdo->prepare('SELECT user_id FROM users WHERE email = ?');
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        jsonResponse(false, 'An account with this email already exists.');
    }

    // Create the real login account first, then the linked profile.
    $stmt = $pdo->prepare('
        INSERT INTO users (full_name, email, password_hash, role, is_active)
        VALUES (:full_name, :email, :password_hash, "counsellor", 1)
    ');
    $stmt->execute([
        ':full_name' => $full_name,
        ':email' => $email,
        ':password_hash' => password_hash($password, PASSWORD_BCRYPT),
    ]);
    $newUserId = $pdo->lastInsertId();

    $stmt = $pdo->prepare('
        INSERT INTO counsellors (name, specialties, avatar, user_id)
        VALUES (:name, :specialties, :avatar, :user_id)
    ');
    $stmt->execute([
        ':name' => $full_name,
        ':specialties' => $specialties ?: null,
        ':avatar' => $avatar,
        ':user_id' => $newUserId,
    ]);

    createAuditLog($pdo, $_SESSION['user_id'], 'counsellor_created', 'users', (int) $newUserId, "Created counsellor account and profile for {$email}.");

    jsonResponse(true, 'Counsellor account and profile created.', ['user_id' => $newUserId]);
}

// ADMIN REPORTS & EXPORT
//
// NOTE — two real gaps flagged rather than faked:
// 1. Department filtering (DIT/BAS/NET in the mockup) does nothing — there
//    is no department/faculty field anywhere in the schema, and
//    registration never collects it. The frontend keeps the selector
//    visible but shows a note that it's not wired to anything yet.
// 2. "Elevated Concern" (labelled "High Risk Students" in the original
//    mockup, deliberately relabeled) is a simple heuristic — students
//    averaging "low"/"struggling" mood over the period — NOT a clinical
//    risk assessment. Real risk detection is the separate, still-unbuilt
//    risk-alerts.php feature and shouldn't be confused with this.
// report_type is accepted but currently doesn't change which stats are
// computed — same underlying data for Monthly/Risk/Engagement for now.

function reportPeriodBounds(string $ym): array {
    $start = $ym . '-01';
    $end = date('Y-m-t', strtotime($start));
    $prevStart = date('Y-m-01', strtotime($start . ' -1 month'));
    $prevEnd = date('Y-m-t', strtotime($prevStart));
    return [$start, $end, $prevStart, $prevEnd];
}

function pctChange($current, $previous) {
    if ($previous == 0) return null; // no baseline to compare against
    return round((($current - $previous) / $previous) * 100, 1);
}

function computeReportData(PDO $pdo, string $ym): array {
    [$start, $end, $prevStart, $prevEnd] = reportPeriodBounds($ym);

    $moodCase = "CASE mood WHEN 'great' THEN 5 WHEN 'good' THEN 4 WHEN 'okay' THEN 3 WHEN 'low' THEN 2 WHEN 'struggling' THEN 1 END";

    $stmt = $pdo->prepare("SELECT AVG($moodCase) AS avg_mood FROM mood_checkins WHERE checkin_date BETWEEN :s AND :e");
    $stmt->execute([':s' => $start, ':e' => $end]);
    $avgMood = $stmt->fetch()['avg_mood'];

    $stmt->execute([':s' => $prevStart, ':e' => $prevEnd]);
    $avgMoodPrev = $stmt->fetch()['avg_mood'];

    $stmt = $pdo->prepare("
        SELECT COUNT(*) AS cnt FROM (
            SELECT user_id FROM mood_checkins
            WHERE checkin_date BETWEEN :s AND :e
            GROUP BY user_id
            HAVING AVG($moodCase) <= 2
        ) AS sub
    ");
    $stmt->execute([':s' => $start, ':e' => $end]);
    $elevatedConcern = (int) $stmt->fetch()['cnt'];

    $stmt->execute([':s' => $prevStart, ':e' => $prevEnd]);
    $elevatedConcernPrev = (int) $stmt->fetch()['cnt'];

    $stmt = $pdo->prepare("
        SELECT COUNT(*) AS cnt FROM bookings
        WHERE status IN ('booked','completed') AND session_date BETWEEN :s AND :e
    ");
    $stmt->execute([':s' => $start, ':e' => $end]);
    $sessions = (int) $stmt->fetch()['cnt'];

    $stmt->execute([':s' => $prevStart, ':e' => $prevEnd]);
    $sessionsPrev = (int) $stmt->fetch()['cnt'];

    return [
        'month' => $ym,
        'avg_mood' => $avgMood !== null ? round((float) $avgMood, 2) : null,
        'avg_mood_change' => pctChange($avgMood, $avgMoodPrev),
        'elevated_concern_count' => $elevatedConcern,
        'elevated_concern_change' => pctChange($elevatedConcern, $elevatedConcernPrev),
        'sessions' => $sessions,
        'sessions_change' => pctChange($sessions, $sessionsPrev),
    ];
}

function handleAdminReportSummary(PDO $pdo): void {
    requireAdminRole();
    $ym = $_GET['month'] ?? date('Y-m');
    if (!preg_match('/^\d{4}-\d{2}$/', $ym)) {
        jsonResponse(false, 'Invalid month.');
    }
    jsonResponse(true, 'Report retrieved.', computeReportData($pdo, $ym));
}

function handleAdminReportExportCsv(PDO $pdo): void {
    requireAdminRole();
    $ym = $_GET['month'] ?? date('Y-m');
    if (!preg_match('/^\d{4}-\d{2}$/', $ym)) {
        jsonResponse(false, 'Invalid month.');
    }
    $data = computeReportData($pdo, $ym);
    createAuditLog($pdo, $_SESSION['user_id'], 'report_exported', null, null, "Exported {$ym} report as CSV.");

    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="wellnesshub-report-' . $ym . '.csv"');

    $out = fopen('php://output', 'w');
    fputcsv($out, ['WellnessHub Institution Report', $ym]);
    fputcsv($out, []);
    fputcsv($out, ['Metric', 'Value', 'Change vs Previous Month']);
    fputcsv($out, ['Average Mood (1-5 scale)', $data['avg_mood'] ?? 'No data', $data['avg_mood_change'] !== null ? $data['avg_mood_change'] . '%' : 'N/A']);
    fputcsv($out, ['Students with Elevated Concern (self-reported mood based, not clinical)', $data['elevated_concern_count'], $data['elevated_concern_change'] !== null ? $data['elevated_concern_change'] . '%' : 'N/A']);
    fputcsv($out, ['Counselling Sessions', $data['sessions'], $data['sessions_change'] !== null ? $data['sessions_change'] . '%' : 'N/A']);
    fclose($out);
    exit;
}

function handleAdminReportExportPdf(PDO $pdo): void {
    requireAdminRole();
    $ym = $_GET['month'] ?? date('Y-m');
    if (!preg_match('/^\d{4}-\d{2}$/', $ym)) {
        jsonResponse(false, 'Invalid month.');
    }
    $data = computeReportData($pdo, $ym);
    $monthLabel = date('F Y', strtotime($ym . '-01'));
    createAuditLog($pdo, $_SESSION['user_id'], 'report_exported', null, null, "Exported {$ym} report as PDF.");

    require_once __DIR__ . '/../lib/dompdf-autoload.php';
    $dompdf = new \Dompdf\Dompdf();

    $fmt = fn($v) => $v === null ? 'No data' : $v;
    $pct = fn($v) => $v === null ? 'N/A' : ($v >= 0 ? '+' : '') . $v . '%';

    $html = "
        <h1 style='font-family:sans-serif;'>WellnessHub Institution Wellness Report</h1>
        <p style='font-family:sans-serif; color:#555;'>Period: {$monthLabel}</p>
        <table style='width:100%; border-collapse:collapse; font-family:sans-serif;' border='1' cellpadding='8'>
            <tr><th align='left'>Metric</th><th align='left'>Value</th><th align='left'>Change vs Previous Month</th></tr>
            <tr><td>Average Mood (1-5 scale)</td><td>{$fmt($data['avg_mood'])}</td><td>{$pct($data['avg_mood_change'])}</td></tr>
            <tr><td>Students with Elevated Concern</td><td>{$data['elevated_concern_count']}</td><td>{$pct($data['elevated_concern_change'])}</td></tr>
            <tr><td>Counselling Sessions</td><td>{$data['sessions']}</td><td>{$pct($data['sessions_change'])}</td></tr>
        </table>
        <p style='font-family:sans-serif; font-size:11px; color:#888; margin-top:20px;'>
            \"Elevated Concern\" is based on self-reported mood check-in averages and is not a clinical risk assessment.
        </p>
    ";

    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();

    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="wellnesshub-report-' . $ym . '.pdf"');
    echo $dompdf->output();
    exit;
}

// SYSTEM LOGS
//
// NOTE: the original mockup included a fake "Security test completed — No
// SQL injection or XSS issues detected" log entry. That's not implemented
// here — there is no automated security-testing system anywhere in this
// project, and fabricating a log entry claiming one ran would be an false
// safety claim, not a placeholder worth keeping. Every entry this page
// shows now corresponds to a real event that actually happened.

function handleAdminLogList(PDO $pdo): void {
    requireAdminRole();

    $stmt = $pdo->query("
        SELECT l.log_id, l.action, l.target_table, l.target_id, l.details, l.created_at,
               u.full_name AS actor_name
        FROM auditlog l
        LEFT JOIN users u ON u.user_id = l.actor_user_id
        ORDER BY l.created_at DESC
        LIMIT 100
    ");
    jsonResponse(true, 'Logs retrieved.', ['logs' => $stmt->fetchAll()]);
}

function handleAdminLogExportCsv(PDO $pdo): void {
    requireAdminRole();

    $stmt = $pdo->query("
        SELECT l.created_at, u.full_name AS actor_name, l.action, l.target_table, l.target_id, l.details
        FROM auditlog l
        LEFT JOIN users u ON u.user_id = l.actor_user_id
        ORDER BY l.created_at DESC
    ");
    $logs = $stmt->fetchAll();

    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="wellnesshub-system-logs.csv"');

    $out = fopen('php://output', 'w');
    fputcsv($out, ['Timestamp', 'Actor', 'Action', 'Target Table', 'Target ID', 'Details']);
    foreach ($logs as $log) {
        fputcsv($out, [
            $log['created_at'],
            $log['actor_name'] ?? 'Unknown/unauthenticated',
            $log['action'],
            $log['target_table'],
            $log['target_id'],
            $log['details'],
        ]);
    }
    fclose($out);
    exit;
}

// ADMIN PLATFORM SETTINGS

function handleAdminPlatformSettingsGet(PDO $pdo): void {
    requireAdminRole();
    $stmt = $pdo->query('SELECT audit_logging_enabled FROM platform_settings WHERE id = 1');
    $row = $stmt->fetch();
    jsonResponse(true, 'Settings retrieved.', [
        'audit_logging_enabled' => $row ? (bool) $row['audit_logging_enabled'] : true,
    ]);
}

function handleAdminPlatformSettingsUpdate(PDO $pdo): void {
    requireAdminRole();
    $enabled = ($_POST['audit_logging_enabled'] ?? '1') === '1' ? 1 : 0;

    // Turning logging OFF must always be recorded — bypass createAuditLog's
    // own toggle check directly for this one event, since by the time the
    // setting is saved, the normal gated path would see it as already
    // disabled and silently skip logging the very action that disabled it.
    if ($enabled === 0) {
        $stmt = $pdo->prepare('
            INSERT INTO auditlog (actor_user_id, action, target_table, target_id, details)
            VALUES (:actor, :action, :target_table, :target_id, :details)
        ');
        $stmt->execute([
            ':actor' => $_SESSION['user_id'],
            ':action' => 'settings_updated',
            ':target_table' => 'platform_settings',
            ':target_id' => 1,
            ':details' => 'Audit logging disabled.',
        ]);
    }

    $stmt = $pdo->prepare('
        INSERT INTO platform_settings (id, audit_logging_enabled) VALUES (1, :enabled)
        ON DUPLICATE KEY UPDATE audit_logging_enabled = VALUES(audit_logging_enabled)
    ');
    $stmt->execute([':enabled' => $enabled]);

    if ($enabled === 1) {
        createAuditLog($pdo, $_SESSION['user_id'], 'settings_updated', 'platform_settings', 1, 'Audit logging enabled.');
    }

    jsonResponse(true, 'Settings saved.');
}

// COUNSELLOR DASHBOARD, APPOINTMENTS, STUDENTS & RISK ALERTS
// (merged from partner's counsellor-side update)

function requireStaff(): void {
    $role = $_SESSION['role'] ?? '';
    if (!isset($_SESSION['user_id']) || !in_array($role, ['counsellor', 'admin'], true)) {
        http_response_code(403);
        jsonResponse(false, 'Staff access only.');
    }
}

function syncRiskAlerts(PDO $pdo): void {
    $stmt = $pdo->query("
        SELECT checkin_id, user_id, mood, stress_level, checkin_date
        FROM mood_checkins
        WHERE checkin_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
          AND (mood IN ('struggling', 'low') OR stress_level >= 8)
    ");
    $insert = $pdo->prepare('
        INSERT INTO risk_alerts (user_id, source, source_id, severity, reason)
        VALUES (:user_id, "mood_checkin", :source_id, :severity, :reason)
        ON DUPLICATE KEY UPDATE severity = VALUES(severity), reason = VALUES(reason)
    ');
    foreach ($stmt->fetchAll() as $row) {
        $severity = ($row['mood'] === 'struggling' || (int) $row['stress_level'] >= 9) ? 'high' : 'medium';
        $reason = $row['mood'] === 'struggling'
            ? 'Logged a "struggling" mood check-in on ' . $row['checkin_date'] . '.'
            : ($row['mood'] === 'low'
                ? 'Logged a "low" mood check-in on ' . $row['checkin_date'] . '.'
                : 'Reported stress level ' . $row['stress_level'] . '/10 on ' . $row['checkin_date'] . '.');
        $insert->execute([
            ':user_id' => $row['user_id'],
            ':source_id' => $row['checkin_id'],
            ':severity' => $severity,
            ':reason' => $reason,
        ]);
    }

    syncCriticalJournalAlerts($pdo);
}

function handleCounsellorDashboardStats(PDO $pdo): void {
    requireStaff();
    syncRiskAlerts($pdo);

    $studentsToday = (int) $pdo->query('SELECT COUNT(DISTINCT user_id) FROM mood_checkins WHERE checkin_date = CURDATE()')->fetchColumn();
    $highRisk = (int) $pdo->query("SELECT COUNT(*) FROM risk_alerts WHERE status != 'resolved' AND severity = 'high'")->fetchColumn();
    $appointmentsToday = (int) $pdo->query('SELECT COUNT(*) FROM bookings WHERE session_date = CURDATE() AND status = "booked"')->fetchColumn();
    $resolvedAlerts = (int) $pdo->query("SELECT COUNT(*) FROM risk_alerts WHERE status = 'resolved' AND resolved_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetchColumn();

    $stmt = $pdo->query("
        SELECT checkin_date,
               AVG(CASE mood
                    WHEN 'struggling' THEN 1 WHEN 'low' THEN 2 WHEN 'okay' THEN 3
                    WHEN 'good' THEN 4 WHEN 'great' THEN 5 END) AS avg_score
        FROM mood_checkins
        WHERE checkin_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
        GROUP BY checkin_date
        ORDER BY checkin_date ASC
    ");
    $moodTrend = $stmt->fetchAll();

    $stmt = $pdo->query("
        SELECT mood, COUNT(*) AS cnt FROM mood_checkins
        WHERE checkin_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
        GROUP BY mood
    ");
    $counts = ['great' => 0, 'good' => 0, 'okay' => 0, 'low' => 0, 'struggling' => 0];
    foreach ($stmt->fetchAll() as $row) {
        $counts[$row['mood']] = (int) $row['cnt'];
    }
    $total = max(1, array_sum($counts));
    $distribution = [
        'positive' => round((($counts['great'] + $counts['good']) / $total) * 100),
        'neutral'  => round(($counts['okay'] / $total) * 100),
        'low'      => round((($counts['low'] + $counts['struggling']) / $total) * 100),
    ];

    jsonResponse(true, 'Dashboard stats retrieved.', [
        'students_checked_in_today' => $studentsToday,
        'high_risk_students' => $highRisk,
        'appointments_today' => $appointmentsToday,
        'resolved_alerts_week' => $resolvedAlerts,
        'mood_trend' => $moodTrend,
        'mood_distribution' => $distribution,
        'staff_name' => $_SESSION['full_name'] ?? 'Counsellor',
    ]);
}

function handleRiskAlertsList(PDO $pdo): void {
    requireStaff();
    syncRiskAlerts($pdo);

    $stmt = $pdo->query("
        SELECT ra.alert_id, ra.user_id, u.full_name AS student_name, ra.source, ra.severity,
               ra.reason, ra.status, ra.note, ra.created_at
        FROM risk_alerts ra
        JOIN users u ON u.user_id = ra.user_id
        WHERE ra.status != 'resolved'
        ORDER BY (ra.severity = 'high') DESC, ra.created_at DESC
    ");
    jsonResponse(true, 'Risk alerts retrieved.', ['alerts' => $stmt->fetchAll()]);
}

function handleRiskAlertUpdate(PDO $pdo): void {
    requireStaff();

    $alertId = (int) ($_POST['alert_id'] ?? 0);
    $status  = $_POST['status'] ?? '';
    $note    = sanitize($_POST['note'] ?? '');

    if ($alertId <= 0 || !in_array($status, ['in_progress', 'resolved'], true)) {
        jsonResponse(false, 'Invalid alert or status.');
    }

    $stmt = $pdo->prepare('
        UPDATE risk_alerts
        SET status = :status,
            note = :note,
            handled_by = :handled_by,
            resolved_at = CASE WHEN :status2 = "resolved" THEN NOW() ELSE resolved_at END
        WHERE alert_id = :alert_id
    ');
    $stmt->execute([
        ':status' => $status,
        ':status2' => $status,
        ':note' => $note !== '' ? $note : null,
        ':handled_by' => $_SESSION['user_id'],
        ':alert_id' => $alertId,
    ]);

    if ($stmt->rowCount() === 0) {
        jsonResponse(false, 'Alert not found.');
    }
    jsonResponse(true, 'Alert updated.');
}

function handleCounsellorAppointmentsList(PDO $pdo): void {
    requireStaff();

    $weekStart = $_GET['week_start'] ?? date('Y-m-d', strtotime('monday this week'));
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $weekStart)) {
        jsonResponse(false, 'Invalid week_start date.');
    }
    $weekEnd = date('Y-m-d', strtotime($weekStart . ' +4 days'));

    $stmt = $pdo->prepare('SELECT counsellor_id FROM counsellors WHERE user_id = :uid');
    $stmt->execute([':uid' => $_SESSION['user_id']]);
    $myCounsellorId = $stmt->fetchColumn();

    $sql = '
        SELECT b.booking_id, b.session_date, b.session_time, b.status,
               u.full_name AS student_name, c.name AS counsellor_name
        FROM bookings b
        JOIN users u ON u.user_id = b.user_id
        JOIN counsellors c ON c.counsellor_id = b.counsellor_id
        WHERE b.status = "booked" AND b.session_date BETWEEN :start AND :end
    ';
    $params = [':start' => $weekStart, ':end' => $weekEnd];

    if ($_SESSION['role'] === 'counsellor' && $myCounsellorId) {
        $sql .= ' AND b.counsellor_id = :cid';
        $params[':cid'] = $myCounsellorId;
    }
    $sql .= ' ORDER BY b.session_date ASC, b.session_time ASC';

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    jsonResponse(true, 'Appointments retrieved.', [
        'week_start' => $weekStart,
        'week_end' => $weekEnd,
        'appointments' => $stmt->fetchAll(),
    ]);
}

function handleCounsellorStudentsList(PDO $pdo): void {
    requireStaff();
    syncRiskAlerts($pdo);

    $search = sanitize($_GET['q'] ?? '');

    $sql = "
        SELECT
            u.user_id, u.full_name, u.student_number,
            lc.mood AS last_mood, lc.checkin_date AS last_checkin,
            (SELECT COUNT(*) FROM risk_alerts ra WHERE ra.user_id = u.user_id AND ra.status != 'resolved') AS open_alerts,
            (SELECT MAX(severity = 'high') FROM risk_alerts ra WHERE ra.user_id = u.user_id AND ra.status != 'resolved') AS has_high_risk
        FROM users u
        LEFT JOIN (
            SELECT mc1.user_id, mc1.mood, mc1.checkin_date
            FROM mood_checkins mc1
            INNER JOIN (
                SELECT user_id, MAX(checkin_date) AS max_date FROM mood_checkins GROUP BY user_id
            ) mc2 ON mc1.user_id = mc2.user_id AND mc1.checkin_date = mc2.max_date
        ) lc ON lc.user_id = u.user_id
        WHERE u.role = 'student'
    ";
    $params = [];
    if ($search !== '') {
        $sql .= ' AND (u.full_name LIKE :q OR u.student_number LIKE :q)';
        $params[':q'] = '%' . $search . '%';
    }
    $sql .= ' ORDER BY has_high_risk DESC, open_alerts DESC, u.full_name ASC';

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    jsonResponse(true, 'Students retrieved.', ['students' => $stmt->fetchAll()]);
}

function handleCounsellorNoteSave(PDO $pdo): void {
    requireStaff();

    $studentId = (int) ($_POST['user_id'] ?? 0);
    $note = sanitize($_POST['note'] ?? '');

    if ($studentId <= 0 || $note === '') {
        jsonResponse(false, 'A student and a note are required.');
    }

    $stmt = $pdo->prepare('
        INSERT INTO counsellor_notes (user_id, counsellor_id, note)
        VALUES (:user_id, :counsellor_id, :note)
    ');
    $stmt->execute([
        ':user_id' => $studentId,
        ':counsellor_id' => $_SESSION['user_id'],
        ':note' => $note,
    ]);

    jsonResponse(true, 'Note saved.', ['note_id' => $pdo->lastInsertId()]);
}

// STUDENT PROFILE
//
// Profile pictures are stored as base64 data URIs directly in
// users.profile_picture (mediumtext), same pattern as journal entry
// photos — no filesystem upload handling needed. The current value is
// also cached in $_SESSION so every page can render the right avatar
// without an extra DB query per page load; upload/remove keep both in sync.

function handleProfileGet(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }

    $stmt = $pdo->prepare('SELECT full_name, student_number, email, role, profile_picture FROM users WHERE user_id = :id');
    $stmt->execute([':id' => $_SESSION['user_id']]);
    $user = $stmt->fetch();

    if (!$user) {
        jsonResponse(false, 'Account not found.');
    }

    jsonResponse(true, 'Profile retrieved.', $user);
}

function handleProfilePictureUpload(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }

    $dataUri = $_POST['image'] ?? '';
    if ($dataUri === '') {
        jsonResponse(false, 'No image provided.');
    }

    // Same validation shape as journal photo uploads: must be a real
    // base64 image data URI, capped well under the mediumtext limit.
    $validImage = preg_match('#^data:image/(png|jpe?g|gif|webp);base64,[A-Za-z0-9+/=]+$#', $dataUri)
        && strlen($dataUri) <= 3 * 1024 * 1024;

    if (!$validImage) {
        jsonResponse(false, 'Please upload a PNG, JPG, GIF or WEBP image under 2MB.');
    }

    $stmt = $pdo->prepare('UPDATE users SET profile_picture = :pic WHERE user_id = :id');
    $stmt->execute([':pic' => $dataUri, ':id' => $_SESSION['user_id']]);

    $_SESSION['profile_picture'] = $dataUri;

    jsonResponse(true, 'Profile picture updated.');
}

function handleProfilePictureRemove(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }

    $stmt = $pdo->prepare('UPDATE users SET profile_picture = NULL WHERE user_id = :id');
    $stmt->execute([':id' => $_SESSION['user_id']]);

    $_SESSION['profile_picture'] = null;

    jsonResponse(true, 'Profile picture removed.');
}

// Lightweight count-only endpoint for the bell icon's unread dot — called
// on every page load, so this stays a single COUNT(*) rather than
// fetching full notification rows like notification_list does.
function handleNotificationUnreadCount(PDO $pdo): void {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        jsonResponse(false, 'You must be logged in.');
    }
    $stmt = $pdo->prepare('SELECT COUNT(*) AS cnt FROM notifications WHERE user_id = :user_id AND is_read = 0');
    $stmt->execute([':user_id' => $_SESSION['user_id']]);
    jsonResponse(true, 'Unread count retrieved.', ['unread_count' => (int) $stmt->fetch()['cnt']]);
}
